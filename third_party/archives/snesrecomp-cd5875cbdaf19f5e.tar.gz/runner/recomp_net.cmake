# recomp_net.cmake — optional recomp-net delay-sync netcode for snesrecomp games.
#
# recomp-net lives as a git submodule at lib/recomp-net. Games that want
# multiplayer link the STATIC target `recomp_net` (alias `recomp_net::recomp_net`)
# and implement the host loop described in lib/recomp-net/docs/host_integration.md
# (and docs/RECOMP_NET.md in this repo).
#
# Usage from a game project's CMakeLists.txt (after include(runner.cmake)):
#
#   # Option A — helper (preferred): add_subdirectory once + link the target
#   snesrecomp_enable_recomp_net(MyGame)
#
#   # Option B — opt-in via cache before include(runner.cmake):
#   #   cmake -DSNESRECOMP_ENABLE_NET=ON ...
#   # then link ${SNESRECOMP_RUNNER_LIBRARIES} (includes recomp_net when enabled)
#
# ICE / WAN (libjuice) — set before enabling:
#   set(SNESRECOMP_NET_ICE ON CACHE BOOL "" FORCE)
#   # or: cmake -DSNESRECOMP_NET_ICE=ON ...
# TURN testing (require Coturn + relay-only candidates; both peers):
#   cmake -DSNESRECOMP_NET_FORCE_TURN=ON -DSNESRECOMP_NET_ICE=ON ...

if(NOT SNESRECOMP_RECOMP_NET_ROOT)
    get_filename_component(SNESRECOMP_RECOMP_NET_ROOT
        "${CMAKE_CURRENT_LIST_DIR}/../lib/recomp-net" ABSOLUTE)
endif()
if(NOT SNESRECOMP_RBENGINE_ROOT)
    get_filename_component(SNESRECOMP_RBENGINE_ROOT
        "${CMAKE_CURRENT_LIST_DIR}/../lib/retcomm-rbengine" ABSOLUTE)
endif()

option(SNESRECOMP_ENABLE_NET
    "Build and expose recomp-net (delay-sync netcode) for game targets" OFF)
option(SNESRECOMP_NET_ICE
    "Enable ICE/libjuice transport in recomp-net (needs network at configure if libjuice is not vendored)" OFF)
option(SNESRECOMP_NET_FORCE_TURN
    "Testing: require Coturn TURN for ICE and only use typ relay candidates (both peers must match)" OFF)
# Kept so an existing -DSNESRECOMP_NET_ROLLBACK=ON configure does not warn.
# No longer consulted: retcomm-rbengine is linked for every netplay port --
# the rollback session is part of netplay, not a second option beside it.
option(SNESRECOMP_NET_ROLLBACK
    "(ignored) rollback is built for every netplay target" ON)

# Internal: add_subdirectory once; disable examples/tests when embedded.
function(_snesrecomp_add_recomp_net)
    if(TARGET recomp_net)
        return()
    endif()

    if(NOT EXISTS "${SNESRECOMP_RECOMP_NET_ROOT}/CMakeLists.txt")
        message(FATAL_ERROR
            "recomp-net submodule missing at ${SNESRECOMP_RECOMP_NET_ROOT}.\n"
            "Run: git submodule update --init --recursive lib/recomp-net")
    endif()

    set(RNET_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
    set(RNET_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    if(SNESRECOMP_NET_ICE OR SNESRECOMP_NET_FORCE_TURN)
        set(RNET_ENABLE_ICE ON CACHE BOOL "" FORCE)
        # Ship static libjuice inside recomp_net so coop binaries run without a
        # system libjuice.so (Fedora/remote hosts). Override with
        # -DRNET_ICE_BUNDLE_STATIC=OFF if you intentionally link a shared juice.
        set(RNET_ICE_BUNDLE_STATIC ON CACHE BOOL "" FORCE)
        if(SNESRECOMP_NET_FORCE_TURN)
            set(RNET_ICE_FORCE_TURN ON CACHE BOOL "" FORCE)
        endif()
    else()
        set(RNET_ENABLE_ICE OFF CACHE BOOL "" FORCE)
    endif()

    add_subdirectory(
        "${SNESRECOMP_RECOMP_NET_ROOT}"
        "${CMAKE_BINARY_DIR}/recomp-net-build"
        EXCLUDE_FROM_ALL)

    if(NOT TARGET recomp_net)
        message(FATAL_ERROR "recomp-net CMake did not create target recomp_net")
    endif()
endfunction()

# Internal: add retcomm-rbengine once. recomp-net is added first: rbengine
# releases before the peer-facing modules moved to recomp-net look for it
# through RECOMP_NET_ROOT rather than re-adding the subdirectory.
function(_snesrecomp_add_rbengine)
    if(TARGET retcomm_rbengine)
        return()
    endif()

    if(NOT EXISTS "${SNESRECOMP_RBENGINE_ROOT}/CMakeLists.txt")
        message(FATAL_ERROR
            "retcomm-rbengine submodule missing at ${SNESRECOMP_RBENGINE_ROOT}.\n"
            "Run: git submodule update --init --recursive lib/retcomm-rbengine")
    endif()

    _snesrecomp_add_recomp_net()
    # rbengine is C++; a C-only project() needs the language switched on.
    enable_language(CXX)
    set(RECOMP_NET_ROOT "${SNESRECOMP_RECOMP_NET_ROOT}" CACHE PATH "" FORCE)
    set(RBE_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    add_subdirectory(
        "${SNESRECOMP_RBENGINE_ROOT}"
        "${CMAKE_BINARY_DIR}/retcomm-rbengine-build"
        EXCLUDE_FROM_ALL)

    if(NOT TARGET retcomm_rbengine)
        message(FATAL_ERROR
            "retcomm-rbengine CMake did not create target retcomm_rbengine")
    endif()
endfunction()

# Link the rollback host into a game executable. Additive over
# snesrecomp_enable_recomp_net: delay-sync stays available and stays the
# default at runtime (SNES_NET_MODE=rollback opts in).
function(snesrecomp_enable_rollback target)
    if(NOT TARGET ${target})
        message(FATAL_ERROR
            "snesrecomp_enable_rollback: '${target}' is not a CMake target.")
    endif()
    # Idempotent: the desktop host helper enables rollback for every port,
    # and a port that predates that still calls this itself.
    get_target_property(_rb_done ${target} SNESRECOMP_ROLLBACK_ENABLED)
    if(_rb_done)
        return()
    endif()
    set_target_properties(${target} PROPERTIES SNESRECOMP_ROLLBACK_ENABLED TRUE)
    _snesrecomp_add_rbengine()
    # snes_netplay_rb calls recomp-net's scheduler / input history /
    # hash_confirm directly; rbengine supplies only the snap ring and clock.
    target_link_libraries(${target} PRIVATE recomp_net retcomm_rbengine)
    target_compile_definitions(${target} PRIVATE SNESRECOMP_NET_ROLLBACK=1)
    if(NOT SNESRECOMP_ENABLE_NET)
        target_sources(${target} PRIVATE
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay_rb.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_rb_probe.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_state_digest.c")
    endif()
    message(STATUS "SNESRECOMP_NET_ROLLBACK: ${target} links retcomm_rbengine")
endfunction()

# Link recomp-net into a game executable (and ensure it is built).
function(snesrecomp_enable_recomp_net target)
    if(NOT TARGET ${target})
        message(FATAL_ERROR
            "snesrecomp_enable_recomp_net: '${target}' is not a CMake target. "
            "Call this after add_executable(${target} ...).")
    endif()
    _snesrecomp_add_recomp_net()
    target_link_libraries(${target} PRIVATE recomp_net)
    target_compile_definitions(${target} PRIVATE SNESRECOMP_NET=1)
    if(SNESRECOMP_NET_FORCE_TURN)
        if(NOT SNESRECOMP_NET_ICE AND NOT RNET_ENABLE_ICE)
            message(FATAL_ERROR
                "SNESRECOMP_NET_FORCE_TURN=ON requires ICE "
                "(-DSNESRECOMP_NET_ICE=ON)")
        endif()
        target_compile_definitions(${target} PRIVATE SNESRECOMP_NET_FORCE_TURN=1)
        message(STATUS
            "SNESRECOMP_NET_FORCE_TURN: ICE requires TURN + relay-only candidates")
    endif()
    # SNES host facade and the SNES spelling of the lobby client. The client
    # itself is recomp-net's (recomp_net/lobby_client.h) and the launcher
    # backend recomp-ui's (recomp_netplay_host.h); what is compiled here is the
    # SNES adapter over each.
    if(NOT SNESRECOMP_ENABLE_NET)
        target_sources(${target} PRIVATE
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_session.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_lobby.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay_identity.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_app.c"
            "${SNESRECOMP_RUNNER_ROOT}/src/lobby/snes_lobby_client.c")
        target_include_directories(${target} PRIVATE
            "${SNESRECOMP_RUNNER_ROOT}/src/netplay"
            "${SNESRECOMP_RUNNER_ROOT}/src/lobby")
    endif()
    # Every netplay port carries the rollback session (retcomm-rbengine +
    # snes_netplay_rb): delay-sync stays the runtime default, rollback is
    # there to opt into (SNES_NET_MODE=rollback). It used to be a scaffold
    # checkbox most projects answered no to.
    snesrecomp_enable_rollback(${target})
    target_compile_definitions(${target} PRIVATE SNES_HAS_LOBBY_CLIENT=1)
    # Host lobby adapter needs recomp-ui types when the launcher is linked,
    # and -- since the lobby lift -- recomp-ui's shared netplay backend, which
    # snes_host_lobby.c is a thin adapter over. There is no SNES copy to fall
    # back to: a recomp-ui that predates the backend is a configure error
    # naming what to bump, not a build that silently loses its lobby.
    if(DEFINED RECOMP_UI_ROOT AND EXISTS "${RECOMP_UI_ROOT}/src/recomp_launcher.h")
        target_include_directories(${target} PRIVATE "${RECOMP_UI_ROOT}/src")
        target_compile_definitions(${target} PRIVATE SNES_HOST_HAS_RECOMP_UI=1)
        if(NOT COMMAND recomp_target_launcher_netplay)
            message(FATAL_ERROR
                "snesrecomp_enable_recomp_net(${target}): recomp-ui at "
                "${RECOMP_UI_ROOT} has no recomp_target_launcher_netplay(). "
                "The SNES lobby is now recomp-ui's shared netplay backend "
                "(src/recomp_netplay_host.h): include(recomp_ui.cmake) before "
                "this call, from a recomp-ui that carries it.")
        endif()
        recomp_target_launcher_netplay(${target} RECOMP_NET_TARGET recomp_net)
    endif()
    if(WIN32)
        target_link_libraries(${target} PRIVATE ws2_32)
    endif()
endfunction()

# When SNESRECOMP_ENABLE_NET=ON at configure time, pull the library into the
# shared runner link list so games that already link ${SNESRECOMP_RUNNER_LIBRARIES}
# pick it up without a separate helper call.
if(SNESRECOMP_ENABLE_NET)
    _snesrecomp_add_recomp_net()
    _snesrecomp_add_rbengine()
    list(APPEND SNESRECOMP_RUNNER_SOURCES
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay_rb.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_rb_probe.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_state_digest.c")
    list(APPEND SNESRECOMP_RUNNER_LIBRARIES retcomm_rbengine)
    list(APPEND SNESRECOMP_RUNNER_INCLUDE_DIRS
        "${SNESRECOMP_RBENGINE_ROOT}/include")
    add_compile_definitions(SNESRECOMP_NET_ROLLBACK=1)
    list(APPEND SNESRECOMP_RUNNER_SOURCES
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_session.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_lobby.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_netplay_identity.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay/snes_host_app.c"
        "${SNESRECOMP_RUNNER_ROOT}/src/lobby/snes_lobby_client.c")
    list(APPEND SNESRECOMP_RUNNER_LIBRARIES recomp_net)
    list(APPEND SNESRECOMP_RUNNER_INCLUDE_DIRS
        "${SNESRECOMP_RECOMP_NET_ROOT}/include"
        "${SNESRECOMP_RUNNER_ROOT}/src/netplay"
        "${SNESRECOMP_RUNNER_ROOT}/src/lobby")
    add_compile_definitions(SNESRECOMP_NET=1 SNES_HAS_LOBBY_CLIENT=1)
    # snes_host_lobby.c is an adapter over recomp-ui's shared netplay backend.
    # This directory-scope path has no target to link it to: a port that also
    # links the launcher must call recomp_target_launcher_netplay(<target>)
    # itself (snesrecomp_enable_recomp_net does it for the per-target path).
    message(STATUS
        "SNESRECOMP_ENABLE_NET: link recomp-ui's netplay backend with "
        "recomp_target_launcher_netplay(<target>) when the launcher is linked")
    if(WIN32)
        list(APPEND SNESRECOMP_RUNNER_LIBRARIES ws2_32)
    endif()
    if(SNESRECOMP_NET_FORCE_TURN)
        add_compile_definitions(SNESRECOMP_NET_FORCE_TURN=1)
    endif()
    message(STATUS
        "SNESRECOMP_ENABLE_NET: recomp-net linked via SNESRECOMP_RUNNER_LIBRARIES"
        " (ICE=${SNESRECOMP_NET_ICE} FORCE_TURN=${SNESRECOMP_NET_FORCE_TURN})")
endif()
