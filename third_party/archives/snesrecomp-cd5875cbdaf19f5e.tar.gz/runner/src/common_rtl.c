#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif
#include "common_rtl.h"
#include "apu_frame_clock.h"
#include "common_cpu_infra.h"
#include "snes/interp_bridge.h"
#include <setjmp.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#ifdef _WIN32
#include <direct.h>
#include <io.h>
#else
#include <sys/stat.h>
#include <unistd.h>
#endif
#include "recomp_hw.h"
#include "framedump.h"
#include "util.h"
#include "config.h"
#include "snes/snes.h"
#include "snes/apu.h"
#include "snes/joypad.h"
#include "snes/dsp.h"
#include "snes/cart.h"
#include "snes/dma.h"
#include "snes/cx4.h"
#include "snes/sa1.h"
#include "snes/msu1.h"
#include "mod_audio.h"
#include "snes/ws_shadow.h"
#if SNESRECOMP_ENABLE_MODS
#include "mod_runtime.h"
#endif
#include "cpu_state.h"
#include "cpu_trace.h"
#include "debug_server.h"
#include "audio_trace.h"
#include "ppu_dma_trace.h"
#include "host_report.h"
#include "cosim.h"
static void rtl_reset_audio_delivery(void);
#include "snes_runahead.h"
#if defined(SNESRECOMP_NET)
#include "snes_netplay.h"
#endif

/* See RtlSetSpeculativeFrame in common_rtl.h. Run-ahead drives this on every
 * build, netplay or not, so it must not sit behind the netplay guard. */
static bool g_rtl_speculative_frame;

uint8 g_ram[0x20000];
uint8 *g_sram;
int g_sram_size;
const uint8 *g_rom;
Ppu *g_ppu;
Dma *g_dma;
uint8 g_snesrecomp_last_hdmaen;

/* Guest -> APU port ($2140-$217F) write observers. Trusted host modules
 * (sound replacement, telemetry) see every CPU-side port write in program
 * order before it reaches the SPC; returning nonzero consumes the write so
 * the SPC never hears it. Always compiled (independent of the mod package
 * runtime) so a title can register one from plain C. */
static RtlApuPortObserver s_apu_port_observers[RTL_APU_PORT_OBSERVER_MAX];
static int s_apu_port_observer_count;
static RtlApuPortReadObserver s_apu_read_observers[RTL_APU_PORT_OBSERVER_MAX];
static int s_apu_read_observer_count;

int RtlAddApuPortReadObserver(RtlApuPortReadObserver observer) {
  if (!observer) return 0;
  for (int i = 0; i < s_apu_read_observer_count; i++)
    if (s_apu_read_observers[i] == observer) return 1;
  if (s_apu_read_observer_count >= RTL_APU_PORT_OBSERVER_MAX) return 0;
  s_apu_read_observers[s_apu_read_observer_count++] = observer;
  return 1;
}
void RtlRemoveApuPortReadObserver(RtlApuPortReadObserver observer) {
  for (int i = 0; i < s_apu_read_observer_count; i++) if (s_apu_read_observers[i] == observer) {
    memmove(s_apu_read_observers+i, s_apu_read_observers+i+1,
            (s_apu_read_observer_count-i-1)*sizeof(*s_apu_read_observers));
    s_apu_read_observers[--s_apu_read_observer_count] = NULL; return;
  }
}
uint8 rtl_apu_port_observers_read(uint16 reg, uint8 value) {
  for (int i = 0; i < s_apu_read_observer_count; i++)
    if (s_apu_read_observers[i](reg, &value)) break;
  return value;
}

int RtlAddApuPortObserver(RtlApuPortObserver observer) {
  if (!observer) return 0;
  for (int i = 0; i < s_apu_port_observer_count; i++)
    if (s_apu_port_observers[i] == observer) return 1;
  if (s_apu_port_observer_count >= RTL_APU_PORT_OBSERVER_MAX) return 0;
  s_apu_port_observers[s_apu_port_observer_count++] = observer;
  return 1;
}

void RtlRemoveApuPortObserver(RtlApuPortObserver observer) {
  for (int i = 0; i < s_apu_port_observer_count; i++) {
    if (s_apu_port_observers[i] == observer) {
      memmove(s_apu_port_observers + i, s_apu_port_observers + i + 1,
              (s_apu_port_observer_count - i - 1) * sizeof(*s_apu_port_observers));
      s_apu_port_observers[--s_apu_port_observer_count] = NULL;
      return;
    }
  }
}

int rtl_apu_port_observers_filter(uint16 reg, uint8 value) {
  int consumed = 0;
  for (int i = 0; i < s_apu_port_observer_count; i++)
    if (s_apu_port_observers[i] && s_apu_port_observers[i](reg, value))
      consumed = 1;
  return consumed;
}

#include "snes/interp_bridge.h"
#ifdef SNESRECOMP_NET_ROLLBACK
#include "netplay/snes_rb_probe.h"
#endif

/* Netplay suppresses the pre-frame wall-clock fallback below. Once frames
 * begin, every runner uses the same guest-frame/APU coupling, and the audio
 * callback only consumes samples without advancing emulation. */
static int rtl_netplay_locks_audio(void) {
#if defined(SNESRECOMP_NET_ROLLBACK)
  /* An armed rollback probe is held to the same rule: see snes_rb_probe.c. */
  if (snes_rb_probe_armed())
    return 1;
#endif
  /* Run-ahead is held to it too, and for the identical reason: it rewinds.
   * The fallback below charges the SPC by WALL-CLOCK elapsed time, and
   * run-ahead spends roughly twice the wall time per displayed frame because
   * it simulates every frame twice. That made the SPC run at ~2x guest tempo
   * -- measured on the attract sequence, which is music-cued and reached the
   * title screen hundreds of frames early with run-ahead 1. Host time folded
   * into guest state cannot survive a rewind; once the frame loop is running
   * rtl_sync_apu_frame_boundary() is the authoritative clock and is keyed on
   * snes_frame_counter, so suppressing this costs nothing but the no-consumer
   * boot-window baseline. */
  if (snes_runahead_active())
    return 1;
#if defined(SNESRECOMP_NET)
  return snes_netplay_active();
#else
  return 0;
#endif
}

static int rtl_fps_heartbeat_enabled(void) {
  static int s_enabled = -1;
  if (s_enabled < 0) {
    const char *env = getenv("SNESRECOMP_FPS");
    s_enabled = env != NULL;
  }
  return s_enabled;
}

void RtlNetplayAudioReset(void) {
  /* Kept as a stable facade hook for recomp-net hosts. The current runner's
   * audio callback is already consumer-only, so there is no separate
   * wall-clock netplay accumulator to reset. */
}

// Main-CPU cycle estimate, incremented per RDB_BLOCK_HOOK in debug_on_block_enter.
// Used to pace APU catchup realistically: real SNES is ~3.58 MHz main / ~1.024 MHz APU,
// ratio ~3.5:1. Prior code hardcoded apuCatchupCycles=32 per APU port touch regardless
// of elapsed main-CPU time, which let APU stay artificially synchronized -- SMW boot's
// "wait for APU ack" loops resolved instantly, racing through ~200 frames worth of game
// logic in ~95 frames. Tracking real elapsed cycles makes those waits actually wait.
uint64_t g_main_cpu_cycles_estimate = 0;
// APU-port-touch-only estimate (issue #4). Only touches of $2140-$217F
// count toward APU catch-up pacing. The general estimate above counts
// EVERY HW-reg touch, which wildly over-counts during load-heavy phases:
// graphics decompression hammers $2118/$2122 thousands of times per
// frame, and the next APU-port access used to convert that entire
// fictional backlog into SPC cycles at once. Measured on MMX (audio_trace
// rings, 300 s boot→attract): 237,426 native samples — 7.4 s of SPC
// over-advance — dropped at the output ring, clustered at scene
// transitions, audibly skipping the music forward at every stage load.
// Genuine APU handshakes (boot/bank uploads, command acks) self-pace
// through their own port polls — each poll is an APU touch — so they
// still over-clock the SPC and complete fast; that part is required:
// at hardware-real SPC pace MMX's boot upload blocks a single frame
// for >5 s and trips the per-frame watchdog (measured, 2026-06-09).
uint64_t g_apu_pace_cycles_estimate = 0;
uint64_t g_apu_last_sync_cycles = 0;

// Set while the interp816 bridge (interp tier / LLE task scheduler) is driving:
// the bridge advances the SPC itself, per interpreted opcode, by guest master
// cycles (like the faithful oracle) — so the per-touch synthetic catch-up must
// NOT also fire (double-count). Guards rtl_accumulate_apu_catchup below. Only
// the interp path sets it; the compiled steady-state path is unaffected.
int g_interp_apu_driving = 0;

#ifdef SNES_COSIM
/* Shared APU clock knob (common_rtl.h). Cached once; both A/B processes of a
 * same-binary pair must be launched with the same value. */
int cosim_apu_shared_clock(void) {
  static int v = -1;
  if (v < 0) {
    const char *e = getenv("SNES_COSIM_APU_SHARED");
    v = (e && e[0] && e[0] != '0') ? 1 : 0;
  }
  return v;
}
#endif

// Axis-5 off-cue: APU pacing now derives from the recompiler's region-weighted
// MASTER-clock accumulator (g_cpu.master_cycles) instead of the +256-per-touch
// synthetic estimate. g_apu_last_sync_master is the master-clock count at the
// last APU sync; rtl_accumulate_apu_catchup() converts the delta to SPC cycles.
uint64_t g_apu_last_sync_master = 0;
/* Production's frame loop is the stable guest-time ruler: one frame is
 * 357368 SNES master cycles and 17088 SPC cycles in this runtime's 60 Hz
 * model. g_cpu.master_cycles supplies only the within-frame position because
 * its total per frame varies with recompilation coverage. */
static uint64_t g_apu_frame_start_master;
static RtlApuFrameClock g_apu_frame_clock;
static bool g_extended_frame_timing;
static bool g_apu_frame_time_valid;

bool rtl_apu_frame_timeline_active(void) {
  return g_apu_frame_time_valid;
}

double RtlLastFramePeriods(void) {
  return g_extended_frame_timing && g_apu_frame_clock.last_duration
      ? (double)g_apu_frame_clock.last_duration / RTL_APU_CYCLES_PER_FRAME : 1.0;
}

void RtlEnableExtendedFrameTiming(void) {
  g_extended_frame_timing = true;
}

bool rtl_apu_extended_frame_timing(void) {
  return g_extended_frame_timing;
}

void rtl_apu_snapshot_pacing(uint64_t *frame_start_master, uint8_t *frame_time_valid) {
  if (frame_start_master) *frame_start_master = g_apu_frame_start_master;
  if (frame_time_valid) *frame_time_valid = g_apu_frame_time_valid ? 1 : 0;
}

void rtl_apu_restore_pacing(uint64_t frame_start_master, uint8_t frame_time_valid) {
  g_apu_frame_start_master = frame_start_master;
  g_apu_frame_time_valid = frame_time_valid != 0;
}

/* Fast-forward advances the real SPC/DSP state faster than the host device can
 * play it. On the transition back to realtime, buffered PCM represents stale
 * guest time and must not become permanent A/V latency. The short ramp joins
 * the last delivered sample to the first current sample without a hard edge. */
#define RTL_AUDIO_RECOVERY_RAMP 128u
#define RTL_AUDIO_TARGET_NATIVES 2136u /* 4 native blocks, ~67 ms cushion */
static bool g_audio_fast_forward;
static uint32_t g_audio_recovery_frames;
static uint32_t g_audio_recovery_remaining;
static int16 g_audio_recovery_anchor_l;
static int16 g_audio_recovery_anchor_r;
static int16 g_audio_last_output_l;
static int16 g_audio_last_output_r;
static void rtl_sync_apu_frame_boundary(void);

static uint64_t rtl_apu_guest_cycle(void) {
  if (g_extended_frame_timing)
    return rtl_apu_clock_now(&g_apu_frame_clock, g_cpu.master_cycles);
  uint64_t within = g_cpu.master_cycles - g_apu_frame_start_master;
  if (within >= RTL_MASTER_CYCLES_PER_FRAME)
    within = RTL_MASTER_CYCLES_PER_FRAME - 1;
  return (uint64_t)snes_frame_counter * RTL_APU_CYCLES_PER_FRAME +
         within * RTL_APU_CYCLES_PER_FRAME /
             RTL_MASTER_CYCLES_PER_FRAME;
}
// $420D bit 0 (FastROM / MEMSEL): 1 => $80-$FF:$8000-$FFFF code runs fast (6
// master clocks/access) instead of slow (8). Tracked here so emitted blocks in
// the WS2 mirror banks weight their master-cycle charge correctly at runtime.
// SlowROM games (e.g. SMW) never set it and run all code from $00-$3F (speed is
// memsel-independent there), so this stays 0 and the emitted charge is constant.
uint8_t g_memsel = 0;

// Axis-7 determinism: diagnostic per-frame WRAM fingerprint ring. FNV-1a of
// the full 128 KiB g_ram each frame, keyed by frame number. Trace and co-sim
// builds retain the forensic history; production omits both the hash and ring.
#ifndef SNESRECOMP_FRAME_FINGERPRINTS
#define SNESRECOMP_FRAME_FINGERPRINTS 1
#endif
#if SNESRECOMP_FRAME_FINGERPRINTS
uint64_t g_fp_ring[FP_RING];
uint64_t g_fp_max_frame;
static uint64_t fp_fnv1a(const uint8_t *p, size_t n) {
  uint64_t h = 1469598103934665603ULL;
  for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
  return h;
}
#endif

// FILE-backed SaveLoadInfo. snes_saveload calls back into func() once per
// scalar/blob; we route each call to fread/fwrite. Single magic+version
// header lets future format changes be detected.
#define RTL_SAV_MAGIC   0x52544c53u  /* "RTLS" */
/* v4: dropped Dma.pad[7] blob tail.
 * v5: optional game-specific chunk appended after the snes_saveload blob
 *     (RtlGameInfo.state_save_extra/state_load_extra) — e.g. MMX task-slot
 *     resume contexts so a load can rebuild its scheduler fibers from any
 *     game mode or a fresh process. v4 files still load (no chunk).
 * v6: beamMasterLast removed from the snes_saveload region (host-only
 *     timing anchor). v5 files still load via an 8-byte compat skip.
 * v7: manual joypad latch/shift state appended after the existing SNES blob.
 *     Older files initialize that transient serial state to idle.
 * v8: multitap chunk (seats, IOBit lines, per-bank shift counters, latched
 *     automatic-read words). Older files load with no multitap configured,
 *     which is the pre-multitap two-pad machine exactly. */
#define RTL_SAV_VERSION 9u /* Super FX architectural state in cart_saveload. */
/* 4 and 5 described a Snes tail layout this struct no longer has; see
 * snes_saveload(). Loading one would mis-map the interrupt fields, so
 * they are rejected by the header check instead. */
#define RTL_SAV_VERSION_MIN 6u

typedef struct FileSli {
  SaveLoadInfo base;
  FILE *f;
  bool is_save;
  bool error;
} FileSli;

typedef struct MemorySli {
  SaveLoadInfo base;
  uint8 *data;
  size_t capacity;
  size_t position;
  bool is_save;
  bool error;
} MemorySli;

static void file_sli_func(SaveLoadInfo *sli, void *data, size_t n) {
  FileSli *fs = (FileSli *)sli;
  if (fs->error) return;
  size_t got = fs->is_save ? fwrite(data, 1, n, fs->f)
                           : fread(data, 1, n, fs->f);
  if (got != n) fs->error = true;
}

static void memory_sli_func(SaveLoadInfo *sli, void *data, size_t n) {
  MemorySli *memory = (MemorySli *)sli;
  if (memory->error || n > SIZE_MAX - memory->position) {
    memory->error = true;
    return;
  }
  if (memory->data) {
    if (memory->position + n > memory->capacity) {
      memory->error = true;
      return;
    }
    if (memory->is_save)
      memcpy(memory->data + memory->position, data, n);
    else
      memcpy(data, memory->data + memory->position, n);
  } else if (!memory->is_save) {
    memory->error = true;
    return;
  }
  memory->position += n;
}

static bool file_sli_peek(SaveLoadInfo *sli, size_t offset, void *data, size_t n) {
  FileSli *fs = (FileSli *)sli;
  long pos = ftell(fs->f);
  if (fs->is_save || fs->error || pos < 0 || offset > LONG_MAX - (size_t)pos)
    return false;
  if (fseek(fs->f, pos + (long)offset, SEEK_SET)) return false;
  bool ok = fread(data, 1, n, fs->f) == n;
  if (fseek(fs->f, pos, SEEK_SET)) return false;
  return ok;
}
static bool memory_sli_peek(SaveLoadInfo *sli, size_t offset, void *data, size_t n) {
  MemorySli *m = (MemorySli *)sli;
  if (m->is_save || m->error || m->position > m->capacity ||
      offset > m->capacity - m->position || n > m->capacity - m->position - offset)
    return false;
  memcpy(data, m->data + m->position + offset, n);
  return true;
}

size_t RtlStateBytesRemaining(SaveLoadInfo *sli) {
  if (!sli) return SIZE_MAX;
  if (sli->func == memory_sli_func) {
    MemorySli *m = (MemorySli *)sli;
    return !m->is_save && !m->error && m->position <= m->capacity
        ? m->capacity - m->position : SIZE_MAX;
  }
  if (sli->func == file_sli_func) {
    FileSli *f = (FileSli *)sli;
    if (f->is_save || f->error) return SIZE_MAX;
    long pos = ftell(f->f);
    if (pos < 0 || fseek(f->f, 0, SEEK_END)) return SIZE_MAX;
    long end = ftell(f->f);
    if (fseek(f->f, pos, SEEK_SET) || end < pos) return SIZE_MAX;
    return (size_t)(end - pos);
  }
  return SIZE_MAX;
}

/* Host-side state that paces the guest but is not part of it.
 *
 * Shared by the two ways into a fresh machine -- RtlReset (soft reset) and
 * SnesInit (cold boot / rematch). Kept in one place because they diverged:
 * SnesInit reset the guest and left these alone, so a rematch started with the
 * previous session's frame counter and APU anchors and booted to a different
 * state than a first run. */
void rtl_reset_host_pacing(void) {
  snes_frame_counter = 0;
  g_apu_frame_time_valid = false;
  g_apu_frame_clock = (RtlApuFrameClock){0};
  g_apu_frame_start_master = g_cpu.master_cycles;
  g_main_cpu_cycles_estimate = 0;
  g_apu_pace_cycles_estimate = 0;
  g_apu_last_sync_cycles = 0;
  // master_cycles is monotonic across soft reset (RtlReset doesn't re-init
  // g_cpu); anchor the sync pointer to its current value so the first post-reset
  // catch-up sees a zero delta rather than the whole run's accumulated cycles.
  g_apu_last_sync_master = g_cpu.master_cycles;
  snes_mod_audio_stop_all();

  /* The DRAM refresh tax carries a SUB-SCANLINE remainder across frames, and
   * that remainder decides where the next refresh boundary falls -- so it
   * decides how many cycles the first block after a boot is charged.
   *
   * It is a static in the runtime, not part of the Snes, so it survived
   * re-creating the machine. A rematch therefore began mid-refresh-line at
   * whatever phase the previous session happened to stop on: the first frame
   * was charged a different number of cycles than on a first boot, the APU
   * catch-up residual came out different (measured: 0.804 vs 0.752), and tick
   * 0 hashed to a different WRAM and APU state. Two peers that had stopped at
   * different phases could not agree on a boot they had both just performed.
   *
   * Anchored to now and zeroed, which is the state a first boot starts from.
   * This same carry has bitten before: it was the rollback replay divergence
   * that had to be found by diffing .data and .bss. */
  snes_refresh_state_set(0u, g_cpu.master_cycles);
}

static uint64_t s_state_generation;
uint64_t RtlStateGeneration(void) { return s_state_generation; }

void RtlReset(int mode) {
  ++s_state_generation;
  rtl_reset_host_pacing();
  snes_reset(g_snes, true);
  g_snes->beamMasterLast = g_cpu.master_cycles;
  SnesEnterNativeMode();
  ppu_reset(g_ppu);
  if (!(mode & 1))
    memset(g_sram, 0, g_sram_size);

  RtlApuLock();
  g_audio_fast_forward = false;
  rtl_reset_audio_delivery();
  g_audio_recovery_frames = 0;
  g_audio_recovery_remaining = 0;
  g_audio_recovery_anchor_l = 0;
  g_audio_recovery_anchor_r = 0;
  g_audio_last_output_l = 0;
  g_audio_last_output_r = 0;
  g_spc_player->initialize(g_spc_player);
  RtlApuUnlock();
  /* After the hardware, so the title reboots against the reset machine. */
  if (g_rtl_game_info && g_rtl_game_info->hardware_reset)
    g_rtl_game_info->hardware_reset();
}

/* Differential first-divergence trace (docs/MULTI_TIER.md §12a). Env-gated,
 * always-compiled, zero cost when off. Emits per-frame changed bytes of low
 * WRAM ($0000-$1FFF) in the EXACT jsonl shape snesref produces, so the two
 * traces diff directly. Sampled at end-of-frame (after run_frame), mirroring
 * snesref's post-retro_run trace_tick; frame numbering starts at 1 on the
 * first completed frame, matching snesref, so frames align by construction. */
static void recomp_wram_trace_tick(void) {
    static int enabled = -1;
    static FILE *log = NULL;
    static unsigned char prev[0x2000];
    static int primed = 0;
    static unsigned frame = 0;
    if (enabled < 0) {
        const char *p = getenv("SNESRECOMP_WRAM_TRACE_FILE");
        enabled = (p && p[0]) ? 1 : 0;
    }
    if (!enabled) return;
    if (!log) {
        log = fopen(getenv("SNESRECOMP_WRAM_TRACE_FILE"), "a");
        if (!log) { enabled = 0; return; }
    }
    frame++;
    if (!primed) {
        for (int a = 0; a <= 0x1fff; a++) {
            prev[a] = g_ram[a];
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x00\",\"val\":\"0x%02x\"}\n",
                    frame, a, g_ram[a]);
        }
        primed = 1; return;
    }
    for (int a = 0; a <= 0x1fff; a++) {
        unsigned char v = g_ram[a];
        if (v != prev[a]) {
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x%02x\",\"val\":\"0x%02x\"}\n",
                    frame, a, prev[a], v);
            prev[a] = v;
        }
    }
    if ((frame % 30) == 0) fflush(log);
}

/* APU/SPC-RAM variant of the differential trace (co-sim step 1: audio hunt).
 * Emits per-frame changed bytes of the full 64K SPC RAM (g_snes->apu->ram) in
 * the SAME jsonl shape as the WRAM trace, so it aligns 1:1 against snesref's
 * bsnes SPC-RAM trace (retro memory id 0x100) via align_diff.py --size 0x10000.
 * The recomp runs a real SPC700 core (LakeSnes-derived apu/spc/dsp); only the
 * IPL upload handshake is HLE'd, so apu->ram reflects the real uploaded SPC
 * program plus the SPC700's runtime writes -- directly comparable to bsnes's
 * dsp.apuram. Env-gated (SNESRECOMP_APURAM_TRACE_FILE), zero cost when off. */
static void recomp_apuram_trace_tick(void) {
    static int enabled = -1;
    static FILE *log = NULL;
    static unsigned char prev[0x10000];
    static int primed = 0;
    static unsigned frame = 0;
    extern Snes *g_snes;
    if (enabled < 0) {
        const char *p = getenv("SNESRECOMP_APURAM_TRACE_FILE");
        enabled = (p && p[0]) ? 1 : 0;
    }
    if (!enabled) return;
    if (!g_snes || !g_snes->apu) return;
    if (!log) {
        log = fopen(getenv("SNESRECOMP_APURAM_TRACE_FILE"), "a");
        if (!log) { enabled = 0; return; }
    }
    const unsigned char *ram = g_snes->apu->ram;
    frame++;
    if (!primed) {
        for (int a = 0; a <= 0xffff; a++) {
            prev[a] = ram[a];
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x00\",\"val\":\"0x%02x\"}\n",
                    frame, a, ram[a]);
        }
        primed = 1; return;
    }
    for (int a = 0; a <= 0xffff; a++) {
        unsigned char v = ram[a];
        if (v != prev[a]) {
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x%02x\",\"val\":\"0x%02x\"}\n",
                    frame, a, prev[a], v);
            prev[a] = v;
        }
    }
    if ((frame % 30) == 0) fflush(log);
}

/* S-DSP register-file variant of the differential trace (co-sim audio hunt).
 * Emits per-frame changed bytes of the 128-byte DSP register file
 * (g_snes->apu->dsp->ram, the $00-$7F mirror incl. VxPITCHL/H, KON/KOFF, ADSR,
 * echo). Same jsonl shape as the WRAM/APU-RAM traces => aligns 1:1 against
 * snesref's bsnes DSP-reg trace (retro memory id 0x101) via align_diff.py
 * --size 0x80. This is the state where "pitch" literally lives, so a persistent
 * divergence here (esp. VxPITCH) localizes an off-pitch bug to driver-writes vs
 * DSP synthesis. Env-gated (SNESRECOMP_DSPREG_TRACE_FILE). */
static void recomp_dspreg_trace_tick(void) {
    static int enabled = -1;
    static FILE *log = NULL;
    static unsigned char prev[0x80];
    static int primed = 0;
    static unsigned frame = 0;
    extern Snes *g_snes;
    if (enabled < 0) {
        const char *p = getenv("SNESRECOMP_DSPREG_TRACE_FILE");
        enabled = (p && p[0]) ? 1 : 0;
    }
    if (!enabled) return;
    if (!g_snes || !g_snes->apu || !g_snes->apu->dsp) return;
    if (!log) {
        log = fopen(getenv("SNESRECOMP_DSPREG_TRACE_FILE"), "a");
        if (!log) { enabled = 0; return; }
    }
    const unsigned char *r = g_snes->apu->dsp->ram;
    frame++;
    if (!primed) {
        for (int a = 0; a < 0x80; a++) {
            prev[a] = r[a];
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x00\",\"val\":\"0x%02x\"}\n",
                    frame, a, r[a]);
        }
        primed = 1; return;
    }
    for (int a = 0; a < 0x80; a++) {
        unsigned char v = r[a];
        if (v != prev[a]) {
            fprintf(log, "{\"f\":%u,\"adr\":\"0x%05x\",\"old\":\"0x%02x\",\"val\":\"0x%02x\"}\n",
                    frame, a, prev[a], v);
            prev[a] = v;
        }
    }
    if ((frame % 30) == 0) fflush(log);
}

/* Native DSP output-stream capture (co-sim audio hunt). Reads the samples the
 * S-DSP PRODUCED this frame straight from dsp->sampleBuffer (the always-on ring,
 * per CLAUDE.md ring-buffer rule) using the monotonic sampleWrite counter, and
 * appends them as raw s16 stereo PCM (~32040 Hz, pre-host-resample) — the exact
 * game-agnostic audio the recomp generates, to align against bsnes's
 * BSNES_COSIM_DSPOUT stream. Env-gated (SNESRECOMP_DSPOUT). */
static void recomp_dspout_capture(void) {
    static int enabled = -1;
    static FILE *f = NULL;
    static uint32_t prev_write = 0;
    static int primed = 0;
    extern Snes *g_snes;
    if (enabled < 0) {
        const char *p = getenv("SNESRECOMP_DSPOUT");
        enabled = (p && p[0]) ? 1 : 0;
    }
    if (!enabled) return;
    if (!g_snes || !g_snes->apu || !g_snes->apu->dsp) return;
    if (!f) { f = fopen(getenv("SNESRECOMP_DSPOUT"), "wb"); if (!f) { enabled = 0; return; } }
    Dsp *dsp = g_snes->apu->dsp;
    uint32_t w = dsp->sampleWrite;
    if (!primed) { prev_write = w; primed = 1; return; }
    for (uint32_t s = prev_write; s != w; s++) {
        uint32_t idx = (s & (DSP_SAMPLE_RING - 1)) * 2;
        int16 pair[2] = { dsp->sampleBuffer[idx], dsp->sampleBuffer[idx + 1] };
        fwrite(pair, sizeof(int16), 2, f);
    }
    prev_write = w;
}

/* ── Multiplayer seats ───────────────────────────────────────────────────
 * See common_rtl.h. The device model lives in snes/joypad.c; this is the
 * host-facing surface plus the launch-time environment override.
 */

/* Opposing directions cannot be held on a real d-pad, and guest code is
 * entitled to assume it. RtlRunFrame has always filtered seats 0 and 1;
 * every other seat gets the same treatment. */
static uint16 rtl_filter_dpad(uint16 buttons) {
  if ((buttons & 0x30u) == 0x30u) buttons ^= 0x30u;   /* up + down */
  if ((buttons & 0xc0u) == 0xc0u) buttons ^= 0xc0u;   /* left + right */
  return (uint16)(buttons & 0x0fffu);
}

void RtlSetPadState(int slot, uint16 buttons) {
  buttons = rtl_filter_dpad(buttons);
  joypad_set_pad(slot, buttons);
  /* Seats 0 and 1 also live in the two fields the rest of the runtime reads
   * directly, so a game may drive them through either door. */
  if (g_snes && slot == 0) g_snes->input1_currentState = buttons;
  if (g_snes && slot == 1) g_snes->input2_currentState = buttons;
}

uint16 RtlGetPadState(int slot) { return joypad_get_pad(slot); }
void RtlSetPadConnected(int slot, int connected) {
  joypad_set_connected(slot, connected);
}
int RtlGetPadConnected(int slot) { return joypad_get_connected(slot); }
void RtlSetMultitap(int port, int enabled) {
  joypad_set_multitap(port, enabled);
}
int RtlGetMultitap(int port) { return joypad_get_multitap(port); }
int RtlPlayerCount(void) { return joypad_player_count(); }

/* SNES_MULTITAP=port1|port2|both|off. Applied once, before the first frame,
 * so a launcher or a soak script can turn a tap on without a rebuild. It
 * overrides whatever the game asked for — an explicit launch flag outranks a
 * built-in default. */
static void RtlApplyMultitapEnv(void) {
  static int applied = 0;
  const char *v;
  if (applied) return;
  applied = 1;
  v = getenv("SNES_MULTITAP");
  if (!v || !v[0]) return;
  if (!strcmp(v, "off") || !strcmp(v, "none") || !strcmp(v, "0")) {
    RtlSetMultitap(0, 0); RtlSetMultitap(1, 0);
  } else if (!strcmp(v, "port1") || !strcmp(v, "1")) {
    RtlSetMultitap(0, 1); RtlSetMultitap(1, 0);
  } else if (!strcmp(v, "port2") || !strcmp(v, "2")) {
    RtlSetMultitap(0, 0); RtlSetMultitap(1, 1);
  } else if (!strcmp(v, "both") || !strcmp(v, "8")) {
    RtlSetMultitap(0, 1); RtlSetMultitap(1, 1);
  } else {
    fprintf(stderr,
            "SNES_MULTITAP=%s not understood "
            "(expected port1, port2, both, or off) — ignoring\n", v);
    return;
  }
  fprintf(stderr, "snesrecomp: multitap port1=%d port2=%d (%d seats)\n",
          RtlGetMultitap(0), RtlGetMultitap(1), RtlPlayerCount());
}

bool RtlRunFrame(uint32 inputs) {
#ifdef SNES_COSIM
  /* Co-sim (dev/diagnostics only): connect the coordinator once, before the
   * first frame executes. Boot ran deterministically already; the co-sim
   * compares from frame 1 onward. SNES_COSIM_OFF=1 skips the engine entirely
   * (used by the harness standalone mode: no coordinator, free-run). */
  { static int s_cosim_started = 0;
    const char *s_co = getenv("SNES_COSIM_OFF");
    if (!s_cosim_started && !(s_co && s_co[0] && s_co[0] != '0')) {
      s_cosim_started = 1;
      cosim_init();
    } else {
      s_cosim_started = 1;
    }
  }
#endif
  // Avoid up/down and left/right from being pressed at the same time
  if ((inputs & 0x30) == 0x30) inputs ^= 0x30;
  if ((inputs & 0xc0) == 0xc0) inputs ^= 0xc0;
  // Player2
  if ((inputs & 0x30000) == 0x30000) inputs ^= 0x30000;
  if ((inputs & 0xc0000) == 0xc0000) inputs ^= 0xc0000;

  RtlApplyMultitapEnv();

  g_snes->input1_currentState = inputs & 0xfff;
  g_snes->input2_currentState = (inputs >> 12) & 0xfff;
  /* Seats 0 and 1 stay owned by the packed word; seats 2..7, when a multitap
   * is configured, keep whatever RtlSetPadState last put there. */
  joypad_set_pad(0, (uint16)(inputs & 0xfff));
  joypad_set_pad(1, (uint16)((inputs >> 12) & 0xfff));

  /* Establish the guest timestamp origin before any frame code can touch an
   * APU port. Host turbo changes how quickly frames arrive, not their guest
   * duration. */
  g_apu_frame_start_master = g_cpu.master_cycles;
  g_apu_frame_time_valid = true;
  rtl_apu_clock_begin(&g_apu_frame_clock, g_cpu.master_cycles);
  WatchdogFrameStart();
  // Watchdog guard: WatchdogCheck() (called per-block in v2 gen) longjmps
  // here when a frame exceeds 5s, so an infinite loop in recompiled code
  // doesn't freeze the runtime indefinitely. Without this setjmp the
  // longjmp would dereference an uninitialized jmp_buf and crash.
  if (setjmp(g_watchdog_jmp) == 0) {
    g_rtl_game_info->run_frame();
  }
#ifdef SNES_COSIM
  /* DETERMINISTIC AUDIO CONSUMER (SNES_COSIM_AUDIO=1). Production is paced by the
   * guest frame (rtl_sync_apu_frame_boundary), NOT by the audio device. An
   * earlier design had RtlRenderAudio cycle the SPC for its own shortfall so the
   * consumer set the rate; that is retired — the callback only consumes.
   * Headless has no audio thread, so the SPC starves (~40x slow). Here we MODEL
   * the consumer deterministically: drain one frame of samples at the exact SNES
   * rate (32040 / 60.0988 = 533.12 samples/frame). This paces the SPC to the
   * correct tempo, reproduces the producer(CPU-catchup)/consumer(this) dynamics
   * incl. any ring drops, and stays fully deterministic (no host thread). The
   * dev dump's samples= then reflects real production audio behaviour. */
  {
    static int s_audio = -1;
    if (s_audio < 0) { const char *e = getenv("SNES_COSIM_AUDIO");
                       s_audio = (e && e[0] && e[0] != '0') ? 1 : 0; }
    if (s_audio && !rtl_netplay_locks_audio()) {
      static double s_acc = 0.0;
      static int16 s_buf[1024 * 2];
      s_acc += 32040.0 / 60.0988;           /* SNES native audio samples per frame */
      int want = (int)s_acc; s_acc -= (double)want;
      while (want > 0) {
        int chunk = want > 1024 ? 1024 : want;
        RtlRenderAudio(s_buf, chunk, 2);     /* self-balances SPC production to demand */
        want -= chunk;
      }
    }
  }
#endif
#ifdef SNES_COSIM
  /* Co-sim fidelity (env-gated for A/B): production's main loop calls
   * draw_ppu_frame() AFTER run_frame() every frame — PPU line render + HDMA +
   * raster-IRQ simulation. The headless harness omits it, so the raster IRQ
   * never fires and IRQ-managed guest state diverges from the oracle (e.g. MMX's
   * $0BA0 raster-ack flag stays governed only by the bootstrap clear). Running it
   * here makes the co-sim model the full production frame; the per-frame trace/
   * hash below then capture post-IRQ state, matching bsnes's frame boundary. */
  { static int s_draw = -1;
    if (s_draw < 0) { const char *e = getenv("SNES_COSIM_DRAW_PPU");
                      /* Default ON (faithful full production frame); opt-out with =0. */
                      s_draw = (e && e[0] == '0') ? 0 : 1; }
    if (s_draw && g_rtl_game_info && g_rtl_game_info->draw_ppu_frame)
      g_rtl_game_info->draw_ppu_frame();
  }
#endif
  // If g_watchdog_tripped is set, frame was abandoned mid-execution;
  // continue to the next frame so the user can interrupt cleanly.
  if (g_framedump_callback)
    g_framedump_callback(snes_frame_counter, g_ram);
  {
    extern void debug_server_record_frame(int);
    debug_server_record_frame(snes_frame_counter);
  }

  /* Always-on PPU/DMA observability: snapshot the live PPU once per frame
   * (forced-blank/brightness, screen-enable, CGRAM/VRAM occupancy). */
  ppudma_frame_snapshot(snes_frame_counter);

  recomp_wram_trace_tick();   /* differential first-divergence trace (env-gated) */
  recomp_apuram_trace_tick(); /* APU/SPC-RAM differential trace (audio hunt, env-gated) */
  recomp_dspreg_trace_tick(); /* S-DSP register-file differential trace (env-gated) */
  recomp_dspout_capture();    /* native DSP output-stream capture (env-gated) */

  /* Axis-7 diagnostic determinism fingerprint. */
#if SNESRECOMP_FRAME_FINGERPRINTS
  g_fp_ring[snes_frame_counter & (FP_RING - 1)] = fp_fnv1a(g_ram, sizeof(g_ram));
  g_fp_max_frame = (uint64_t)snes_frame_counter;
#endif

  snes_frame_counter++;
  Tier2CoverageTick(snes_frame_counter);
  /* Every runner client gets the same guest-frame/APU coupling. Presentation
   * code may opt into fast-forward PCM recovery separately, but cannot omit
   * the emulation clock.
   *
   * Except on a speculative frame, which the player never hears and which is
   * about to be rewound. The SPC's executed-cycle counter (Apu.portClock and
   * the port anchors beside it) sits AFTER the region apu_saveload
   * serialises, deliberately, because it is host-side lead: a rollback does
   * not put it back. So running the SPC for a frame that gets rewound
   * advances the audio chip PERMANENTLY, and the guest's next real frame
   * finds a handshake further along than it should be. Measured in Super
   * Metroid with run-ahead: the SPC had executed 73% more cycles after 232
   * frames, and the game's sound-effect queue stepped a frame early on 21
   * frames in 1,200. Not running it is both the correct answer and the
   * cheaper one -- the audio from those frames was discarded regardless. */
  if (!g_rtl_speculative_frame)
    rtl_sync_apu_frame_boundary();

#if SNESRECOMP_ENABLE_MODS
  /* Not on a speculative frame: the player never sees it, so a mod counting
   * frames must not count it. See RtlSetSpeculativeFrame in common_rtl.h. */
  if (!g_rtl_speculative_frame)
    snes_mod_runtime_frame_tick_c();
#endif

#ifdef SNES_COSIM
  /* Frame-keyed checkpoint: snapshot full state + park for the coordinator. */
  cosim_frame();
#endif

  /* Axis-2 soak instrumentation: env-gated FPS heartbeat to stderr. Counts
   * frames completed per wall-clock second (the frame loop caps at ~60 fps, so
   * ~60 = full speed; a sustained dip = slowdown). When off, only the cached
   * branch remains; no clock or output work runs. Enable by setting
   * SNESRECOMP_FPS. */
  if (rtl_fps_heartbeat_enabled()) {
    static long s_last_sec = 0;
    static int  s_frames = 0;
    long now = (long)time(NULL);
    s_frames++;
    if (s_last_sec == 0) {
      s_last_sec = now;
    } else if (now != s_last_sec) {
      fprintf(stderr, "[fps] %d fps (frame=%d)\n", s_frames, snes_frame_counter);
      s_frames = 0;
      s_last_sec = now;
    }
  }

#ifdef SNESRECOMP_NET_ROLLBACK
  /* Offline rollback self-check. No-op unless SNESRECOMP_RB_PROBE is set;
   * see snes_rb_probe.c for why the runner needs one at all. */
  snes_rb_probe_after_frame(inputs);
#endif

  return false;
}

bool RtlSaveSnapshot(const char *filename) {
  FILE *f = fopen(filename, "wb");
  if (!f) {
    printf("Failed fopen for save: %s\n", filename);
    return false;
  }
  uint32 hdr[2] = { RTL_SAV_MAGIC, RTL_SAV_VERSION };
  bool header_ok = fwrite(hdr, sizeof(hdr), 1, f) == 1;
  RtlApuLock();
  FileSli fs = { { &file_sli_func }, f, true, !header_ok };
  if (header_ok) {
    snes_saveload_set_version(RTL_SAV_VERSION);
    snes_saveload(g_snes, &fs.base);
  }
  /* v5: game-specific chunk (task-slot resume contexts etc.). Streamed
   * through the same FileSli so the format stays one linear blob. */
  if (g_rtl_game_info && g_rtl_game_info->state_save_extra)
    g_rtl_game_info->state_save_extra(&fs.base);
  RtlApuUnlock();
  if (fs.error) printf("Save write error: %s\n", filename);
  bool close_ok = fclose(f) == 0;
  return !fs.error && close_ok;
}

bool RtlLoadSnapshot(const char *filename) {
  FILE *f = fopen(filename, "rb");
  if (!f)
    return false;
  uint32 hdr[2];
  if (fread(hdr, sizeof(hdr), 1, f) != 1
      || hdr[0] != RTL_SAV_MAGIC
      || hdr[1] < RTL_SAV_VERSION_MIN || hdr[1] > RTL_SAV_VERSION
      || (g_rtl_game_info && hdr[1] < g_rtl_game_info->minimum_state_version)) {
    printf("Save file %s: bad magic/version (legacy StateRecorder format no longer supported)\n", filename);
    fclose(f);
    return false;
  }
  RtlApuLock();
  FileSli fs = { { &file_sli_func, &file_sli_peek }, f, false, false };
  snes_saveload_set_version(hdr[1]);
  snes_saveload(g_snes, &fs.base);
  /* v5+: an optional game-specific chunk follows the guest blob. Only call
   * the loader when trailing bytes remain so older v5 snapshots created by
   * games without an extra chunk remain readable. */
  if (hdr[1] >= 5 && g_rtl_game_info && g_rtl_game_info->state_load_extra) {
    long pos = ftell(f);
    if (pos >= 0 && fseek(f, 0, SEEK_END) == 0) {
      long end = ftell(f);
      if (fseek(f, pos, SEEK_SET) == 0 && end > pos)
        g_rtl_game_info->state_load_extra(&fs.base, hdr[1]);
    }
  }
  if (!fs.error) rtl_reset_audio_delivery();
  RtlApuUnlock();
  fclose(f);
  if (fs.error) {
    printf("Save read error: %s\n", filename);
    return false;
  }
  g_snes->beamMasterLast = g_cpu.master_cycles;
  snes_mod_audio_stop_all();
  PpuResetWidescreenOamHistory(g_snes->ppu);
  /* Post-load reconciliation: host-side execution state (fibers, HLE
   * scheduler bookkeeping) cannot live in the guest snapshot; give the
   * game one hook to rebuild it against the freshly restored WRAM. */
  if (g_rtl_game_info && g_rtl_game_info->on_state_loaded)
    g_rtl_game_info->on_state_loaded(hdr[1]);
  ++s_state_generation;
  return true;
}

size_t RtlSaveSnapshotToMemory(void *data, size_t capacity) {
  MemorySli memory = {
    { &memory_sli_func }, (uint8 *)data, capacity, 0, true, false
  };
  uint32 hdr[2] = { RTL_SAV_MAGIC, RTL_SAV_VERSION };
  memory_sli_func(&memory.base, hdr, sizeof hdr);
  RtlApuLock();
  snes_saveload_set_version(RTL_SAV_VERSION);
  snes_saveload(g_snes, &memory.base);
  if (g_rtl_game_info && g_rtl_game_info->state_save_extra)
    g_rtl_game_info->state_save_extra(&memory.base);
  RtlApuUnlock();
  return memory.error ? 0 : memory.position;
}

bool RtlLoadSnapshotFromMemory(const void *data, size_t size) {
  if (!data || size < sizeof(uint32) * 2) return false;
  uint32 hdr[2];
  memcpy(hdr, data, sizeof hdr);
  if (hdr[0] != RTL_SAV_MAGIC || hdr[1] < RTL_SAV_VERSION_MIN ||
      hdr[1] > RTL_SAV_VERSION ||
      (g_rtl_game_info && hdr[1] < g_rtl_game_info->minimum_state_version))
    return false;

  MemorySli memory = {
    { &memory_sli_func, &memory_sli_peek }, (uint8 *)data, size, sizeof hdr, false, false
  };
  RtlApuLock();
  snes_saveload_set_version(hdr[1]);
  snes_saveload(g_snes, &memory.base);
  /* Match file load: only consume a game chunk when trailing bytes remain.
   * Always calling state_load_extra at EOF zero-fills the chunk (short-read
   * sets error on MemorySli, but games that memset-then-read still see
   * magic 0 and cold-boot into a hybrid WRAM/RESET state). */
  if (hdr[1] >= 5 && g_rtl_game_info && g_rtl_game_info->state_load_extra &&
      memory.position < size && !memory.error)
    g_rtl_game_info->state_load_extra(&memory.base, hdr[1]);
  if (!memory.error) rtl_reset_audio_delivery();
  RtlApuUnlock();
  if (memory.error) return false;
  g_snes->beamMasterLast = g_cpu.master_cycles;
  snes_mod_audio_stop_all();
  PpuResetWidescreenOamHistory(g_snes->ppu);
  if (g_rtl_game_info && g_rtl_game_info->on_state_loaded)
    g_rtl_game_info->on_state_loaded(hdr[1]);
  ++s_state_generation;
  return true;
}

/* ── Rollback snapshots ──────────────────────────────────────────────────
 * See common_rtl.h for why the guest blob alone is not a rollback snapshot.
 */

#define RTL_RB_RESIDUE_MAGIC 0x53524252u /* 'RBRS' */
#define RTL_RB_RESIDUE_VERSION 6u

typedef struct RtlRollbackResidue {
  uint32 magic;
  uint32 version;
  CpuState cpu;              /* ram pointer is preserved, not restored */
  ApuPortSched apu_port;
  uint64_t beam_master_last;
  uint64_t apu_pace_cycles_estimate;
  uint64_t apu_last_sync_cycles;
  uint64_t apu_last_sync_master;
  uint64_t apu_frame_start_master;
  uint64_t main_cpu_cycles_estimate;
  int      frame_counter;
  uint8    apu_frame_time_valid;
  uint8    pad[3];
  /* v2: the interpreter bridge's cross-frame execution state. See
   * interp_bridge.h — without it a replayed frame burns a different number of
   * master cycles than the frame it replaces. */
  uint8    interp[1024];   /* sized against interp_bridge_rb_state_size() */
  /* v3: guest hardware state that lives in host globals rather than in the
   * Snes struct, so snes_saveload never carried it.
   *   memsel        $420D FastROM select. bridge_region_speed charges 6 vs 8
   *                 master clocks per bus access in banks $80-FF off this one
   *                 bit, so a rewind that left it on the discarded timeline
   *                 re-ran the identical code for a different number of
   *                 cycles — which is exactly the observed divergence: hPos,
   *                 apuCatchupCycles and autoJoyTimer move while guest memory
   *                 stays byte-identical.
   *   last_hdmaen   $420C shadow the raster journal reads.
   *   interp_apu_driving  suppresses the per-touch APU catch-up.
   * cosim_state.c already hashes g_memsel as guest state; the rollback path
   * simply never did. */
  uint8    memsel;
  uint8    last_hdmaen;
  uint8    interp_apu_driving;
  uint8    pad_v3;
  /* v4: the DRAM refresh tax's carry. See snes_refresh_state_get. */
  uint64_t refresh_phase;
  uint64_t refresh_charged_upto;
  /* v5: Dma.hdmaPendingInit -- the set of channels the CPU switched on this
   * frame that still owe their one-slot HDMA table initialization.
   *
   * It sits outside dma_saveload's range on purpose (see dma.h), which is
   * correct for a savestate and wrong for a rollback: a rollback snapshot is
   * taken BETWEEN the CPU half of a frame (RtlRunFrame) and the render half
   * that runs dma_doHdma (draw_ppu_frame), so the mask is live across exactly
   * the boundary run-ahead rewinds over. Left out, run-ahead's speculative
   * frame consumed the pending bits, the restore did not put them back, and
   * the real frame's dma_doHdma then skipped the table init for every channel
   * the CPU had just enabled -- wrong tableAdr/repCount/doTransfer for the
   * rest of the frame, i.e. a corrupted raster split. Measured on Gundam
   * Wing's pre-fight screen, the one dma_doHdma's own comment cites. */
  uint8    hdma_pending_init;
  uint8    pad_v5[7];
  /* v6: the PPU's within-frame state -- the OAM write port (oamAdr,
   * oamInHigh, oamSecondWrite, oamBuffer) and the widescreen OBJ motion
   * classifier. Same shape of bug as hdma_pending_init above and found the
   * same way: ppu_saveload's window stops at cgwsel, which is right for a
   * frame-boundary savestate (ppu_handleVblank reloads the OAM port from
   * oamaddl/oamaddh) and wrong for a mid-frame rollback. See ppu.h. */
  PpuRollbackResidue ppu_rb;
} RtlRollbackResidue;

size_t RtlRollbackSnapshotBound(void) {
  /* Guest blob upper bound + residue. The guest blob is WRAM (128 KiB) +
   * APU RAM (64 KiB) + DSP (incl. the 32 KiB output ring) + PPU VRAM/CGRAM/OAM
   * (~64 KiB) + cart SRAM and coprocessor RAM; 1 MiB clears all of it with
   * room for a game's state_save_extra chunk. A game that also puts its
   * execution position in (a fiber's live stack) adds its own bound, which
   * grows and shrinks with the guest's call depth. */
  size_t exec = 0;
  if (g_rtl_game_info && g_rtl_game_info->exec_state_bound)
    exec = g_rtl_game_info->exec_state_bound();
  return (1u << 20) + sizeof(uint32) + exec + sizeof(RtlRollbackResidue);
}

/* ── resync hooks ─────────────────────────────────────────────────────────
 * Each group of host state that a rollback restore must put back is owned by
 * a named pair, in the file that owns the state. psxrecomp does the same with
 * its *_resync_after_restore() family; the point is that a subsystem author
 * has an obvious place to look, and the roll-call below reads as a list of
 * subsystems rather than a pile of field assignments. */

/* APU pacing: how much guest time the SPC has been credited. Host accounting,
 * so snes_saveload never carried it, but the guest polls APU ports and
 * branches on what it reads. */
static void rtl_apu_pace_resync_get(uint64_t *pace, uint64_t *last_sync,
                                    uint64_t *last_master, uint64_t *frame_start,
                                    uint64_t *main_cycles, uint8 *time_valid) {
  *pace = g_apu_pace_cycles_estimate;
  *last_sync = g_apu_last_sync_cycles;
  *last_master = g_apu_last_sync_master;
  *frame_start = g_apu_frame_start_master;
  *main_cycles = g_main_cpu_cycles_estimate;
  *time_valid = g_apu_frame_time_valid ? 1u : 0u;
}

static void rtl_apu_pace_resync_set(uint64_t pace, uint64_t last_sync,
                                    uint64_t last_master, uint64_t frame_start,
                                    uint64_t main_cycles, uint8 time_valid) {
  g_apu_pace_cycles_estimate = pace;
  g_apu_last_sync_cycles = last_sync;
  g_apu_last_sync_master = last_master;
  g_apu_frame_start_master = frame_start;
  g_main_cpu_cycles_estimate = main_cycles;
  g_apu_frame_time_valid = time_valid != 0;
}

/* MMIO shadows: guest hardware state that happens to live in host globals
 * rather than in the Snes struct, which is exactly why snes_saveload missed
 * it. g_memsel ($420D FastROM) decides 6 vs 8 master clocks per bus access in
 * banks $80-FF, so losing it re-runs identical code for a different number of
 * cycles. cosim_state.c already hashes it as guest state. */
static void rtl_mmio_shadow_resync_get(uint8 *memsel, uint8 *hdmaen,
                                       uint8 *apu_driving) {
  *memsel = g_memsel;
  *hdmaen = g_snesrecomp_last_hdmaen;
  *apu_driving = (uint8)(g_interp_apu_driving ? 1 : 0);
}

static void rtl_mmio_shadow_resync_set(uint8 memsel, uint8 hdmaen,
                                       uint8 apu_driving) {
  g_memsel = memsel;
  g_snesrecomp_last_hdmaen = hdmaen;
  g_interp_apu_driving = apu_driving ? 1 : 0;
}

/*
 * THE CONTRACT. Everything a replayed frame reads must be restored here, or
 * the replay burns different cycles than the frame it replaces and the peers
 * fork. Guest memory is NOT the boundary: the defect that cost the most in
 * this port was s_refresh_phase, a sub-scanline remainder in the DRAM refresh
 * tax, with WRAM byte-identical throughout.
 *
 * Adding host state to the frame path? Add it to a resync pair above (or to
 * the owning subsystem's header, as interp_bridge and common_cpu_infra do),
 * then to BOTH functions below, then bump RTL_RB_RESIDUE_VERSION. The
 * _Static_assert on sizeof exists to stop that being silent.
 *
 * The check is mechanical, not a code review: SNESRECOMP_RB_PROBE=25:3 runs
 * save/replay/restore/replay in one process and reports the first divergence,
 * and SNESRECOMP_RB_PROBE_STATICS=1 names the carrier by address when it
 * finds one. Run it after touching anything in the frame path.
 */
static void rtl_rb_residue_capture(RtlRollbackResidue *r) {
  memset(r, 0, sizeof(*r));
  r->magic = RTL_RB_RESIDUE_MAGIC;
  r->version = RTL_RB_RESIDUE_VERSION;
  r->cpu = g_cpu;
  apu_port_sched_save(g_snes->apu, &r->apu_port);
  r->beam_master_last = g_snes->beamMasterLast;
  r->frame_counter = snes_frame_counter;
  rtl_apu_pace_resync_get(&r->apu_pace_cycles_estimate,
                          &r->apu_last_sync_cycles, &r->apu_last_sync_master,
                          &r->apu_frame_start_master,
                          &r->main_cpu_cycles_estimate,
                          &r->apu_frame_time_valid);
  rtl_mmio_shadow_resync_get(&r->memsel, &r->last_hdmaen,
                             &r->interp_apu_driving);
  snes_refresh_state_get(&r->refresh_phase, &r->refresh_charged_upto);
  assert(interp_bridge_rb_state_size() <= sizeof(r->interp));
  interp_bridge_rb_state_save(r->interp);
  r->hdma_pending_init = dma_hdma_pending_init_get(g_snes->dma);
  ppu_rb_residue_get(g_snes->ppu, &r->ppu_rb);
}

static void rtl_rb_residue_apply(const RtlRollbackResidue *r) {
  uint8 *ram_ptr = g_cpu.ram;
  g_cpu = r->cpu;
  g_cpu.ram = ram_ptr; /* host pointer, not simulation state */
  apu_port_sched_restore(g_snes->apu, &r->apu_port);
  g_snes->beamMasterLast = r->beam_master_last;
  snes_frame_counter = r->frame_counter;
  rtl_apu_pace_resync_set(r->apu_pace_cycles_estimate, r->apu_last_sync_cycles,
                          r->apu_last_sync_master, r->apu_frame_start_master,
                          r->main_cpu_cycles_estimate, r->apu_frame_time_valid);
  rtl_mmio_shadow_resync_set(r->memsel, r->last_hdmaen,
                             r->interp_apu_driving);
  snes_refresh_state_set(r->refresh_phase, r->refresh_charged_upto);
  interp_bridge_rb_state_load(r->interp);
  dma_hdma_pending_init_set(g_snes->dma, r->hdma_pending_init);
  ppu_rb_residue_set(g_snes->ppu, &r->ppu_rb);
}

static RtlRollbackResidue s_loaded_execution;
static bool s_loaded_execution_valid;

void RtlSaveExecutionState(SaveLoadInfo *sli) {
  RtlRollbackResidue r;
  rtl_rb_residue_capture(&r);
  r.cpu.ram = NULL; /* Never persist a process address. */
  uint32 size = sizeof(r);
  sli->func(sli, &size, sizeof(size));
  sli->func(sli, &r, sizeof(r));
  cx4_saveload_clock(g_snes->cart->cx4, sli);
}

bool RtlLoadExecutionState(SaveLoadInfo *sli) {
  uint32 size = 0;
  s_loaded_execution_valid = false;
  sli->func(sli, &size, sizeof(size));
  if (size != sizeof(s_loaded_execution)) return false;
  memset(&s_loaded_execution, 0, sizeof(s_loaded_execution));
  sli->func(sli, &s_loaded_execution, sizeof(s_loaded_execution));
  cx4_saveload_clock(g_snes->cart->cx4, sli);
  return s_loaded_execution_valid =
      s_loaded_execution.magic == RTL_RB_RESIDUE_MAGIC &&
      s_loaded_execution.version == RTL_RB_RESIDUE_VERSION;
}

void RtlApplyExecutionState(void) {
  if (s_loaded_execution_valid) rtl_rb_residue_apply(&s_loaded_execution);
  s_loaded_execution_valid = false;
}

/* Layout: [guest blob][game execution state][its length, u32][residue].
 * The residue stays last so the load can find it without a directory, and the
 * execution chunk carries its own length just before it for the same reason.
 * A game with no exec_state_save writes a zero length, which is what every
 * title that has no fiber to rewind does. */
size_t RtlRollbackSaveToMemory(void *data, size_t capacity) {
  size_t guest, used;
  uint32 exec_len = 0;
  RtlRollbackResidue residue;

  if (!data || !g_snes)
    return 0;
  guest = RtlSaveSnapshotToMemory(data, capacity);
  if (guest == 0)
    return 0;
  used = guest;
  if (capacity < used + sizeof(exec_len) + sizeof(residue))
    return 0;

  if (g_rtl_game_info && g_rtl_game_info->exec_state_save) {
    size_t room = capacity - used - sizeof(exec_len) - sizeof(residue);
    size_t n = g_rtl_game_info->exec_state_save((uint8 *)data + used, room);
    if (n == 0)
      return 0;   /* the game could not put its position in; no snapshot */
    exec_len = (uint32)n;
    used += n;
  }
  memcpy((uint8 *)data + used, &exec_len, sizeof(exec_len));
  used += sizeof(exec_len);

  RtlApuLock();
  rtl_rb_residue_capture(&residue);
  RtlApuUnlock();
  memcpy((uint8 *)data + used, &residue, sizeof(residue));
  return used + sizeof(residue);
}

bool RtlRollbackLoadFromMemory(const void *data, size_t size) {
  RtlRollbackResidue residue;
  DspOutputRing ring;
  size_t guest;
  uint32 exec_len = 0;
  bool ok;

  if (!data || !g_snes || size <= sizeof(residue) + sizeof(exec_len))
    return false;
  guest = size - sizeof(residue);
  memcpy(&residue, (const uint8 *)data + guest, sizeof(residue));
  if (residue.magic != RTL_RB_RESIDUE_MAGIC ||
      residue.version != RTL_RB_RESIDUE_VERSION)
    return false;
  guest -= sizeof(exec_len);
  memcpy(&exec_len, (const uint8 *)data + guest, sizeof(exec_len));
  if (exec_len > guest)
    return false;
  guest -= exec_len;

  /* The audio output ring belongs to the live consumer, not to the tick we
   * are rewinding to. Lift it out around the guest blob. */
  RtlApuLock();
  dsp_output_ring_save(g_snes->apu->dsp, &ring);
  RtlApuUnlock();

  /* A rollback is not a timeline jump, and must not read as one.
   *
   * RtlStateGeneration() is how a host learns the guest went somewhere the
   * player can see -- a reset, a savestate load -- so it can drop the
   * host-side history it derived from the old timeline: the audio timeline,
   * the rewind ring, a presenter's interpolation frames. A rollback undoes a
   * speculation the player never saw and leaves the guest exactly where it
   * was, so none of that is stale. Run-ahead rolls back sixty times a second:
   * counted as jumps, the desktop host tore down and rebuilt its 17.5 MB
   * rewind ring EVERY FRAME -- rewind kept no history at all while run-ahead
   * was on, and said so once per frame in the log. Netplay rollback had the
   * same shape waiting for it. Keep the counter across the load. */
  { const uint64_t generation = s_state_generation;
    ok = RtlLoadSnapshotFromMemory(data, guest);
    s_state_generation = generation; }

  /* The game's execution position goes back BEFORE the residue is applied and
   * after the guest blob: it is the thing that has to agree with the RAM the
   * blob just restored. A game that saved one must be able to load it, so a
   * refusal fails the whole rollback rather than leaving the two out of step
   * -- which is the exact defect these hooks exist to close. */
  if (ok && exec_len) {
    if (!g_rtl_game_info || !g_rtl_game_info->exec_state_load ||
        !g_rtl_game_info->exec_state_load((const uint8 *)data + guest,
                                          exec_len))
      ok = false;
  }

  RtlApuLock();
  dsp_output_ring_restore(g_snes->apu->dsp, &ring);
  if (ok)
    rtl_rb_residue_apply(&residue);
  RtlApuUnlock();
  return ok;
}

uint32_t RtlAudioProducerCursor(void) {
  uint32_t w;
  if (!g_snes)
    return 0u;
  RtlApuLock();
  w = dsp_output_ring_write(g_snes->apu->dsp);
  RtlApuUnlock();
  return w;
}

void RtlAudioRewindProducer(uint32_t cursor) {
  if (!g_snes)
    return;
  RtlApuLock();
  dsp_output_ring_set_write(g_snes->apu->dsp, cursor);
  RtlApuUnlock();
}

void RtlSaveLoad(int cmd, int slot) {
  char name[128];
  RtlEnsureSaveDir();
  RtlSaveSlotPath(slot, name, sizeof(name));
  printf("*** %s slot %d: %s\n",
    cmd == kSaveLoad_Save ? "Saving" : "Loading", slot, name);
  /* Breadcrumb the operation: a crash shortly after a state load is a
   * different bug class than a cold-boot crash, and the field report
   * needs to distinguish them without the user remembering. */
  host_report_breadcrumb("savestate %s: %s",
      cmd == kSaveLoad_Save ? "save" : "load", name);
  if (cmd == kSaveLoad_Save)
    RtlSaveSnapshot(name);
  else
    RtlLoadSnapshot(name);
}


void MemCpy(void *dst, const void *src, int size) {
  memcpy(dst, src, size);
}

bool Unreachable(void) {
  printf("Unreachable!\n");
  assert(0);
  g_ram[0x1ffff] = 1;
  return false;
}

uint8 *RomPtr(uint32_t addr) {
  uint8_t bank = (uint8_t)(addr >> 16);
  uint16_t lo = (uint16_t)addr;
  extern Snes *g_snes;
  /* Cx4 working RAM reached through a ROM-shaped pointer. The reachable
   * caller is SimpleHdma_GetPtr (below), which resolves HDMA table pointers
   * through RomPtr -- and Mega Man X2/X3 stage graphics data in Cx4 RAM, so an
   * HDMA table there is plausible. NOT reachable from cpu_read8: that
   * intercepts the Cx4 window itself before its RomPtr fallthrough. Serve it
   * from the coprocessor buffer; cx4_ram_ptr returns NULL for the $7F40-$7F5E
   * MMIO registers, which must go through cart_read and so fall through to the
   * off-rails report below. */
  if (g_snes && cart_is_cx4_window(g_snes->cart, bank, lo)) {
    uint8_t *cx4p = cx4_ram_ptr(g_snes->cart->cx4, lo);
    if (cx4p) return cx4p;
  }
  uint8_t *mapped = g_snes && g_snes->cart
      ? cart_getRomPtr(g_snes->cart, bank, lo) : NULL;
  if (bank == 0x7e || bank == 0x7f || !mapped) {
    if (!g_fail) {
      const char *verbose = getenv("SNESRECOMP_OFFRAILS_STDERR");
      if (verbose && verbose[0] && verbose[0] != '0') {
        extern const char *g_last_recomp_func;
        extern uint32_t g_interp_wlog_pc24;
        fprintf(stderr,
                "[off-rails-romptr] addr=$%06X PB=$%02X DB=$%02X "
                "S=$%04X func=%s interp=$%06X\n",
                (unsigned)(addr & 0xFFFFFFu), g_cpu.PB, g_cpu.DB, g_cpu.S,
                g_last_recomp_func ? g_last_recomp_func : "<none>",
                (unsigned)g_interp_wlog_pc24);
      }
      g_fail = true;
    }
    /* No printf — the ring buffer + cpu_trace_offrails is the
     * channel for backwards investigation. printf'ing every bad
     * read floods stderr with millions of identical lines. */
    cpu_trace_offrails("RomPtr-invalid", addr);
  }
  /* Resolve mapping and actual-size mirroring through Cart. This prevents a
   * valid-looking guest address from becoming an out-of-allocation host read. */
  return mapped ? mapped : (uint8 *)&g_rom[0];
}

// Replay a DMA transfer into g_ppu after the emulator executed it into g_snes->ppu.

static int _writereg_ppu_count = 0;
static int _writereg_dma_count = 0;
void WriteReg(uint16 reg, uint8 value) {
  /* Advance emulated beam time before the write lands.
   *
   * AOT-compiled code never advances the PPU beam — only a $2137 read did, in
   * ReadRegOpenBus below — so a compiled routine executes in zero PPU time no
   * matter how many cycles it costs. The interpreter does the opposite: it
   * calls snes_sync_master_clock after every opcode. That asymmetry is what
   * loses raster splits scheduled close together: snes_advance_beam's IRQ
   * comparator is a WINDOW test (target inside [h, h+span)), so a beam that
   * jumps in one lump can step straight over a target and produce no IRQ at
   * all rather than a late one.
   *
   * Measured on Gundam Wing: $00:888E is the line-21 split handler, it writes
   * INIDISP = shadow & $80 (brightness 0, deliberate) and schedules the split
   * that RESTORES brightness only two scanlines later at line 23. That second
   * split was missed in ~85% of frames, leaving the gameplay demo black for
   * ~1100 consecutive frames.
   *
   * Syncing on every hardware touch keeps compiled and interpreted code on the
   * same clock. It is bounded work: register accesses are rare next to RAM, and
   * frequent syncing keeps each delta small. */
  if (g_snes)
    snes_sync_master_clock(g_snes, g_cpu.master_cycles);
  // Direct dispatch — bypass emulator bus
  // MSU-1 ($2000-$2007). Inert unless a pack is armed, so the open-bus
  // default (no-op + log) is preserved byte-for-byte when disabled.
  if (g_snes && cart_has_sa1(g_snes->cart) &&
      ((reg >= 0x2200 && reg < 0x2400) ||
       (reg >= 0x3000 && reg < 0x3800))) {
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    cart_write(g_snes->cart, 0, reg, value);
    debug_server_on_reg_write(reg, value);
    return;
  }
  if (reg >= 0x2000 && reg < 0x2008) {
    if (msu1_enabled()) msu1_write(reg, value);
    debug_server_on_reg_write(reg, value);
    return;
  }
  if (reg >= 0x3000 && reg < 0x3300 && g_snes->cart->type == CART_SUPERFX) {
    /* AOT code reaches the GSU through this direct-register fast path rather
     * than the normal CPU bus.  Bring the coprocessor up to the CPU's current
     * master clock before either side observes or changes its registers. */
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    cart_write(g_snes->cart, 0, reg, value);
  } else if (reg >= 0x2100 && reg < 0x2140) {
    ppu_write(g_ppu, reg & 0xff, value);
    if (g_snes)
      ppu_rasterRecord(reg, g_snes->vPos, value);
  } else if (reg >= 0x2140 && reg < 0x2180) {
#if SNESRECOMP_ENABLE_MODS
    if (snes_mod_runtime_filter_apu_write_c(reg, value)) {
      debug_server_on_reg_write(reg, value);
      return;
    }
#endif
    RtlApuWrite(reg, value);
  } else if (reg >= 0x2180 && reg < 0x2184) {
    snes_writeBBus(g_snes, reg & 0xff, value);
  } else if (reg >= 0x4200 && reg < 0x4220) {
    if (reg == 0x420C) {
      g_snesrecomp_last_hdmaen = value;
      /* Per-line fact: this title switches the transition's HDMA
       * channels on from the line-21 raster handler, and a frame-model
       * host that samples the mask once at render time never sees them.
       * See raster_reg_journaled() in ppu.c. */
      if (g_snes)
        ppu_rasterRecord(reg, g_snes->vPos, value);
    }
    if (reg == 0x420D)
      g_memsel = (uint8_t)(value & 1);  /* FastROM select; paces $80-FF code */
    recomp_write_internal_reg(reg, value);
  } else if (reg >= 0x4300 && reg < 0x4380) {
    dma_write(g_dma, reg, value);
  } else if (reg >= 0x4800 && reg < 0x4808 &&
             g_snes && g_snes->cart &&
             g_snes->cart->type == CART_SDD1) {
    /* S-DD1 decompression-chip registers ($4800-$4807). The LLE
     * interpreter's cpu_write8 funnels everything in $2000-$5FFF through
     * WriteReg; without this case the game's $4800/$4801 enables and
     * $4804-$4807 MMC selects were silently dropped and the chip could
     * never activate (Star Ocean's boot hung in the SPC700 upload feeding
     * it raw compressed data). */
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    cart_write(g_snes->cart, 0, reg, value);
  }
  debug_server_on_reg_write(reg, value);
}


uint8 ReadRegOpenBus(uint16 reg, uint8 open_bus) {
  // Direct dispatch — bypass emulator bus
  // MSU-1 ($2000-$2007). An absent device leaves the data bus undriven.
  if (g_snes && cart_has_sa1(g_snes->cart) &&
      ((reg >= 0x2200 && reg < 0x2400) ||
       (reg >= 0x3000 && reg < 0x3800))) {
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    return sa1_cpu_read(g_snes->cart->sa1, 0, reg, open_bus);
  }
  if (reg >= 0x2000 && reg < 0x2008) {
    return msu1_enabled() ? msu1_read(reg) : open_bus;
  }
  if (reg == 0x2137)
    snes_sync_master_clock(g_snes, g_cpu.master_cycles);
  if (reg >= 0x3000 && reg < 0x3300 && g_snes->cart->type == CART_SUPERFX) {
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    return cart_read(g_snes->cart, 0, reg);
  }
  if (reg >= 0x2100 && reg < 0x2140) {
    return ppu_read(g_ppu, reg & 0xff);
  } else if (reg >= 0x2140 && reg < 0x2180) {
    // APU read — route through emulator (real SPC700 outPorts).
    return snes_read(g_snes, reg);
  } else if (reg == 0x2180) {
    return snes_readBBus(g_snes, reg & 0xff);
  } else if (reg == 0x4016 || reg == 0x4017) {
    /* JOYSER0 / JOYSER1 — manual joypad-read serial registers.
     * Routed through snes_readReg so the SNES core can return the
     * controller-presence signature (bit 0 set after the implicit
     * "16 reads done" state). Phase B koopa-stomp investigation
     * (2026-04-24) found these reads were falling through to the
     * default `return 0` and breaking SMW's CheckWhichControllers-
     * ArePluggedIn detection. */
    return snes_readReg(g_snes, reg);
  } else if (reg >= 0x4200 && reg < 0x4220) {
    return recomp_read_internal_reg(reg);
  } else if (reg >= 0x4300 && reg < 0x4380) {
    return dma_read(g_dma, reg);
  } else if (reg >= 0x4800 && reg < 0x4808 &&
             g_snes && g_snes->cart &&
             g_snes->cart->type == CART_SDD1) {
    /* S-DD1 register reads: mirror the write path so ioRead (bsnes)
     * semantics apply under the interpreter instead of returning open bus. */
    cart_sync_coprocessors(g_snes->cart, g_cpu.master_cycles);
    return cart_read(g_snes->cart, 0, reg);
  }
  return open_bus;
}

uint8 ReadReg(uint16 reg) {
  return ReadRegOpenBus(reg, g_cpu.open_bus);
}

uint16 ReadRegWord(uint16 reg) {
  // APU port quirk: 16-bit CMP $2140 must see a CONSISTENT outPorts
  // snapshot. Two separate ReadReg calls would each catch the APU
  // up — between them the SPC could write only the LO byte (port 0)
  // before host has read HI (port 1), so host sees a torn value. Read
  // both ports atomically (single guest-time sync) for the APU-port range.
  if (reg >= 0x2140 && reg <= 0x217F) {
    void RtlApuLock(void); void RtlApuUnlock(void);
    extern Snes *g_snes;
    RtlApuLock();
    rtl_sync_apu_to_cpu_locked();
    uint8_t lo = g_snes->apu->outPorts[(reg & 0x3)];
    uint8_t hi = g_snes->apu->outPorts[((reg + 1) & 0x3)];
    RtlApuUnlock();
    lo = rtl_apu_port_observers_read(reg, lo);
    hi = rtl_apu_port_observers_read(reg + 1, hi);
    g_cpu.open_bus = hi;
    return (uint16_t)lo | ((uint16_t)hi << 8);
  }
  uint8_t lo = ReadReg(reg);
  g_cpu.open_bus = lo;
  uint8_t hi = ReadReg(reg + 1);
  g_cpu.open_bus = hi;
  return (uint16_t)lo | ((uint16_t)hi << 8);
}

static void WriteVramWord(Ppu *ppu, uint16 value) {
  uint16_t adr = ppu->vramPointer;
  ppu->vram[adr & 0x7fff] = value;
  ppu->vramWriteCount++;
  // Atomic 16-bit STA $2118 hits both VRAM bytes at this word; record
  // each as a byte event so the differ can compare against the
  // oracle's REGISTER_2118 + REGISTER_2119 byte sequence.
  uint32_t byte_addr = (uint32_t)(adr & 0x7fff) << 1;
  debug_server_on_vram_write(byte_addr,     (uint8_t)(value & 0xff));
  debug_server_on_vram_write(byte_addr + 1, (uint8_t)(value >> 8));
  WsShadowOnVramWrite((uint16_t)(adr & 0x7fff), value);
  /* With incOnHigh=1 (VMAIN bit 7), the pointer advances after the high
   * byte ($2119). A 16-bit STA $2118 writes both bytes atomically, so
   * the pointer advances by one word — same as the real hardware path
   * (case 0x18 no-increment + case 0x19 increment). With incOnHigh=0,
   * the pointer would advance after the low byte, placing the high byte
   * in the NEXT word — but no sane game does 16-bit STA $2118 in that
   * mode, so we unconditionally advance by one word. */
  ppu->vramPointer += ppu->vramIncrement;
}

void WriteRegWord(uint16 reg, uint16 value) {
  if (reg == 0x2118) {
    // VRAM data port: atomic word write
    WriteVramWord(g_ppu, value);
    return;
  }
  // APU port quirk: 16-bit STA $2140 transfers data via $2141 (hi)
  // and the ack-trigger via $2140 (lo). On real hardware both bytes
  // hit the bus together; SMW's SPC IPL upload protocol reads $2141
  // the moment it sees $2140 change. If we write lo first the IPL
  // latches stale $2141. Order hi-then-lo so $2141 is in place
  // before $2140 fires the trigger.
  if (reg >= 0x2140 && reg <= 0x217F) {
    WriteReg(reg + 1, value >> 8);
    WriteReg(reg, (uint8)value);
    return;
  }
  WriteReg(reg, (uint8)value);
  WriteReg(reg + 1, value >> 8);
}

uint8 *IndirPtr_Slow(LongPtr ptr, uint16 offs) {
  return IndirPtr(ptr, offs);  /* delegates to inline version in header */
}

/* IndirWriteByte is now inline in common_rtl.h */

// Convert the APU-touch cycle delta into APU cycles (ratio ~3.5:1) and
// accumulate into apuCatchupCycles. Caller holds RtlApuLock and is
// responsible for the snes_catchupApu() call. Sets g_apu_last_sync_cycles
// to the current APU-touch estimate so subsequent calls only see
// incremental work. (See g_apu_pace_cycles_estimate's comment for why
// this deliberately ignores non-APU HW touches.)
//
// Public so snes.c's snes_readBBus (the APU read path) can use the same
// pacing -- both reads and writes need to advance APU.
void rtl_accumulate_apu_catchup(void) {
  /* The interp816 bridge advances the SPC per-opcode by guest master cycles
   * (guest-time-anchored, like the ref oracle). Skip the per-touch estimate so
   * an APU-port access inside interpreted code doesn't double-count. */
  if (g_interp_apu_driving) return;
#ifdef SNES_COSIM
  /* Shared APU clock (see common_rtl.h): pure touch-delta pacing, NO wall
   * baseline. The baseline reads the co-sim virtual wall clock, which derives
   * from master_cycles — a per-execution-model quantity (interp charges
   * cyc*8, compiled blocks charge region-weighted static costs), so it would
   * re-introduce the per-side skew this mode exists to remove. Touch credit is
   * deliberately unscaled 256/touch (SNESRECOMP_APU_TOUCH_CYCLES ignored):
   * both sides must use the identical constant. */
  if (cosim_apu_shared_clock()) {
    uint64_t delta = g_apu_pace_cycles_estimate - g_apu_last_sync_cycles;
    g_apu_last_sync_cycles = g_apu_pace_cycles_estimate;
    g_snes->apuCatchupCycles += (double)delta * 2.0 / 7.0;
    g_apu_last_sync_master = g_cpu.master_cycles;
    return;
  }
#endif
#ifdef SNES_COSIM
  /* Co-sim A-vs-B variable-under-test (SNES_COSIM.md task 9): with
   * SNES_COSIM_ACCURATE_APU=1, pace the SPC from the region-weighted master
   * clock at the true SPC:master ratio (exactly like the interp816 ref),
   * instead of the +256/APU-touch synthetic estimate. Two recomp instances
   * that boot IDENTICALLY and differ ONLY in this pacing choice stay
   * bit-identical until synthetic pacing first yields a different APU value —
   * the off-cue's first observable effect, cleanly localized. Cached once. */
  static int s_accurate = -1;
  if (s_accurate < 0) { const char *e = getenv("SNES_COSIM_ACCURATE_APU");
                        s_accurate = (e && e[0] && e[0] != '0') ? 1 : 0; }
  if (s_accurate) {
    static const double kApuPerMaster = (32040.0 * 32.0) / (1364.0 * 262.0 * 60.0);
    uint64_t md = g_cpu.master_cycles - g_apu_last_sync_master;
    g_apu_last_sync_master = g_cpu.master_cycles;
    g_apu_last_sync_cycles = g_apu_pace_cycles_estimate;   /* keep sync ptr current */
    g_snes->apuCatchupCycles += (double)md * kApuPerMaster;
    return;
  }
#endif
  // NOTE (Axis-5 off-cue experiment, 2026-06-28): pacing the SPC from the
  // recompiler's region-weighted MASTER-clock accumulator (g_cpu.master_cycles,
  // = sum of CPU cycles x code-region speed) was tried here in place of the
  // +256/touch estimate below. Measured A/B vs the bsnes oracle REGRESSED it:
  // SMW drift -4013 -> -5900 ppm, onset match 53% -> 29%. Root: master_cycles
  // counts every recompiled block executed per wall-frame, but the recomp runs
  // frames host-driven (not by counting 357368 master clocks/frame), so its
  // per-frame execution-cycle total over-counts real elapsed time and the SPC
  // over-advances (music runs fast). The accumulator stays emitted as inert
  // Axis-5 infra (companion to cpu->cycles); a correct off-cue cure must pace by
  // WALL time / consumer rate, not accumulated execution cycles -- see
  // SNES_ACCURACY_BURNDOWN.md. Reverted to the known-good touch estimate:
  uint64_t delta = g_apu_pace_cycles_estimate - g_apu_last_sync_cycles;
  g_apu_last_sync_cycles = g_apu_pace_cycles_estimate;
  // 2/7 is about 1/3.5 (main MHz / APU MHz). Floor of zero is fine -- short deltas
  // (back-to-back APU touches with no block hooks between them) just don't
  // advance APU on this pass; cycles accumulate for the next touch.
  /* DIAGNOSTIC OVERRIDE (audio hunt, env-gated): rescale the per-touch credit.
   * The estimate charges 256 master cycles per HW touch, but a tight APU poll
   * loop's real period is ~15-25 cycles — an over-credit of >10x that balloons
   * SPC time during port-heavy phases (boot/stage-load uploads measured 17-45x
   * realtime, 220s of APU audio discarded at the output ring). Set
   * SNESRECOMP_APU_TOUCH_CYCLES=20 to charge ~20 master cycles per touch. */
  {
    static double s_touch_scale = -1.0;
    if (s_touch_scale < 0.0) {
      const char *e = getenv("SNESRECOMP_APU_TOUCH_CYCLES");
      s_touch_scale = (e && e[0]) ? (atof(e) / 256.0) : 1.0;
      if (s_touch_scale <= 0.0) s_touch_scale = 1.0;
    }
    delta = (uint64_t)((double)delta * s_touch_scale);
  }
  g_snes->apuCatchupCycles += (double)delta * 2.0 / 7.0;
  // Keep the master sync pointer current so the (now inert) accumulator's delta
  // never balloons if a future change re-enables master-clock pacing.
  g_apu_last_sync_master = g_cpu.master_cycles;

  // Real-time baseline when nothing is draining the DSP output ring
  // (EnableAudio=0, headless runs, the pre-callback boot window, a
  // stalled device). With audio on, the audio thread's RtlRenderAudio
  // top-up advances the SPC at the device's real consumption rate; with
  // no consumer that baseline vanishes and the SPC would advance only on
  // the (possibly rare) APU touches. Inject wall-clock time at the SPC's
  // real rate (~1.024 MHz) so engine state keeps tracking real time and
  // handshakes can never freeze. ADDITIVE to the touch credit, never a
  // limit — handshake over-clock must stay possible (see above).
  // Consumer presence is inferred from sampleRead movement, so this is
  // automatic per game and per moment, no config.
  //
  // Netplay skips this: wall time differs per peer and desyncs LLE. Once the
  // frame loop starts, rtl_sync_apu_frame_boundary() is authoritative.
  {
    static uint32_t last_sample_read;
    static uint64_t consume_seen_ms, wall_last_ms;
    Dsp *dsp = g_snes->apu->dsp;
    /* audio_trace_wall_ms() is a deterministic virtual clock under SNES_COSIM
     * (see audio_trace.c) — routes this baseline through the same source as the
     * port-write scheduler, so the whole APU-pacing path is deterministic. */
    uint64_t now_ms = audio_trace_wall_ms();
    if (rtl_netplay_locks_audio()) {
      wall_last_ms = now_ms;
      audio_trace_on_pace(1, 0);
      return;
    }
    uint32_t rd = dsp->sampleRead;
    if (rd != last_sample_read) {
      last_sample_read = rd;
      consume_seen_ms = now_ms;
    }
    int consumer_active = consume_seen_ms != 0 &&
                          now_ms - consume_seen_ms < 250;
    uint32_t baseline = 0;
    if (!consumer_active && wall_last_ms != 0) {
      uint64_t elapsed = now_ms - wall_last_ms;
      if (elapsed > 32) elapsed = 32;  /* burst cap: ~32 ms of SPC time */
      baseline = (uint32_t)(elapsed * 1024);  /* SPC ~1.024 MHz */
      g_snes->apuCatchupCycles += (double)baseline;
    }
    wall_last_ms = now_ms;
    audio_trace_on_pace(consumer_active, baseline);
  }
}

#ifdef SNESRECOMP_INTERP_PROFILE
#include <time.h>
uint64_t apuw_prof_calls = 0;
double apuw_prof_ms = 0.0;
#endif
void RtlApuWrite(uint16 adr, uint8 val) {
  assert(adr >= 0x2140 && adr <= 0x217f);
  if (rtl_apu_port_observers_filter(adr, val)) return;
  uint8_t port = (uint8_t)(adr & 3);
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apuw_prof_calls; extern double apuw_prof_ms;
    clock_t _t0 = clock();
    apuw_prof_calls++; }
  clock_t _t1 = clock();
#endif

#ifdef SNES_COSIM
  /* The shared-clock co-sim advances the SPC synchronously and compares two
   * execution models instruction-for-instruction. Keep its bus mutation at
   * the already-aligned current clock. */
  if (cosim_apu_shared_clock()) {
    RtlApuLock();
    audio_trace_on_cpu_port_write(port, val);
    apu_writePortNow(g_snes->apu, port, val);
    RtlApuUnlock();
    return;
  }
#endif

  RtlApuLock();
  if (!g_apu_frame_time_valid) {
    rtl_accumulate_apu_catchup();
    snes_catchupApu(g_snes);
  }
  audio_trace_on_cpu_port_write(port, val);

  if (!g_apu_frame_time_valid) {
    /* Reset/IPL handshakes actively advance the SPC through their poll loops;
     * there is no host frame timeline yet, so current-cycle visibility is the
     * faithful model. */
    apu_writePortNow(g_snes->apu, port, val);
  } else {
    uint64_t guest_cycle = rtl_apu_guest_cycle();
    while (!apu_schedulePortWrite(g_snes->apu, port, val, guest_cycle))
      apu_cycle(g_snes->apu);
  }
  RtlApuUnlock();
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apuw_prof_calls; extern double apuw_prof_ms;
    apuw_prof_ms += 1000.0 * ((double)(clock() - _t1)) / CLOCKS_PER_SEC; }
#endif
}

#ifdef SNESRECOMP_INTERP_PROFILE
uint64_t apus_prof_calls = 0;
double apus_prof_ms = 0.0;
#endif
void rtl_sync_apu_to_cpu_locked(void) {
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apus_prof_calls; extern double apus_prof_ms;
    clock_t _t0 = clock();
    apus_prof_calls++; }
  clock_t _t1 = clock();
#endif
  if (!g_apu_frame_time_valid) {
    rtl_accumulate_apu_catchup();
    snes_catchupApu(g_snes);
#ifdef SNESRECOMP_INTERP_PROFILE
    { extern uint64_t apus_prof_calls; extern double apus_prof_ms;
      apus_prof_ms += 1000.0 * ((double)(clock() - _t1)) / CLOCKS_PER_SEC; }
#endif
    return;
  }
  audio_trace_set_producer(AUDIO_TRACE_PRODUCER_CPU);
  uint64_t before = g_snes->apu->portClock;
  bool synced = apu_runToGuestCycle(g_snes->apu, rtl_apu_guest_cycle(),
                                    1u << 20);
  audio_trace_on_guest_sync(0, g_snes->apu->portClock - before);
  audio_trace_set_producer(AUDIO_TRACE_PRODUCER_UNKNOWN);
  if (!synced)
    fprintf(stderr, "[apu] CPU-port guest-clock sync timed out\n");
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apus_prof_calls; extern double apus_prof_ms;
    apus_prof_ms += 1000.0 * ((double)(clock() - _t1)) / CLOCKS_PER_SEC; }
#endif
}

/* AOT APU pacing hook. Generated AOT code advances g_cpu.master_cycles but
 * (unlike the interpreter bridge) never flushes the SPC periodically, so a
 * long AOT block that doesn't touch APU ports ($2140-$2143) leaves the
 * SPC700 frozen and the DSP output ring starves -> silent/choppy music.
 * The interpreter bridge flushes every ~1024 master cycles; WatchdogCheck()
 * runs per-block in generated code, so hooking the same periodic catch-up
 * here restores that cadence for AOT execution. Caller: game thread only.
 * The delta is measured against g_apu_last_sync_master, which the interp
 * bridge also advances, so AOT/interp alternation never double-counts. */
void rtl_apu_pace_check(void) {
  /* Boot (frame 0) is paced by the interp bridge's progress checkpoints and
   * the SPC IPL upload handshake; forcing an extra catch-up here from AOT
   * blocks disturbs that pacing and can stall the vblank poll loop. Only
   * pace once real frames are running. */
  if (snes_frame_counter == 0) return;
  uint64_t delta = g_cpu.master_cycles - g_apu_last_sync_master;
  if (delta < 1024) return;
  RtlApuLock();
  g_apu_last_sync_master = g_cpu.master_cycles;
  rtl_sync_apu_to_cpu_locked();
  RtlApuUnlock();
}

static bool RtlUploadSpcImageFromDpInternal(CpuState *cpu,
                                            bool update_cpu_result,
                                            bool live_transfer) {
  uint16_t dp = cpu->D;
  uint16_t data_lo = (uint16_t)g_ram[(dp + 0) & 0xffff]
                   | ((uint16_t)g_ram[(dp + 1) & 0xffff] << 8);
  uint8_t data_bank = g_ram[(dp + 2) & 0xffff];
  const uint8_t *p = RomPtr(((uint32_t)data_bank << 16) | data_lo);
  uint16_t final_pc = 0;
  int block_count = 0;

  RtlApuLock();
  bool ipl_phase = g_snes->apu->romReadable;
  /* The HLE routine takes ownership only after all earlier CPU bus events
   * have reached the live SPC. For a running driver, honor its ready
   * handshake before replacing the byte-by-byte payload copy. */
  if (!apu_runUntilPortQueueEmpty(g_snes->apu, 1u << 22)) {
    RtlApuUnlock();
    fprintf(stderr, "[apu] queued port events did not reach upload boundary\n");
    return false;
  }
  uint8_t transfer_request = g_snes->apu->inPorts[1];
  if (live_transfer && !ipl_phase &&
      !apu_waitForTransferReady(g_snes->apu, 1, transfer_request, 1u << 20)) {
    fprintf(stderr,
            "[apu] SPC transfer-ready timeout pc=%04x stopped=%d "
            "in=%02x%02x out=%02x%02x edge=%02x%02x buf=%02x%02x\n",
            g_snes->apu->spc->pc, g_snes->apu->spc->stopped,
            g_snes->apu->inPorts[0], g_snes->apu->inPorts[1],
            g_snes->apu->outPorts[0], g_snes->apu->outPorts[1],
            g_snes->apu->ram[0], g_snes->apu->ram[1],
            g_snes->apu->ram[4], g_snes->apu->ram[5]);
    RtlApuUnlock();
    return false;
  }
  apu_clearPortQueue(g_snes->apu);
  for (;;) {
    uint16_t n = (uint16_t)p[0] | ((uint16_t)p[1] << 8);
    uint16_t target = (uint16_t)p[2] | ((uint16_t)p[3] << 8);
    p += 4;
    if (n == 0) {
      final_pc = target;
      break;
    }
    for (uint16_t i = 0; i < n; i++)
      g_snes->apu->ram[(uint16_t)(target + i)] = p[i];
    p += n;
    if (++block_count > 512) {
      RtlApuUnlock();
      fprintf(stderr, "[apu] bad SPC upload stream at %02X:%04X\n",
              data_bank, data_lo);
      return false;
    }
  }

  /* First-upload vs subsequent-upload semantics differ. The very first
   * upload from CPU after reset goes through the SNES SPC IPL bootROM,
   * which ends with `JMP [$0000+X]` — i.e. the IPL jumps to the entry
   * address provided in the terminator's target field. After that
   * first upload, the IPL is mapped out (romReadable=false) and the
   * loaded SPC engine handles all subsequent CPU upload requests via
   * its own routine (SMW's StandardTransfer at SPC $12F2). That
   * routine just RETs at the end — it does NOT jump to any entry
   * point. The terminator's target field is benign on subsequent
   * uploads.
   *
   * If we unconditionally re-jumped SPC PC to the terminator entry,
   * every music-bank upload would restart APU_Start, zero-clearing
   * the engine's music state ($00-$E7 + ARAM_0386-9) and the
   * just-uploaded music data would never start playing. SFX would
   * still work since they're triggered by inPort writes processed
   * after the restart's re-init, but song state would never persist.
   *
   * Detect "first upload" via apu->romReadable: it's reset to true by
   * apu_reset() and only flipped false here, so on the IPL-phase
   * upload it's still true. */
  if (ipl_phase) {
    /* The boot upload body was replaced wholesale, so this is the logical
     * consumption of the request that selected it. */
    audio_trace_on_spc_port_read(1, transfer_request);
    memset(g_snes->apu->inPorts, 0, 4);
    memset(g_snes->apu->outPorts, 0, sizeof(g_snes->apu->outPorts));
    g_snes->apu->romReadable = false;
    g_snes->apuCatchupCycles = 0;
    g_snes->apu->cpuCyclesLeft = 0;
    if (final_pc != 0) {
      g_snes->apu->spc->a = 0;
      g_snes->apu->spc->x = 0;
      g_snes->apu->spc->y = 0;
      if (g_snes->apu->spc->sp == 0)
        g_snes->apu->spc->sp = 0xef;
      g_snes->apu->spc->pc = final_pc;
    }
  } else if (live_transfer) {
    if (!apu_finishHleTransfer(g_snes->apu, final_pc, 1u << 20)) {
      RtlApuUnlock();
      fprintf(stderr, "[apu] SPC transfer terminator timed out\n");
      return false;
    }
  } else {
    /* Legacy HLE users have not declared a live driver protocol. Preserve
     * their prior behavior instead of guessing that they speak SMW's
     * AA/BB/CC transfer handshake. */
    memset(g_snes->apu->inPorts, 0, 4);
    memset(g_snes->apu->outPorts, 0, sizeof(g_snes->apu->outPorts));
  }
  g_apu_last_sync_cycles = g_apu_pace_cycles_estimate;
  // Resync the master pointer too: an IPL-phase upload zeroes apuCatchupCycles,
  // so the next catch-up must start its delta from here, not replay the master
  // cycles burned during the upload spin.
  g_apu_last_sync_master = g_cpu.master_cycles;
  RtlApuUnlock();

  if (update_cpu_result) {
    cpu->A = (uint16_t)(cpu->A & 0xff00);
    cpu->X = 0;
    cpu->Y = 0;
    cpu->_flag_Z = 1;
    cpu->_flag_N = 0;
    cpu->P = (uint8_t)((cpu->P & ~0x82) | 0x02);
  }
  return true;
}

bool RtlUploadSpcImageFromDp(CpuState *cpu) {
  return RtlUploadSpcImageFromDpInternal(cpu, false, false);
}

bool RtlUploadSpcImageFromDpLive(CpuState *cpu) {
  return RtlUploadSpcImageFromDpInternal(cpu, false, true);
}

bool RtlHandleSpcUpload(CpuState *cpu) {
  return RtlUploadSpcImageFromDpInternal(cpu, true, false);
}

/* Dev perf: accumulated host ns in the per-frame SPC boundary sync. */
static uint64_t s_apu_boundary_ns = 0;
static uint64_t s_apu_boundary_calls = 0;
void rtl_apu_perf_snapshot(uint64_t *ns, uint64_t *calls) {
    if (ns) *ns = s_apu_boundary_ns;
    if (calls) *calls = s_apu_boundary_calls;
}

#ifdef SNESRECOMP_INTERP_PROFILE
#include <time.h>
uint64_t apub_prof_calls = 0;
double apub_prof_ms = 0.0;
#endif
static void rtl_sync_apu_frame_boundary(void) {
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apub_prof_calls; extern double apub_prof_ms;
    clock_t _t0 = clock();
    apub_prof_calls++; }
  clock_t _t1 = clock();
#endif
  /* The game frame is the authoritative guest-time clock. The audio callback
   * may fill a host scheduling shortfall, but CPU->APU events must never wait
   * behind it: advance the real SPC through every event due by this completed
   * frame at normal speed and turbo alike. */
  uint64_t _t0 = 0;
  if (getenv("SNESRECOMP_PHASE_MS")) {
    extern uint64_t snesrecomp_host_now_ns(void);
    _t0 = snesrecomp_host_now_ns();
  }
  RtlApuLock();
  audio_trace_set_producer(AUDIO_TRACE_PRODUCER_CPU);
  uint64_t before = g_snes->apu->portClock;
  /* RtlRunFrame has already incremented snes_frame_counter. This is the exact
   * boundary after the completed frame; adding its stale within-frame master
   * offset here would count the frame body twice. */
  uint64_t boundary = g_extended_frame_timing
      ? rtl_apu_clock_finish(&g_apu_frame_clock, g_cpu.master_cycles)
      : (uint64_t)snes_frame_counter * RTL_APU_CYCLES_PER_FRAME;
  bool synced = apu_runToGuestCycle(g_snes->apu, boundary,
                                    1u << 20);
  audio_trace_on_guest_sync(1, g_snes->apu->portClock - before);
  audio_trace_set_producer(AUDIO_TRACE_PRODUCER_UNKNOWN);
  if (!synced)
    fprintf(stderr, "[apu] frame-boundary guest-clock sync timed out\n");
  RtlApuUnlock();
  if (_t0) {
    extern uint64_t snesrecomp_host_now_ns(void);
    s_apu_boundary_ns += snesrecomp_host_now_ns() - _t0;
    s_apu_boundary_calls++;
  }
#ifdef SNESRECOMP_INTERP_PROFILE
  { extern uint64_t apub_prof_calls; extern double apub_prof_ms;
    apub_prof_ms += 1000.0 * ((double)(clock() - _t1)) / CLOCKS_PER_SEC; }
#endif
}

void RtlSetSpeculativeFrame(bool on) { g_rtl_speculative_frame = on; }
bool RtlSpeculativeFrame(void) { return g_rtl_speculative_frame; }

void RtlAudioSetFastForward(bool active) {
  if (!active && !g_audio_fast_forward && g_audio_recovery_frames == 0)
    return;
  RtlApuLock();
  if (active && !g_audio_fast_forward) {
    /* A new fast-forward interval supersedes the prior continuity ramp. */
    g_audio_recovery_frames = 0;
    g_audio_recovery_remaining = 0;
  } else if (!active && g_audio_fast_forward) {
    g_audio_recovery_frames = 30;
    g_audio_recovery_anchor_l = g_audio_last_output_l;
    g_audio_recovery_anchor_r = g_audio_last_output_r;
    g_audio_recovery_remaining = RTL_AUDIO_RECOVERY_RAMP;
  }
  if (!active && g_audio_recovery_frames != 0) {
    uint32_t available = g_snes->apu->dsp->sampleWrite -
                         g_snes->apu->dsp->sampleRead;
    /* Preserve the consumer's startup cushion. A stage upload or starvation
     * can re-enter priming during turbo; trimming below its threshold would
     * prevent playback from ever restarting and perpetually renew recovery.
     * Remove stale latency while allowing the same delivery gate to open. */
    uint32_t discarded = dsp_trimSamples(g_snes->apu->dsp,
                                          RTL_AUDIO_TARGET_NATIVES);
    if (discarded != 0) {
      audio_trace_on_fast_forward_discard(discarded,
                                           available - discarded);
      g_audio_recovery_anchor_l = g_audio_last_output_l;
      g_audio_recovery_anchor_r = g_audio_last_output_r;
      g_audio_recovery_remaining = RTL_AUDIO_RECOVERY_RAMP;
      /* The host frame-delay clock may still be catching up after a long
       * turbo interval. Require a full stable window after the most recent
       * trim instead of expiring recovery after a fixed number of fast game
       * frames. This makes release behavior independent of turbo duration. */
      g_audio_recovery_frames = 30;
    } else {
      g_audio_recovery_frames--;
    }
  }
  g_audio_fast_forward = active;
  RtlApuUnlock();
}

/* ---- Native-rate delivery with an occupancy servo ----------------------
 *
 * Two independent clocks meet here and nowhere else: the guest produces
 * exactly 534 natives per emulated frame (RTL_APU_CYCLES_PER_FRAME / 32,
 * paced by rtl_sync_apu_frame_boundary), and the host audio device drains at
 * its own crystal rate. They never agree exactly:
 *
 *   - the frame loop runs at 60.0988 fps (SMK/SMRPG) or 60.000 (block hosts),
 *     or whatever vsync imposes, so production lands anywhere in the
 *     32040-32093 natives/s range;
 *   - the device consumes at the rate implied by its own clock.
 *
 * Left unreconciled, even a 40 natives/s imbalance walks the 8192-sample ring
 * to one end within ~3 minutes and stays there: at the full end the producer
 * drops runs (crackle, plus 256 ms of latency), at the empty end the consumer
 * starves. Both ends were observed in this family.
 *
 * So the consumer flexes. Each call we read the ring's occupancy, compare it
 * against a target cushion, and consume natives at a rate up to +/-0.5% off
 * nominal to steer occupancy back — resampling that fractional count onto the
 * exact `frames` the host asked for, with interpolation phase carried across
 * calls so block boundaries have no seam. +/-0.5% is ~8 cents, an order of
 * magnitude below the ~25 cents where pitch drift becomes noticeable, and it
 * comfortably covers every imbalance in this family (SMK's 60.0988 loop is
 * 0.165% off; 59.94 vsync is 0.1%).
 *
 * Production is deliberately NOT touched: the guest frame stays the master
 * clock. An earlier design had this callback cycle the SPC for its own
 * shortfall, which made the host's scheduling a second competing emulation
 * clock and let audio drift behind video after turbo. The consumer bending by
 * half a percent cannot become a clock.
 */
#define RTL_AUDIO_NATIVE_RATE    32040.0 /* SPC output rate: 1.024 MHz / 32   */
#define RTL_AUDIO_SERVO_GAIN     0.05  /* gentle: full-scale error -> 5%, clamped */
#define RTL_AUDIO_SERVO_MAX      0.005 /* +/-0.5% == ~8 cents, inaudible        */
/* Occupancy is sampled at callback entry, but production arrives in 534-native
 * bursts once per emulated frame, so the raw reading sawtooths by more than the
 * servo's whole proportional band (+/-160 natives). Feeding that straight in
 * slams the ratio rail-to-rail every callback — ~1% peak-to-peak pitch flutter
 * at the callback rate, which is an order of magnitude above where tape wow
 * becomes objectionable. Smooth the burst out before the servo sees it. */
#define RTL_AUDIO_OCC_EMA        0.05
/* Fade length for starvation edges. A hard cut to zero and back is a click at
 * both edges; 64 frames (~2 ms) is short enough to be inaudible as a gain
 * change but long enough to remove the click. */
#define RTL_AUDIO_FADE_FRAMES    64

static double s_render_phase;      /* fractional native position, carried over */
static int16 s_render_hold_l;      /* last native delivered — fade anchor and  */
static int16 s_render_hold_r;      /* interpolation partner across calls       */
static int s_render_starved;       /* in a starvation episode (drives fade-in) */
static int s_render_fade_pos;      /* fade-in progress, carried across calls   */
static double s_render_occ_ema = -1.0; /* burst-filtered occupancy, -1 = unset */
static bool s_render_priming = true;
static int s_render_fade_out;

/* Delivery state belongs to the host clock, not to a guest snapshot. Reset
 * under the APU lock when the guest queue is replaced, and rebuild the same
 * cushion that the ordinary clock-drift servo targets. Never run the SPC to
 * fill it: only completed guest frames may produce the missing samples. */
static void rtl_reset_audio_delivery(void) {
  s_render_phase = 0;
  s_render_occ_ema = -1.0;
  s_render_priming = true;
  s_render_starved = 1;
  s_render_fade_pos = 0;
  s_render_fade_out = RTL_AUDIO_FADE_FRAMES;
}

static void rtl_render_wait(int16 *out, int frames) {
  for (int i = 0; i < frames; ++i) {
    int weight = s_render_fade_out > 0 ? --s_render_fade_out : 0;
    out[i*2] = (int16)((int32_t)s_render_hold_l * weight / RTL_AUDIO_FADE_FRAMES);
    out[i*2+1] = (int16)((int32_t)s_render_hold_r * weight / RTL_AUDIO_FADE_FRAMES);
  }
  if (!s_render_fade_out) s_render_hold_l = s_render_hold_r = 0;
}
/* Host output rate. Defaults to the native rate, so a host that never calls
 * RtlSetAudioOutputRate behaves exactly as if no conversion were needed —
 * which is correct for every shipped default config, all of which open the
 * device at 32040 (or 32000, inside the servo's range). */
static double s_render_output_rate = RTL_AUDIO_NATIVE_RATE;

/* Tell the consumer what rate the host actually opened the device at.
 *
 * This is not optional bookkeeping: the retired fixed-534-block path did the
 * 32040 -> device-rate conversion as a side effect of its sample-and-hold, so
 * removing it removed the only rate conversion in the chain. Every host whose
 * AudioFreq is user-configurable (all the Family A hosts accept 11025-48000)
 * must report the obtained rate here, or a user who sets 44100 gets audio
 * consumed 37% too fast — permanent starvation plus a 5.5-semitone pitch error.
 *
 * Called once from host audio init, before the device is unpaused and hence
 * before any callback can run, so no lock is needed. */
void RtlSetAudioOutputRate(int freq) {
  if (freq >= 8000 && freq <= 192000)
    s_render_output_rate = (double)freq;
}

/* Accessor for other consumers that must resample onto the same device rate
 * as rtl_render_native (e.g. msu1_mix's 44.1 kHz track -> device-rate
 * conversion in snes/msu1.c). Declared extern locally there rather than
 * pulled in through a header, matching this file's existing convention for
 * small cross-module hooks (see msu1.c's RtlApuLock/RtlApuUnlock externs). */
double RtlAudioOutputRate(void) {
  return s_render_output_rate;
}

static void rtl_render_native(Dsp *dsp, int16 *out, int frames) {
  if (frames <= 0) return;
  uint32_t available = dsp_available(dsp);

  if (s_render_priming) {
    if (available < RTL_AUDIO_TARGET_NATIVES || s_render_fade_out) {
      rtl_render_wait(out, frames);
      audio_trace_on_output_priming(available);
      return;
    }
    s_render_priming = false;
    s_render_occ_ema = (double)available;
    s_render_starved = 1;
    s_render_fade_pos = 0;
  }

  /* Servo: steer ring occupancy toward the target cushion, on top of the fixed
   * native->device rate conversion. */
  if (s_render_occ_ema < 0.0) s_render_occ_ema = (double)available;
  else s_render_occ_ema += RTL_AUDIO_OCC_EMA *
                           ((double)available - s_render_occ_ema);
  double err = (s_render_occ_ema - (double)RTL_AUDIO_TARGET_NATIVES) /
               (double)RTL_AUDIO_TARGET_NATIVES;
  double servo = 1.0 + RTL_AUDIO_SERVO_GAIN * err;
  if (servo > 1.0 + RTL_AUDIO_SERVO_MAX) servo = 1.0 + RTL_AUDIO_SERVO_MAX;
  if (servo < 1.0 - RTL_AUDIO_SERVO_MAX) servo = 1.0 - RTL_AUDIO_SERVO_MAX;
  /* Natives to advance per output frame: the rate ratio, trimmed by the servo. */
  double ratio = (RTL_AUDIO_NATIVE_RATE / s_render_output_rate) * servo;

  /* Natives spanned by this request, including the carried phase. The last
   * output frame interpolates between floor(pos) and floor(pos)+1, so one
   * extra native must be present. */
  double span = s_render_phase + (double)(frames - 1) * ratio;
  uint32_t need = (uint32_t)span + 2;

  int usable = frames;
  if (available < need) {
    /* Starving. Emit every frame we can actually source rather than blanking
     * the whole request — the old behaviour memset the full block even when
     * 533 perfectly good samples were queued. */
    if (available < 2) {
      usable = 0;
    } else {
      double max_span = (double)(available - 2) - s_render_phase;
      usable = max_span <= 0.0 ? 0 : (int)(max_span / ratio) + 1;
      if (usable > frames) usable = frames;
    }
  }

  for (int i = 0; i < usable; i++) {
    double pos = s_render_phase + (double)i * ratio;
    uint32_t idx = (uint32_t)pos;
    double frac = pos - (double)idx;
    int16 l0, r0, l1, r1;
    dsp_peek(dsp, idx, &l0, &r0);
    dsp_peek(dsp, idx + 1, &l1, &r1);
    int16 l = (int16)((double)l0 + ((double)l1 - (double)l0) * frac);
    int16 r = (int16)((double)r0 + ((double)r1 - (double)r0) * frac);
    /* Fade in out of a starvation episode so the recovery edge is not a step.
     * The fade-out below ends at silence, so this ramps 0 -> signal.
     *
     * Progress is carried in a static across calls rather than derived from `i`.
     * Keyed on `i`, a recovery spread over several short callbacks restarts the
     * ramp from zero every call — a buzz at the callback rate rather than a
     * fade — and the flag would never clear at all if no single call ever
     * delivered more than RTL_AUDIO_FADE_FRAMES frames, leaving every
     * subsequent callback permanently ramped despite a healthy ring. */
    if (s_render_starved) {
      int32_t w = s_render_fade_pos < RTL_AUDIO_FADE_FRAMES
                      ? s_render_fade_pos : RTL_AUDIO_FADE_FRAMES;
      l = (int16)(((int32_t)l * w) / RTL_AUDIO_FADE_FRAMES);
      r = (int16)(((int32_t)r * w) / RTL_AUDIO_FADE_FRAMES);
      if (++s_render_fade_pos >= RTL_AUDIO_FADE_FRAMES) s_render_starved = 0;
    }
    out[i * 2] = l;
    out[i * 2 + 1] = r;
  }

  if (usable > 0) {
    s_render_hold_l = out[(usable - 1) * 2];
    s_render_hold_r = out[(usable - 1) * 2 + 1];
    /* Retire only the natives fully behind the new phase, so the interpolation
     * partner for the next call stays resident. */
    double consumed_span = s_render_phase + (double)usable * ratio;
    uint32_t retire = (uint32_t)consumed_span;
    dsp_advance(dsp, retire);
    s_render_phase = consumed_span - (double)retire;
  }

  if (usable < frames) {
    /* One fade per starvation episode, followed by a real refill. Draining
     * each newly arriving block immediately creates repeated tiny gaps until
     * the slow drift servo eventually rebuilds the scheduling cushion. */
    s_render_starved = 1;
    s_render_fade_pos = 0;
    s_render_priming = true;
    s_render_phase = 0;
    s_render_fade_out = RTL_AUDIO_FADE_FRAMES;
    audio_trace_on_output_underflow(available, (uint32_t)(frames - usable));
    rtl_render_wait(out + usable*2, frames - usable);
  }
}

void RtlRenderAudio(int16 *audio_buffer, int samples, int channels) {
  assert(channels == 2);


  /* SPC state is guest-frame driven by RtlAudioSyncFrame. The host callback is
   * a consumer only: allowing it to invent SPC cycles makes its wall-clock
   * schedule a second, competing emulation clock and is what let audio drift
   * behind visuals after turbo. */
  RtlApuLock();
  rtl_render_native(g_snes->apu->dsp, audio_buffer, samples);
  /* Mix MSU-1 streaming audio on top of the S-DSP block. Inert (no-op)
   * unless a pack is armed and a track is playing. Runs under the APU
   * lock we already hold, which serialises it against MSU register
   * writes on the CPU thread (msu1_read/msu1_write take the same lock). */
  msu1_mix(audio_buffer, samples);
  /* Overlay follows the native+MSU mix and precedes recovery fade, so trusted
   * one-shots share the final discontinuity smoothing. */
  snes_mod_audio_mix(audio_buffer, samples,
                      (uint32_t)(RtlAudioOutputRate() + 0.5), channels);
  for (int i = 0; i < samples && g_audio_recovery_remaining != 0; i++) {
    uint32_t progressed = RTL_AUDIO_RECOVERY_RAMP -
                          g_audio_recovery_remaining + 1;
    uint32_t old_weight = RTL_AUDIO_RECOVERY_RAMP - progressed;
    audio_buffer[i * 2] = (int16)(((int32_t)g_audio_recovery_anchor_l *
                                   (int32_t)old_weight +
                                   (int32_t)audio_buffer[i * 2] *
                                   (int32_t)progressed) /
                                  (int32_t)RTL_AUDIO_RECOVERY_RAMP);
    audio_buffer[i * 2 + 1] = (int16)(((int32_t)g_audio_recovery_anchor_r *
                                       (int32_t)old_weight +
                                       (int32_t)audio_buffer[i * 2 + 1] *
                                       (int32_t)progressed) /
                                      (int32_t)RTL_AUDIO_RECOVERY_RAMP);
    g_audio_recovery_remaining--;
  }
  if (samples > 0) {
    g_audio_last_output_l = audio_buffer[(samples - 1) * 2];
    g_audio_last_output_r = audio_buffer[(samples - 1) * 2 + 1];
  }
  RtlApuUnlock();
}

/* Battery-backed SRAM + savestate slots live under RtlSaveRoot() (default
 * "saves/"). Netplay guests switch the root to "saves/netplay/" so host sync
 * cannot overwrite personal progress. Older builds named the SRAM after the
 * game's internal title ("smw" for every title); RtlMigrateLegacySram copies
 * that forward the first time the generic name is used under the main root. */
static char s_save_root[96] = "saves";

void RtlSetSaveRoot(const char *root) {
  if (!root || !root[0])
    snprintf(s_save_root, sizeof(s_save_root), "saves");
  else {
    snprintf(s_save_root, sizeof(s_save_root), "%s", root);
    /* Trim trailing slash */
    size_t n = strlen(s_save_root);
    while (n > 1 && (s_save_root[n - 1] == '/' || s_save_root[n - 1] == '\\')) {
      s_save_root[n - 1] = '\0';
      n--;
    }
  }
}

const char *RtlSaveRoot(void) { return s_save_root; }

void RtlEnsureSaveDir(void) {
#ifdef _WIN32
  /* Also ensure parent "saves" when root is saves/netplay */
  if (strncmp(s_save_root, "saves/", 6) == 0 || strncmp(s_save_root, "saves\\", 6) == 0)
    _mkdir("saves");
  _mkdir(s_save_root);
#else
  if (strncmp(s_save_root, "saves/", 6) == 0)
    mkdir("saves", 0755);
  mkdir(s_save_root, 0755);
#endif
}

void RtlSaveSlotPath(int slot, char *buf, size_t buflen) {
  const char *prefix = g_rtl_game_info ? g_rtl_game_info->save_name_prefix : NULL;
  if (prefix)
    snprintf(buf, buflen, "%s/%s%d.sav", s_save_root, prefix, slot);
  else if (g_rtl_game_info && g_rtl_game_info->title)
    snprintf(buf, buflen, "%s/%s_save%d.sav", s_save_root, g_rtl_game_info->title, slot);
  else
    snprintf(buf, buflen, "%s/save%d.sav", s_save_root, slot);
}

void RtlSramFilePath(char *buf, size_t buflen) {
  snprintf(buf, buflen, "%s/save.srm", s_save_root);
}

void RtlMigrateLegacySram(const char *legacy_title) {
  /* Only migrate into the main offline root — never into a netplay sandbox. */
  if (!legacy_title || !*legacy_title) return;
  if (strcmp(s_save_root, "saves") != 0) return;
  char cur_path[128];
  RtlSramFilePath(cur_path, sizeof(cur_path));
  FILE *cur = fopen(cur_path, "rb");
  if (cur) { fclose(cur); return; }   /* already on the generic name */
  char legacy[64];
  snprintf(legacy, sizeof(legacy), "saves/%s.srm", legacy_title);
  if (strcmp(legacy, cur_path) == 0) return;
  FILE *in = fopen(legacy, "rb");
  if (!in) return;
  RtlEnsureSaveDir();
  FILE *out = fopen(cur_path, "wb");
  if (!out) { fclose(in); return; }
  char buf[4096];
  size_t n;
  while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
    fwrite(buf, 1, n, out);
  fclose(in);
  fclose(out);
  fprintf(stderr, "[saves] migrated legacy %s -> %s\n", legacy, cur_path);
}

void RtlReadSram(void) {
  if (!g_sram || g_sram_size <= 0)
    return;
  char path[128];
  RtlMigrateLegacySram(g_rtl_game_info->title);
  RtlSramFilePath(path, sizeof(path));
  FILE *f = fopen(path, "rb");
  if (f) {
    if (fread(g_sram, 1, g_sram_size, f) != g_sram_size)
      fprintf(stderr, "Error reading %s\n", path);
    fclose(f);
  }
}

int RtlTryWriteSram(void) {
  if (!g_sram || g_sram_size <= 0)
    return 1;
  char path[128], bak[140], tmp[140];
  RtlEnsureSaveDir();
  RtlSramFilePath(path, sizeof(path));
  snprintf(bak, sizeof(bak), "%s.bak", path);
  snprintf(tmp, sizeof(tmp), "%s.tmp", path);
  FILE *f = fopen(tmp, "wb");
  if (!f) {
    fprintf(stderr, "Unable to write %s\n", tmp);
    return 0;
  }
  int ok = fwrite(g_sram, 1, g_sram_size, f) == (size_t)g_sram_size;
  ok = ok && fflush(f) == 0;
#ifdef _WIN32
  ok = ok && _commit(_fileno(f)) == 0;
#else
  ok = ok && fsync(fileno(f)) == 0;
#endif
  ok = fclose(f) == 0 && ok;
  if (!ok) {
    fprintf(stderr, "Unable to write %s\n", tmp);
    remove(tmp);
    return 0;
  }
  /* Keep exactly one previous revision. A missing current file (first save
   * in this namespace) is not an error. */
  remove(bak);
  FILE *cur = fopen(path, "rb");
  if (cur) {
    fclose(cur);
    if (rename(path, bak) != 0) {
      fprintf(stderr, "Unable to rotate %s to %s\n", path, bak);
      remove(tmp);
      return 0;
    }
  }
  if (rename(tmp, path) != 0) {
    fprintf(stderr, "Unable to publish %s\n", path);
    /* Put the previous revision back so the namespace still has a file. */
    rename(bak, path);
    remove(tmp);
    return 0;
  }
  return 1;
}

int RtlWriteSram(void) { return RtlTryWriteSram(); }

static const uint8 *SimpleHdma_GetPtr(uint32 p) {
  uint8 bank = (uint8)(p >> 16);
  uint16 addr = (uint16)(p & 0xffff);
  if (bank == 0x7E) return g_ram + addr;
  if (bank == 0x7F) return g_ram + 0x10000 + addr;
  if ((bank < 0x40 || (bank >= 0x80 && bank < 0xC0)) && addr < 0x2000)
    return g_ram + addr;
  return RomPtr(p);
}

/* RomPtr() mirrors the initial SNES address into the loaded cartridge, but
 * SimpleHdma_DoLine advances the returned host pointer directly. A malformed
 * or unterminated table can therefore step one byte past WRAM or the ROM
 * allocation. Validate every host-side read and treat the end of either
 * backing store like an HDMA table terminator. Use integer address arithmetic
 * here: relational comparisons between pointers to different C objects are
 * not portable. */
static bool SimpleHdma_PtrRangeValid(const uint8 *p, size_t length) {
  uintptr_t addr = (uintptr_t)p;
  uintptr_t ram_base = (uintptr_t)g_ram;
  if (addr >= ram_base) {
    size_t offset = (size_t)(addr - ram_base);
    if (offset <= sizeof(g_ram) && length <= sizeof(g_ram) - offset)
      return true;
  }

  uint32 rom_size = g_snes && g_snes->cart
                  ? (uint32)g_snes->cart->romSize : 0;
  uintptr_t rom_base = (uintptr_t)g_rom;
  if (g_rom && rom_size != 0 && addr >= rom_base) {
    size_t offset = (size_t)(addr - rom_base);
    if (offset <= rom_size && length <= (size_t)rom_size - offset)
      return true;
  }
  return false;
}

void SimpleHdma_Init(SimpleHdma *c, DmaChannel *dc) {
  /* Calling this IS the declaration that the host walks the HDMA tables in
   * its own raster loop, so the framework's beam must not walk them too:
   * every table would be consumed twice per line, once here and once from
   * snes_advance_beam inside any guest register write that syncs the master
   * clock. Measured in Super Metroid, that second pass re-ran the Ceres
   * shaft's BG-mode split from the wrong table entry and drew one frame in
   * eighty as full-screen garbage. Eight ports drive HDMA this way and none
   * of them had said so; inferring it here is the fix that reaches all of
   * them. A host that wants the beam to own HDMA simply does not call this.
   * Re-asserted per frame, which also survives a save-state load restoring
   * the Snes struct the flag lives in. */
  if (g_snes) snes_set_hdma_beam_enabled(g_snes, false);
  if (!dc->hdmaActive) {
    c->table = 0;
    return;
  }
  c->table = SimpleHdma_GetPtr(dc->aAdr | dc->aBank << 16);
  c->rep_count = 0;
  c->mode = dc->mode | dc->indirect << 6;
  c->ppu_addr = dc->bAdr;
  c->indir_bank = dc->indBank;
}

void SimpleHdma_DoLine(SimpleHdma *c) {
  static const uint8 bAdrOffsets[8][4] = {
    {0, 0, 0, 0},
    {0, 1, 0, 1},
    {0, 0, 0, 0},
    {0, 0, 1, 1},
    {0, 1, 2, 3},
    {0, 1, 0, 1},
    {0, 0, 0, 0},
    {0, 0, 1, 1}
  };
  static const uint8 transferLength[8] = {
    1, 2, 2, 4, 4, 4, 2, 4
  };

  if (c->table == NULL)
    return;
  bool do_transfer = false;
  if ((c->rep_count & 0x7f) == 0) {
    if (!SimpleHdma_PtrRangeValid(c->table, 1)) {
      c->table = NULL;
      return;
    }
    c->rep_count = *c->table++;
    if (c->rep_count == 0) {
      c->table = NULL;
      return;
    }
    if(c->mode & 0x40) {
      if (!SimpleHdma_PtrRangeValid(c->table, 2)) {
        c->table = NULL;
        return;
      }
      c->indir_ptr = SimpleHdma_GetPtr(c->indir_bank << 16 | c->table[0] | c->table[1] * 256);
      c->table += 2;
    }
    do_transfer = true;
  }
  if(do_transfer || c->rep_count & 0x80) {
    for(int j = 0, j_end = transferLength[c->mode & 7]; j < j_end; j++) {
      const uint8 *src = c->mode & 0x40 ? c->indir_ptr : c->table;
      if (!SimpleHdma_PtrRangeValid(src, 1)) {
        c->table = NULL;
        break;
      }
      uint8 v = *src;
      if (c->mode & 0x40)
        c->indir_ptr++;
      else
        c->table++;
      /* ppu_write takes the B-bus offset ($00-$3F), not a $21xx CPU address. */
      uint8 reg = (uint8)(c->ppu_addr + bAdrOffsets[c->mode & 7][j]);
      g_ppu_wlog_src = kPpuWlogHdma;
      ppu_write(g_ppu, reg, v);
      g_ppu_wlog_src = kPpuWlogCpu;
      debug_server_on_reg_write((uint16)(0x2100u + reg), v);
    }
  }
  c->rep_count--;
}
