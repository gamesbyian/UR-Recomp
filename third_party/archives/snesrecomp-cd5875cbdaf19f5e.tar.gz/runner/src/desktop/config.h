/* Adapted from snesrev/smw src/config.h (MIT, (c) 2023 snesrev, (c) 2021
 * elzo_d). See THIRD_PARTY_ATTRIBUTION.md; this project's own work here is
 * PolyForm Noncommercial, the retained upstream material stays MIT. */
#pragma once
/* Shared Mega Man X trilogy desktop configuration contract. */
#include "types.h"
#include "sdl_compat.h"
#include "display_aspect.h"

enum {
  kKeys_Null,
  kKeys_Controls,
  kKeys_Controls_Last = kKeys_Controls + 11,

  kKeys_ControlsP2,
  kKeys_ControlsP2_Last = kKeys_ControlsP2 + 11,

  kKeys_Load,
  kKeys_Load_Last = kKeys_Load + 19,
  kKeys_Save,
  kKeys_Save_Last = kKeys_Save + 19,
  kKeys_Fullscreen,
  kKeys_Reset,
  kKeys_Pause,
  kKeys_PauseDimmed,
  kKeys_Turbo,
  kKeys_WindowBigger,
  kKeys_WindowSmaller,
  kKeys_DisplayPerf,
  kKeys_ToggleRenderer,
  kKeys_ToggleWidescreen,
  kKeys_VolumeUp,
  kKeys_VolumeDown,
  /* Save-state slot browser (snes_savestate_menu.c). Appended here rather
   * than inserted above so the kKeys_Load / kKeys_Save 20-slot ranges keep
   * their numbering — those are index arithmetic, not just enum labels. */
  kKeys_SaveStateMenu,
  /* Local rewind filmstrip (snes_rewind.c). Appended for the same reason as
   * SaveStateMenu: the Load/Save ranges above are index arithmetic. */
  kKeys_Rewind,
  /* OpenGL-only framebuffer capture. Kept separate from the diagnostic
   * SNESRECOMP_SCREENSHOT path, which is driven by environment variables. */
  kKeys_Screenshot,
  /* Reopen the launcher mid-game (SnesDesktopHostGame.in_game_launcher).
   * Appended for the same reason as SaveStateMenu. */
  kKeys_OpenLauncher,
  kKeys_Total,
};

enum {
  kOutputMethod_SDL,
  kOutputMethod_SDLSoftware,
  kOutputMethod_OpenGL,
};

/* config.ini [Graphics] VSync. Off and On keep the historical 0/1 spellings so
 * an existing config.ini reads identically; Adaptive is written as the word,
 * and maps to a late-swap-tearing interval (-1) where the driver has one. */
enum {
  kSnesVSync_Off = 0,
  kSnesVSync_On = 1,
  kSnesVSync_Adaptive = 2,
};

typedef struct Config {
  int window_width;
  int window_height;
  bool new_renderer;
  bool ignore_aspect_ratio;
  uint8 display_aspect;
  uint8 fullscreen;
  uint8 window_scale;
  bool enable_audio;
  bool linear_filtering;
  uint8 output_method;
  uint16 audio_freq;
  uint8 audio_channels;
  uint16 audio_samples;
  bool autosave;
  bool no_sprite_limits;
  // Render genuine extra PPU columns to match the current display aspect.
  // This is host presentation state, not emulated game state.
  bool widescreen;
  bool display_perf_title;

  // Skip the per-frame SDL_Delay pacing. Off by default (pacing on) so audio
  // stays in sync; cfg-only escape hatch (DisableFrameDelay = 1) for users on
  // an exactly-60 Hz / vsync-correct display who want the perf.
  bool disable_frame_delay;

  // Boot straight to the game, skipping the GUI launcher, on subsequent runs.
  // Set from the launcher's dashboard checkbox. Force the launcher back with the
  // --launcher argument or by setting SkipLauncher = 0 in config.ini.
  bool skip_launcher;
  bool expose_coverage_mod;
  int coverage_capture; /* -1 absent: use Mods selection */

  /* Netplay display name, persisted so the lobby does not prompt on every
   * launch. Framework-owned (config.ini [Netplay] PlayerName) so every SNES
   * port inherits it — the alternative was a copy of this field in each
   * game's own config, which is how MetalWarriors carried it. */
  char netplay_player_name[64];

  /* Rewind's controller gesture, config.ini [Controller] RewindGesture:
   * pad buttons joined with '+', e.g. "Select+R3" (the default when empty),
   * or "none". The host parses it; the SNES pad has no stick buttons, so
   * L3/R3 come from the gamepad itself. */
  char rewind_gesture[64];
  /* [Controller] LauncherGesture: the same syntax, opening the launcher
   * mid-game for a host that offers it (default "Select+L3"). */
  char launcher_gesture[64];

  /* Presentation and emulation options the desktop host offers through the
   * launcher's Display page, persisted by WriteConfigFile:
   *   [Graphics] FrameBlend  average each presented frame with the previous
   *                          one (alternate-frame flicker reads as translucency)
   *   [Graphics] VSync       driver vsync at present time (default on);
   *                          tri-state, kSnesVSync_* below. The launcher has
   *                          offered Off/On/Adaptive for as long as the row
   *                          has existed; this host used to store a bool, so
   *                          Adaptive silently came back as On on the next
   *                          launch. Legacy 0/1/true/false spellings still
   *                          read exactly as before.
   *   [Graphics] Renderer    "auto" (SDL's pick), "opengl" (the native GL
   *                          presenter), "software", or an SDL render driver
   *                          name such as "vulkan"; empty follows OutputMethod
   *   [General]  RunAhead    frames of local input-latency hiding (0 = off)
   * The [Video] / [Emulation] spellings a per-game host used for the same
   * settings are accepted on read. */
  bool frame_blend;
  uint8 vsync;

  /* config.ini [Rewind], for a host whose descriptor sets rewind_settings.
   * The ring holds whole-machine snapshots on a frame cadence, so depth and
   * interval are memory decisions, not cosmetics. Seeded from snes_rewind.c's
   * own defaults; a port that wants rewind off out of the box ships
   * `Enabled = 0` in its default_config_ini rather than changing these. */
  bool rewind_enabled;
  int rewind_depth;
  int rewind_interval;
  int run_ahead;
  char renderer[32];
  /* [Sound] Volume, 0..100 (default 100): the mixer level the VolumeUp /
   * VolumeDown keys move in 5% steps and the launcher's slider edits. */
  int volume;

  /* Oracle-build only. When false, main.c skips snes_oracle_init_default
   * and calls snes_oracle_set_disabled_by_game so the dispatcher refuses
   * every emu_* command with a structured warning naming the reason. For
   * MMX, this defaults to OFF in mmx.ini because the freeze repro path
   * is save-state load, which the from-boot oracle cannot follow — a
   * prior session wasted real time chasing false divergences before
   * noticing. See snes_oracle_backend.h header doc. */
  bool enable_snes9x_oracle;

  char *memory_buffer;
  const char *shader;

  bool enable_gamepad[2];
  /* Which input device drives each player, from config.ini [Controller]
   * SourceP1/SourceP2 as the launcher writes it: 0 none, 1 keyboard,
   * 2 gamepad. Player 1 defaults to keyboard so a config without the section
   * behaves as it always did; player 2 defaults to none, because a second
   * keyboard player sharing one keyboard has to be asked for. */
  int player_src[2];
  int gamepad_deadzone;

  // Which players have keyboard controls
  uint8 has_keyboard_controls;
} Config;

enum {
  kGamepadBtn_Invalid = -1,
  kGamepadBtn_A,
  kGamepadBtn_B,
  kGamepadBtn_X,
  kGamepadBtn_Y,
  kGamepadBtn_Back,
  kGamepadBtn_Guide,
  kGamepadBtn_Start,
  kGamepadBtn_L3,
  kGamepadBtn_R3,
  kGamepadBtn_L1,
  kGamepadBtn_R1,
  kGamepadBtn_DpadUp,
  kGamepadBtn_DpadDown,
  kGamepadBtn_DpadLeft,
  kGamepadBtn_DpadRight,
  kGamepadBtn_L2,
  kGamepadBtn_R2,
  kGamepadBtn_Count,
};

extern Config g_config;

void ConfigUseStateMenuDefaults(void);
/* Opt in before parsing: binds [KeyMap] OpenLauncher to Ctrl+L by default. */
void ConfigUseInGameLauncherDefaults(void);
void ParseConfigFile(const char *filename);
// Re-apply only the [KeyMap] section (launcher hotkey editor wrote it after
// the initial parse). Keyboard command map is rebuilt; gamepad map and all
// scalar settings are left alone.
void ConfigReloadKeyMap(const char *filename);
// Re-apply only the [GamepadMap] button bindings (the launcher's controller
// page wrote them after the initial parse). The gamepad command map is
// rebuilt; every scalar setting, EnableGamepadN and the deadzone included,
// keeps its live value.
void ConfigReloadGamepadMap(const char *filename);
/* True when ParseConfigFile read a [KeyMap] line that carried a former
 * generated default and mapped it to the current one; WriteConfigFile then
 * rewrites that line. The host writes the file once when this is set. */
bool ConfigKeyMapMigrated(void);
/* True when the file carried the former generated GamepadDeadzone (10000 raw
 * units, 30%) and it was read as the current default instead. The caller
 * rewrites config.ini once so the file says what the game is using. */
bool ConfigDeadzoneMigrated(void);

/* True when config.ini actually named [Controller] SourceP<player+1>. A file
 * written before this key existed has not said anything about the player's
 * device, and the caller falls back to the older EnableGamepadN spelling
 * rather than to the seeded default. player is 0 or 1. */
bool ConfigHasPlayerSource(int player);

/* Opt in to persisting [Rewind]. A host that does not offer the launcher's
 * rewind rows never calls this, and WriteConfigFile then leaves whatever the
 * file says about rewind exactly as it found it. */
void ConfigEnableRewindKeys(void);

/* Analog stick deadzone, in raw axis units of a 32767 full scale. 10% is the
 * default because it clears a resting stick on the pads players actually own
 * without eating a third of the throw, which 10000 (30%) did. */
#define SNES_CONFIG_DEFAULT_DEADZONE 3277
#define SNES_CONFIG_LEGACY_DEADZONE  10000
// Persist the launcher-editable settings back into `filename` (or config.ini)
// with a surgical, comment-preserving in-place update. Called after the GUI
// launcher returns PLAY.
void WriteConfigFile(const char *filename);
int FindCmdForSdlKey(SDL_Keycode code, SDL_Keymod mod);
int FindCmdForGamepadButton(int button, uint32 modifiers);
