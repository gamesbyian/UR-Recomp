#ifndef PPU_H
#define PPU_H

#include "../types.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "saveload.h"

typedef struct Ppu Ppu;
typedef struct PpuMode7HdSurface {
  uint32_t *pixels;
  size_t pitch; /* Bytes, including optional row padding. */
  unsigned width, height; /* Native dimensions, before scale. */
  unsigned scale;
} PpuMode7HdSurface;
typedef void PpuWidescreenLineEnhancer(Ppu *ppu, uint y, bool sub,
                                       void *context);

typedef struct BgLayer {
  uint16_t xhScroll;
  uint16_t xvScroll;
  bool xtilemapWider;
  bool xtilemapHigher;
  uint16_t xtilemapAdr;
  uint16_t xtileAdr;
  bool xxbigTiles;
  bool xxmosaicEnabled;
} BgLayer;

enum {
  kPpuXPixels = 256,
  // Maximum widescreen expansion *per side*, baked into the priority-buffer
  // capacity. This is a compile-time ceiling only; the actual extra columns
  // rendered each frame are the runtime ppu->extraLeftCur/extraRightCur, which
  // default to 0 (authentic 256-wide output). 272 per side allows up to an
  // 800-pixel internal width for opt-in 32:9 presentation.
  kPpuExtraLeftRight = 272,
  // Full internal width of the priority buffers (logical 256 + both borders).
  kPpuBufWidth = kPpuXPixels + kPpuExtraLeftRight * 2,
  // Split-screen games can assign distinct anchor layouts to each viewport.
  kPpuWsAnchorBands = 2,
  // Number of stopped frames tolerated after a moving unhinted OBJ reaches the
  // left widened margin.
  kPpuWsOamMovingGraceFrames = 4,
  // A layer may need more than one authored-world span per frame (e.g. an
  // arena strip above a status bar and a second one below it).
  kPpuWsWorldBands = 2,
  // Elastic anchor bands (see PpuSetWidescreenLayerElasticBand). A raster
  // status bar needs one band per tile row whose horizontal layout differs,
  // plus one identity band per transitional line: GWED's fight HUD uses five.
  kPpuWsElasticBands = 6,
  // Piecewise segments per elastic band. Five is what a symmetric
  // rigid/elastic/centre/elastic/rigid split costs; the spare room is for
  // layouts that need more than one stretchable run per side.
  kPpuWsElasticSegs = 8,
};

// One piece of an elastic anchor band's horizontal mapping: destination
// columns [dstX0,dstX1) of the widened line are produced from source columns
// [srcX0,srcX1) of the native 256-px rendered line. Equal widths copy 1:1 --
// a RIGID segment, shifted if dstX0 != srcX0. A wider destination resamples
// (nearest neighbour, integer math) -- an ELASTIC segment.
typedef struct PpuWsElasticSeg {
  int16_t srcX0, srcX1;   // source columns, within [0,256]
  int16_t dstX0, dstX1;   // destination columns, within [-extraLeft,256+extraRight]
} PpuWsElasticSeg;

typedef uint16_t PpuZbufType;

typedef struct PpuPixelPrioBufs {
  // This holds the prio in the upper 8 bits and the color in the lower 8 bits.
  // Sized for the widescreen border; logical screen x maps to
  // data[x + kPpuExtraLeftRight].
  //
  // 8-aligned because ClearBackdrop fills this through a uint64 pointer.
  // The array itself only needs 2, so any member landing on a 4-mod-8
  // offset aborts on ARM -- and which ones do shifts whenever a field
  // above them grows.
  PpuZbufType data[kPpuBufWidth];
} __attribute__((aligned(8))) PpuPixelPrioBufs;

static inline void PpuWidescreenAdjustPinnedWindowEdges(
    int screen_left, int screen_right, int *w1l, int *w1r, int *w2l,
    int *w2r) {
  if (screen_left == 0 && screen_right == kPpuXPixels)
    return;
  if (*w1l == 0) *w1l = screen_left;
  if (*w1r == kPpuXPixels - 1) *w1r = screen_right - 1;
  if (*w2l == 0) *w2l = screen_left;
  if (*w2r == kPpuXPixels - 1) *w2r = screen_right - 1;
}

/* Renderer-neutral host-overlay extraction. BG source values deliberately
 * match the PPU layer indices; OBJ is the fifth screen layer. Each source can
 * own one screen-space capture rectangle and one full-frame ARGB destination
 * surface. A caller can crop several independently placed graphics from one
 * captured bounding rectangle after scanout. */
typedef enum PpuOverlaySource {
  kPpuOverlaySource_Bg1 = 0,
  kPpuOverlaySource_Bg2 = 1,
  kPpuOverlaySource_Bg3 = 2,
  kPpuOverlaySource_Bg4 = 3,
  kPpuOverlaySource_Obj = 4,
  kPpuOverlaySource_Count = 5,
} PpuOverlaySource;

enum {
  /* Do not merge captured pixels back into either main or subscreen. The host
   * can then reinsert them without a duplicate remaining in renderBuffer. */
  kPpuOverlayFlag_RemoveFromGame = 1,
};

typedef struct PpuOverlayCapture {
  /* SNES screen coordinates after scroll/window/mosaic processing. X may be
   * negative or exceed 255 when a widescreen margin is active. Endpoints are
   * exclusive. y uses visible output coordinates (0 is the first scanline). */
  int16_t x0, x1;
  int16_t y0, y1;
  uint8_t flags;
  /* OBJ-only selector. Arming selects all objects for compatibility. Titles
   * can select a semantic slot range explicitly; count zero selects none. */
  uint8_t oamFirst, oamCount;
} PpuOverlayCapture;

enum {
  kPpuRenderFlags_NewRenderer = 1,
  // Preserve the established bit value for config/save compatibility.
  kPpuRenderFlags_NoSpriteLimits = 8,
};

typedef struct Layer {
  bool xmainScreenEnabled;
  bool xsubScreenEnabled;
  bool xmainScreenWindowed;
  bool xsubScreenWindowed;
} Layer;

typedef struct WindowLayer {
  bool xwindow1enabled;
  bool xwindow2enabled;
  bool xwindow1inversed;
  bool xwindow2inversed;
  uint8_t xmaskLogic;
} WindowLayer;

#define PPU_SAVESTATE_REGS_SIZE 0x40
#define PPU_SAVESTATE_MEM_SIZE 0x10420

struct Ppu {
  // Snes registers. Saved to snapshot. Need to be stable
  // -- START OF SNAPSHOT, 0x40 bytes
  uint8 inidisp;
  uint8 obsel;
  uint8 oamaddl;
  uint8 oamaddh;
  uint8 bgmode;
  uint8 mosaic;
  uint8 bgXsc[4];
  uint16 bgTileAdr;
  uint8 m7sel;
  uint8 setini;
  uint16 hScroll[4];
  uint16 vScroll[4];
  int16_t m7matrix[8]; // a, b, c, d, x, y, h, v
  uint16 fixedColor;
  uint32 windowsel;
  uint8 window1left;
  uint8 window1right;
  uint8 window2left;
  uint8 window2right;
  uint16 wbgobjlog;
  uint8 screenEnabled[2];
  uint8 screenWindowed[2];
  uint8 cgadsub;
  uint8 cgwsel;
  // -- END OF SNAPSHOT

  // vram access
  uint16_t vramPointer;
  bool vramIncrementOnHigh;
  uint8_t vramRemapMode;
  uint8_t vramIncrement;
  uint16_t vramReadBuffer;
  // cgram access
  uint8_t cgramPointer;
  bool cgramSecondWrite;
  uint8_t cgramBuffer;
  // oam access
  uint8_t oamAdr;
  bool oamInHigh;
  bool oamSecondWrite;
  uint8_t oamBuffer;
  bool timeOver;
  bool rangeOver;
  uint8_t scrollPrev;
  uint8_t scrollPrev2;
  uint8_t mosaicStartLine;
  uint8_t m7prev;
  // mode 7 internal
  int32_t m7startX;
  int32_t m7startY;
  // settings
  bool evenFrame;
  bool frameOverscan; // if we are overscanning this frame (determined at 0,225)
  bool frameInterlace; // if we are interlacing this frame (determined at start vblank)
  // latching
  uint16_t hCount;
  uint16_t vCount;
  bool hCountSecond;
  bool vCountSecond;
  bool countersLatched;
  // pixel buffer (xbgr)
  // times 2 for even and odd frame

  uint16_t extraLeftCur, extraRightCur, extraLeftRight;
  uint8_t extraBottomCur;
  // Widescreen BG3 HUD split (see PpuSetWidescreenHudSplit). 0 height = off.
  uint8_t wsHudSplitHeight, wsHudLeftEnd, wsHudRightStart;
  // Widescreen HUD OAM anchor (see PpuSetWsHudOamShiftRange): an OAM slot
  // range near either native screen edge can move outward with the live
  // margins. Its vertical band can be decoupled from the BG3 split for games
  // whose HUD is sprite-only while BG3 carries dialogue. 0 slots/height = off.
  // A second, independently published range exists for HUD elements the game
  // allocates OUTSIDE its fixed HUD reserve (e.g. MMX boss health bars are
  // general-pool objects at OAM 16+); both ranges share the band/thresholds.
  uint8_t wsHudOamFirstSlot, wsHudOamSlots, wsHudOamHeight;
  uint8_t wsHudOamFirstSlot2, wsHudOamSlots2;
  // Widescreen BG3 widen (see PpuSetWidescreenBg3Widen). Scanlines >= this let
  // BG3 (layer 2) extend into the side margins like BG1/BG2 instead of staying
  // clamped to the authentic 256-wide region. 0 = off (BG3 clamped everywhere,
  // so a BG3 status bar never tiles into the margins). SMW sets it to the HUD
  // band height so water/level content on BG3 below the bar fills 16:9.
  uint8_t wsBg3WidenY;
  // Optional bitmask of BG layers allowed to render in the side margins.
  // Zero preserves the default behavior (BG1/BG2 wide, BG3 policy above).
  uint8_t wsLayerWidenMask;
  // Optional native-width Mode 2 layer capture. Stored as layer+1 so zero is
  // disabled; pixels are palette indices for the most recently drawn frame.
  uint8_t wsMode2CaptureLayer;
  uint8_t wsMode2Capture[224][kPpuXPixels];
  uint8_t wsMode2Bg1Palette[224][kPpuXPixels];
  // Per-layer widescreen policies. Bit L refers to BG(L+1), layer 0..3.
  // Clamp keeps a layer in the authentic 256 columns. Mirror/repeat render
  // the authentic scanline in isolation and use it to fill the side margins.
  uint8_t wsLayerClamp, wsLayerMirror, wsLayerRepeat;
  // Optional scanline bands: clamp or cyclically repeat only [y0,y1).
  uint8_t wsClampY0[4], wsClampY1[4];
  uint8_t wsRepeatY0[4], wsRepeatY1[4];
  // Optional scanline bands: scale a native-width layer across the full
  // widescreen budget. Used for full-screen liquid/effect planes.
  uint8_t wsStretchY0[4], wsStretchY1[4];
  // Optional scanline bands: anchor a layer's left/right chunks to the
  // expanded viewport edges while retaining its middle chunk at native x.
  uint8_t wsAnchorY0[kPpuWsAnchorBands][4];
  uint8_t wsAnchorY1[kPpuWsAnchorBands][4];
  uint8_t wsAnchorLeftEnd[kPpuWsAnchorBands][4];
  uint8_t wsAnchorRightStart[kPpuWsAnchorBands][4];
  // Skip offscreen staging columns before sampling a layer's side margins.
  uint8_t wsMarginGapL[4], wsMarginGapR[4];
  // Authored-world spans, in tilemap pixels, for the world-mirror bands (see
  // PpuSetWidescreenLayerWorldMirrorBand). y1<=y0 or right<=left = off.
  uint8_t wsWorldY0[kPpuWsWorldBands][4], wsWorldY1[kPpuWsWorldBands][4];
  uint16_t wsWorldLeft[kPpuWsWorldBands][4];
  uint16_t wsWorldRight[kPpuWsWorldBands][4];
  // Piecewise horizontal remaps for the elastic anchor bands (see
  // PpuSetWidescreenLayerElasticBand). nseg == 0 or y1 <= y0 = slot off.
  uint8_t wsElasticY0[kPpuWsElasticBands][4];
  uint8_t wsElasticY1[kPpuWsElasticBands][4];
  uint8_t wsElasticNSeg[kPpuWsElasticBands][4];
  PpuWsElasticSeg wsElasticSeg[kPpuWsElasticBands][4][kPpuWsElasticSegs];
  // Treat [left_px, 256-right_px) as a layer's authentic visible viewport
  // when a host line enhancer supplies the expanded scene. This lets the
  // layer's normally hidden/blank native edge columns reveal lower layers.
  uint8_t wsViewportInsetL[4], wsViewportInsetR[4];
  // Presentation-only expansion of game-authored window edges into the side
  // margins. Layer bits use the PPU window layer numbering (BG1..BG4, OBJ,
  // color); window bits select W1/W2. Zero is the hardware-authentic default.
  uint8_t wsWindowExpandLayers, wsWindowExpandWindows;
  // Strict decode of ambiguous left-margin OAM positions. A NULL hint pointer
  // disables strict mode; a zeroed hint array enables strict mode with no slots
  // explicitly allowed.
  // Host switch for the temporal fallback below. 1 (the default) lets an
  // unhinted moving OBJ into the margins; 0 admits ONLY hinted slots.
  // Screens whose margin content the host can enumerate exactly should
  // turn it off -- a heuristic there shows sprites while the screen moves
  // and hides them when it stops.
  uint8_t wsOamMotionGraceOn;
  uint8_t wsOamLeftHintStrict;
  uint8_t wsOamLeftHint[16];
  // Strict decode of the ambiguous 9-bit OAM X band [256, 256+extraRightCur).
  // A raw value there is either a genuine right-margin sprite (widescreen
  // host emitted it on purpose) or a sprite the game parked off-screen-left
  // at x-512 (invisible on hardware). When strict is set, only slots marked
  // in wsOamRightHint keep the positive decode; unmarked slots wrap negative
  // like hardware, so parked sprites don't ghost into the right margin.
  // Default off preserves the legacy always-positive band (SMW relies on it).
  // Games publish per NMI via PpuWsSetOamRightHints. 1 bit per OAM slot.
  uint8_t wsOamRightHintStrict;
  uint8_t wsOamRightHint[16];
  /* Host-only temporal classifier for unhinted left-margin OBJ. It lets a
   * game-authored sprite keep moving through the widened margin, then parks it
   * again after its X stops changing for a few frames. */
  int16_t wsOamMotionLastLine;
  int16_t wsOamMotionX[128];
  uint32_t wsOamMotionSig[128];
  uint8_t wsOamMotionSeen[16];
  uint8_t wsOamMotionGrace[128];
  uint8_t lastMosaicModulo;
  uint8_t lastBrightnessMult;
  bool lineHasSprites;
  // Active kPpuRenderFlags_* set by PpuBeginDrawing. Kept outside the stable
  // snapshot region because it is host rendering policy, not emulated state.
  uint32_t renderFlags;
  PpuPixelPrioBufs bgBuffers[2];
  PpuPixelPrioBufs objBuffer;
  /* Per-source isolated priority pixels for generic host-overlay captures. */
  PpuPixelPrioBufs overlayBuffers[kPpuOverlaySource_Count];
  PpuOverlayCapture overlayCaptures[kPpuOverlaySource_Count];
  uint32_t renderPitch;
  uint8_t *renderBuffer;
  /* Optional additional presentation surface; never part of guest state. */
  PpuMode7HdSurface mode7Hd;
  /* Optional host picture memory. Drawing only: CPU ports and save states
   * always use vram. The caller owns 32768 words until unbound. */
  const uint16_t *renderVram;
  uint32_t overlayRenderPitch[kPpuOverlaySource_Count];
  uint8_t *overlayRenderBuffer[kPpuOverlaySource_Count];
  uint8_t brightnessMult[32 + 31];
  uint8_t brightnessMultHalf[32 * 2];
  uint8_t mosaicModulo[kPpuXPixels];

  // Host-only widescreen state; excluded from savestates and cleared by reset.
  PpuWidescreenLineEnhancer *widescreenLineEnhancer;
  void *widescreenLineEnhancerContext;

  /* Host-only: bumped on every VRAM store (the $2118/$2119 ports, the 16-bit
   * fast path, and a save-state load). A frame-model host that snapshots the
   * picture per raster line compares it to tell whether VRAM changed since
   * its last copy -- a title that uploads character data in a mid-frame
   * forced blank (Yoshi's Island, line 217) otherwise gets one frame's OAM
   * drawn with the next frame's tiles. Not guest state; never serialized. */
  uint32_t vramWriteCount;
  /* Host-only, same rule, for OAM ($2104, and a save-state load). Tells a
   * host WHEN the sprite table it is drawing was uploaded, so it can pair it
   * with whatever produced it. */
  uint32_t oamWriteCount;

  // -- START OF SNAPSHOT, 0x10420 bytes
  uint16_t cgram[0x100];
  uint16_t oam[0x100];
  uint8_t highOam[0x20];
  uint16_t vram[0x8000];
  // -- END OF SNAPSHOT


};

#define SPRITE_PRIO_TO_PRIO(prio, level6) (((prio) * 4 + 2) * 16 + 4 + (level6 ? 2 : 0))
#define SPRITE_PRIO_TO_PRIO_HI(prio) ((prio) * 4 + 2)

// Host-only debug render filter (SNESRECOMP_LAYER_MASK env; ppu.c). Guest
// state and savestates are untouched — this only gates final composition.
static inline const uint16_t *PpuRenderVram(const Ppu *ppu) {
  return ppu->renderVram ? ppu->renderVram : ppu->vram;
}
extern uint8_t g_snes_ppu_dbg_layer_mask;
#define IS_SCREEN_ENABLED(ppu, sub, layer) \
  (ppu->screenEnabled[sub] & g_snes_ppu_dbg_layer_mask & (1 << layer))
#define IS_SCREEN_WINDOWED(ppu, sub, layer) (ppu->screenWindowed[sub] & (1 << layer))
#define GET_WINDOW_FLAGS(ppu, layer) (ppu->windowsel >> (layer * 4))

#define PPU_brightness(ppu) (ppu->inidisp & 0xf)
#define PPU_forcedBlank(ppu) (ppu->inidisp & 0x80)

#define PPU_objSize(ppu) (ppu->obsel >> 5)
#define PPU_objTileAdr1(ppu) ((ppu->obsel & 7) << 13)
#define PPU_objTileAdr2(ppu) (PPU_objTileAdr1(ppu) + (((ppu->obsel & 0x18) + 8) << 9))

#define PPU_objPriority(ppu) (ppu->oamaddh & 0x80)

#define PPU_mode(ppu) (ppu->bgmode & 7)
#define PPU_bg3priority(ppu) (ppu->bgmode & 0x8)
#define PPU_bigTiles(ppu, layer) (ppu->bgmode >> layer & 0x10)

#define PPU_mosaicEnabled(ppu, layer) (ppu->mosaic & (1 << layer))
#define PPU_mosaicSize(ppu) ((ppu->mosaic >> 4) + 1)

#define PPU_bgTilemapWider(ppu, layer) (ppu->bgXsc[layer] & 0x1)
#define PPU_bgTilemapHigher(ppu, layer) (ppu->bgXsc[layer] & 0x2)
#define PPU_bgTilemapAdr(ppu, layer) ((ppu->bgXsc[layer] & 0xfc) << 8)
#define PPU_bgTileAdr(ppu, layer) ((ppu->bgTileAdr >> (layer * 4) & 0xf) << 12)

#define PPU_m7xFlip(ppu) (ppu->m7sel & 0x1)
#define PPU_m7yFlip(ppu) (ppu->m7sel & 0x2)
#define PPU_m7charFill(ppu) (ppu->m7sel & 0x40)
#define PPU_m7largeField(ppu) (ppu->m7sel & 0x80)

#define PPU_directColor(ppu) ((ppu->cgwsel & 0x1) != 0)
#define PPU_addSubscreen(ppu) ((ppu->cgwsel & 0x2) != 0)
#define PPU_preventMathMode(ppu) (ppu->cgwsel >> 4 & 0x3)
#define PPU_clipMode(ppu) (ppu->cgwsel >> 6 & 0x3)

#define PPU_mathEnabled(ppu) (ppu->cgadsub & 0x3f)
#define PPU_halfColor(ppu) ((ppu->cgadsub & 0x40) != 0)
#define PPU_subtractColor(ppu) ((ppu->cgadsub & 0x80) != 0)

#define PPU_fixedColorR(ppu) (ppu->fixedColor & 0x1f)
#define PPU_fixedColorG(ppu) (ppu->fixedColor >> 5 & 0x1f)
#define PPU_fixedColorB(ppu) (ppu->fixedColor >> 10 & 0x1f)

#define PPU_interlace(ppu) ((ppu->setini & 0x1) != 0)
#define PPU_objInterlace(ppu) ((ppu->setini & 0x2) != 0)
#define PPU_overscan(ppu) ((ppu->setini & 0x4) != 0)
#define PPU_pseudoHires(ppu) ((ppu->setini & 0x8) != 0)
#define PPU_m7extBg(ppu) ((ppu->setini & 0x40) != 0)

static inline bool PpuWidescreenLayerRepeatBandActive(
    const Ppu *ppu, unsigned int layer, int y) {
  return layer < 4 &&
      ppu->wsRepeatY1[layer] > ppu->wsRepeatY0[layer] &&
      y >= ppu->wsRepeatY0[layer] && y < ppu->wsRepeatY1[layer];
}

static inline bool PpuWidescreenLayerStretchBandActive(
    const Ppu *ppu, unsigned int layer, int y) {
  return layer < 4 &&
      ppu->wsStretchY1[layer] > ppu->wsStretchY0[layer] &&
      y >= ppu->wsStretchY0[layer] && y < ppu->wsStretchY1[layer];
}

static inline bool PpuWidescreenLineRepeatBandActive(const Ppu *ppu, int y) {
  for (unsigned int layer = 0; layer < 4; layer++) {
    if (PpuWidescreenLayerRepeatBandActive(ppu, layer, y) ||
        PpuWidescreenLayerStretchBandActive(ppu, layer, y))
      return true;
  }
  return false;
}

static inline int PpuWidescreenLayerExtra(
    const Ppu *ppu, unsigned int layer, int y, int extra) {
  if (layer < 4) {
    if (ppu->wsLayerWidenMask &&
        !(ppu->wsLayerWidenMask & (1u << layer)))
      return 0;
    if ((ppu->wsLayerClamp | ppu->wsLayerMirror | ppu->wsLayerRepeat) &
        (1u << layer))
      return 0;
    if (ppu->wsClampY1[layer] > ppu->wsClampY0[layer] &&
        y >= ppu->wsClampY0[layer] && y < ppu->wsClampY1[layer])
      return 0;
    if (PpuWidescreenLayerRepeatBandActive(ppu, layer, y) ||
        PpuWidescreenLayerStretchBandActive(ppu, layer, y))
      return 0;
  }
  if (layer != 2)
    return extra;
  return (ppu->wsBg3WidenY && y >= ppu->wsBg3WidenY) ? extra : 0;
}

// Which world-mirror band, if any, governs BG(layer+1) on scanline y.
// Returns the band slot, or -1 for natural (unreflected) tilemap rendering.
// Deliberately inert unless a side margin is actually live, and every other
// per-line policy wins over this one: on a line the layer does not widen
// (layer mask, clamp, mirror, repeat, stretch, BG3-widen) there is no margin
// to reflect into, and the line's hScroll may not even be the world camera --
// a raster-split status bar pinned to hScroll 0 is the usual case.
static inline int PpuWidescreenLayerWorldBandAt(
    const Ppu *ppu, unsigned int layer, int y) {
  if (layer >= 4 || !(ppu->extraLeftCur | ppu->extraRightCur))
    return -1;
  int widest = ppu->extraLeftCur > ppu->extraRightCur ? ppu->extraLeftCur
                                                      : ppu->extraRightCur;
  if (!PpuWidescreenLayerExtra(ppu, layer, y, widest))
    return -1;
  for (unsigned int slot = 0; slot < kPpuWsWorldBands; slot++) {
    if (ppu->wsWorldY1[slot][layer] > ppu->wsWorldY0[slot][layer] &&
        y >= ppu->wsWorldY0[slot][layer] &&
        y < ppu->wsWorldY1[slot][layer] &&
        ppu->wsWorldRight[slot][layer] > ppu->wsWorldLeft[slot][layer])
      return (int)slot;
  }
  return -1;
}

// Which elastic anchor band, if any, governs BG(layer+1) on scanline y.
// Returns the band slot, or -1 for the ordinary (unremapped) merge.
// Inert unless a side margin is live. Deliberately shares the world band's
// precedence rule -- clamp band, layer mask, mirror/repeat/stretch and the
// BG3-widen gate all win over this one -- so a game excludes a line from the
// remap exactly the way it excludes one from a world band. Where the two do
// overlap the elastic band wins, because it is the more specific statement
// about the same scanline: the world band describes a scrolling plane and the
// elastic band a raster-split status bar pinned to its own scroll.
static inline int PpuWidescreenLayerElasticBandAt(
    const Ppu *ppu, unsigned int layer, int y) {
  if (layer >= 4 || !(ppu->extraLeftCur | ppu->extraRightCur))
    return -1;
  int widest = ppu->extraLeftCur > ppu->extraRightCur ? ppu->extraLeftCur
                                                      : ppu->extraRightCur;
  if (!PpuWidescreenLayerExtra(ppu, layer, y, widest))
    return -1;
  for (unsigned int slot = 0; slot < kPpuWsElasticBands; slot++) {
    if (ppu->wsElasticNSeg[slot][layer] &&
        ppu->wsElasticY1[slot][layer] > ppu->wsElasticY0[slot][layer] &&
        y >= ppu->wsElasticY0[slot][layer] &&
        y < ppu->wsElasticY1[slot][layer])
      return (int)slot;
  }
  return -1;
}


enum {
  kWindow1Inversed = 1,
  kWindow1Enabled = 2,
  kWindow2Inversed = 4,
  kWindow2Enabled = 8,
};


Ppu* ppu_init(void);
void ppu_free(Ppu* ppu);
void ppu_reset(Ppu* ppu);
bool ppu_checkOverscan(Ppu* ppu);
void ppu_handleVblank(Ppu* ppu);
void ppu_runLine(Ppu* ppu, int line);

/* Bind an additional XRGB8888 frame with 1..4 samples per native pixel in
 * each dimension. Width is 256 + twice the current centering budget; height
 * is 1..240. The caller owns pixels and must unbind before freeing them.
 * Returns false without changing the binding on invalid dimensions/capacity.
 * NULL disables HD; reset preserves the binding, just like renderBuffer.
 * Ordinary Mode 7 is resampled from picture memory. Other modes and unsupported
 * combinations use nearest-neighbor copies of the normal scanout. Scale 1 is
 * always a byte-exact copy. The normal output and emulated state are unchanged.
 * Call again after changing the native viewport width. */
bool PpuBindMode7HdSurface(Ppu *ppu, uint32_t *pixels, size_t capacity,
                            size_t pitch, unsigned width, unsigned height,
                            unsigned scale);
void ppu_sec_reset(void);
void ppu_sec_read(double *eval, double *line, double *bg, double *spr,
                  double *compose, double *hdma);
uint8_t ppu_read(Ppu* ppu, uint8_t adr);
void ppu_write(Ppu* ppu, uint8_t adr, uint8_t val);
/* Notified on every CPU write to VRAM through $2118/$2119, with the BYTE
 * address written and the value. Mirrors snes_set_wram_write_log_hook():
 * a host can name the instruction responsible, which the AOT-side
 * watchpoints cannot do on the interp816 path. Unset by default. */
typedef void (*PpuVramWriteLogHook)(uint32_t byte_addr, uint8_t value);
void ppu_set_vram_write_log_hook(PpuVramWriteLogHook hook);

/* Raster journal — per-line replay of mid-frame INIDISP writes for frame-model
 * hosts. See the block comment in ppu.c. Host calls Begin after its
 * vblank-edge work and ApplyLine in its render loop; the register write path
 * calls Record with the beam line. */
void ppu_rasterBegin(Ppu *ppu);
void ppu_rasterRenderBegin(Ppu *ppu);
int  ppu_rasterTakeHdmaen(uint8_t *out);
void ppu_rasterRecord(uint16_t reg, uint16_t line, uint8_t val);
void ppu_rasterApplyLine(Ppu *ppu, int line);

/* Scanout latch bypass — set by the debug server around render_inject so an
 * injected OAM/CGRAM state is rendered as given. A frame-model host that
 * latches OAM/CGRAM at the frame's start (hardware scans out the state as of
 * line 0; a mid-frame DMA below the sprites belongs to the NEXT scanout)
 * must honor this flag in its draw_ppu_frame and render the LIVE state when
 * it is set. Default 0. */
extern int g_ppu_scanout_latch_bypass;
int  ppu_rasterDebugDump(char *out, int cap);

/* Raster journal — per-line replay of mid-frame INIDISP writes for frame-model
 * hosts. See the block comment in ppu.c. Host calls Begin after its
 * vblank-edge work and ApplyLine in its render loop; the register write path
 * calls Record with the beam line. */
void ppu_rasterBegin(Ppu *ppu);
void ppu_rasterRenderBegin(Ppu *ppu);
int  ppu_rasterTakeHdmaen(uint8_t *out);
void ppu_rasterRecord(uint16_t reg, uint16_t line, uint8_t val);
void ppu_rasterApplyLine(Ppu *ppu, int line);
int  ppu_rasterDebugDump(char *out, int cap);
/* Always-on PPU register write journal (every build, Release included).
 *
 * Every $2100-$2133 write except the bulk data ports ($2104 OAMDATA, $2118/
 * $2119 VMDATA, $2122 CGDATA) lands in a fixed ring, tagged with the frame
 * counter, the raster line it takes effect on, and who wrote it. It is the
 * recomp half of the per-line register diff against the oracle (snesref's
 * `<tag>.ppuw.tsv`): a layer that is wrong on some lines is a register whose
 * per-line value differs, and a write journal says which one and who wrote it.
 * Probes query it; nothing arms it.
 *
 * Line attribution: a write made before ppu_runLine(L) of the frame being
 * rasterized belongs to line L. Writes made after the raster walk ends (the
 * next frame's CPU half) carry line kPpuWlogPreRaster and the frame counter of
 * the frame just drawn -- ppu_wlog_collect() files them under the following
 * frame, which is the one they affect. */
enum {
  kPpuWlogCpu = 0, kPpuWlogDma = 1, kPpuWlogHdma = 2, kPpuWlogReplay = 3,
};
enum { kPpuWlogPreRaster = 225 };
typedef struct PpuWlogEntry {
  uint32_t frame;
  int16_t line;     /* 0..224, or -1 in collect() output = before the raster */
  uint16_t reg;     /* CPU address: $21xx, or $420C */
  uint8_t val;
  uint8_t src;      /* kPpuWlog* */
} PpuWlogEntry;
extern uint8_t g_ppu_wlog_src;
/* Writes that affected drawn frame `frame`, oldest first. Returns the count
 * copied (<= cap); *lost is set when the ring has already evicted part of that
 * frame. */
int ppu_wlog_collect(uint32_t frame, PpuWlogEntry *out, int cap, int *lost);
/* HDMAEN is not a PPU register but decides which lines HDMA touches, so the
 * $420C write path journals itself too. */
void ppu_wlog_note_reg(uint16_t reg, uint8_t val);
/* The frame counter and raster line a write made NOW is attributed to, by the
 * same rule as the journal. Lets other always-on rings (the DMA ring) file
 * their events on the line they affect. */
void ppu_wlog_position(uint32_t *frame, int16_t *line);

void ppu_saveload(Ppu *ppu, SaveLoadInfo *sli);
void PpuBeginDrawing(Ppu *ppu, uint8_t *pixels, size_t pitch, uint32_t render_flags);
void PpuResetWidescreenOamHistory(Ppu *ppu);

/* Rollback seam for PPU state that lives WITHIN a frame.
 *
 * ppu_saveload serializes the register window inidisp..cgwsel and the
 * cgram/oam/vram memories. Everything below sits outside it, correctly so for
 * a SAVESTATE: it is taken at a frame boundary, where ppu_handleVblank has
 * just reloaded the OAM write port from oamaddl/oamaddh and the widescreen
 * classifier can re-seed from the next frame.
 *
 * A ROLLBACK snapshot is taken MID-frame -- run-ahead and netplay resim both
 * snapshot after the CPU half of the frame and before the render half that
 * calls ppu_handleVblank -- so this state is live across exactly the boundary
 * being rewound. Leaving it out let a speculative frame's $2104 writes walk
 * oamAdr forward and kept that walk after the restore, so the real frame then
 * wrote sprite attributes to the wrong OAM slots. */
typedef struct PpuRollbackResidue {
  uint8_t  oamAdr;
  uint8_t  oamInHigh;
  uint8_t  oamSecondWrite;
  uint8_t  oamBuffer;
  /* Presentation-only, and deliberately NOT digested (a digest carries the
   * simulation; peers may render differently). Restored anyway so a rewind
   * reproduces the same picture, which is the whole point of run-ahead. */
  int16_t  wsOamMotionLastLine;
  int16_t  wsOamMotionX[128];
  uint32_t wsOamMotionSig[128];
  uint8_t  wsOamMotionSeen[16];
  uint8_t  wsOamMotionGrace[128];
} PpuRollbackResidue;

void ppu_rb_residue_get(const Ppu *ppu, PpuRollbackResidue *out);
void ppu_rb_residue_set(Ppu *ppu, const PpuRollbackResidue *in);

// Replace stale BG1 tilemap pixels in widened side margins before final
// composition. The callback is host-only and runs independently for main and
// subscreen buffers.
void PpuSetWidescreenLineEnhancer(Ppu *ppu,
                                  PpuWidescreenLineEnhancer *enhancer,
                                  void *context);

// Renderer-neutral host-overlay extraction (opt-in; see
// docs/HOST_OVERLAY_EXTRACTION.md). Default behavior is unchanged: with no
// surface bound and no capture rectangle set, every source is a deterministic
// no-op and the layer stays composited into renderBuffer exactly as before.

// Clear/bind persistent transparent ARGB host-overlay surfaces. Bindings survive
// ppu_reset; capture rectangles do not and are configured by game policy each
// frame. Surfaces are 256-kPpuBufWidth pixels wide and use the same full-frame
// coordinate system as renderBuffer.
// Passing NULL disables extraction for that source. Call ClearBindings once
// after PPU creation so a frontend can explicitly own all optional surfaces.
void PpuClearOverlayBindings(Ppu *ppu);
bool PpuBindOverlaySurface(Ppu *ppu, PpuOverlaySource source,
                           uint8_t *pixels, size_t pitch);

// Clear per-frame capture policy, then configure an arbitrary screen-space
// rectangle from BG1-BG4 or OBJ. With RemoveFromGame, pixels inside the rect
// are omitted from both main and subscreen while still exported with palette,
// transparency, windows, mosaic, and master brightness resolved. Coverage:
// Mode 1 BG1/BG2 (4bpp) and BG3 (2bpp), and Mode 7 BG1; other modes/layers
// leave the source inactive.
void PpuClearOverlayCaptures(Ppu *ppu);
bool PpuSetOverlayCapture(Ppu *ppu, PpuOverlaySource source,
                          int x, int y, int width, int height, uint8_t flags);

// Select a contiguous OAM slot range for an already configured OBJ capture.
// The game remains responsible for validating what those slots represent.
bool PpuSetOverlayOamRange(Ppu *ppu, uint8_t first, uint8_t count);

// Set the symmetric widescreen border, in pixels per side (clamped to
// kPpuExtraLeftRight). 0 restores authentic 256-wide rendering. The internal
// render width becomes 256 + 2*extra. Drives the dormant extraLeftCur/
// extraRightCur/extraLeftRight machinery used by the line renderer.
void PpuSetExtraSpace(Ppu *ppu, uint16_t extra);

// Render authentic 256-wide content centered within a `budget`-per-side wider
// framebuffer (no border columns drawn). For bounded screens; caller blacks
// out the side margins to pillarbox.
void PpuSetExtraSpaceCentered(Ppu *ppu, uint16_t budget);

// Asymmetric per-side widescreen margin (the snesrev/zelda3 model, see
// attribution in IMPROVEMENTS.md). The centering budget (extraLeftRight) must
// already be set via PpuSetExtraSpaceCentered/PpuSetExtraSpace; this fills the
// per-frame extraLeftCur/extraRightCur/extraBottomCur within that budget,
// clamped so the window/sprite/composite paths never read past the
// priority-buffer capacity (left/right) or the 16px overscan bottom. Negative
// inputs clamp to 0. (0,0,0) collapses to a centered pillarbox. Callers
// re-apply per frame (ppu_reset zeroes the fields). Used by games whose own
// scroll/room-bounds state drives the visible margin dynamically (Zelda),
// versus PpuSetExtraSpace's fixed symmetric border (SMW).
void PpuSetExtraSideSpace(Ppu *ppu, int left, int right, int bottom);

// Widescreen HUD split (opt-in, configured by the game frontend): for
// scanlines < height, BG3 (layer 2) is drawn as three chunks — source
// [0,left_end) anchored to the LEFT border edge, [left_end,right_start)
// kept centered (unmoved), [right_start,256) anchored to the RIGHT border
// edge. The vacated spans stay transparent. height 0 = off (authentic).
// Uses the fixed centering budget, independent of dynamic room-bound playfield
// margins, and takes effect while BG3 is not windowed; mosaic lines fall back
// to centered. Like the extra-space
// setters, callers re-apply per frame (ppu_reset zeroes the fields).
void PpuSetWidescreenHudSplit(Ppu *ppu, uint8_t height, uint8_t left_end,
                              uint8_t right_start);

// Opt the split HUD, configured layer-anchor bands, and selected HUD OAM into
// full-budget composition. Pixels outside the live world margin remain black
// unless one of those HUD sources supplied an actual pixel. A BG3 hardware
// window is ignored only inside the configured split-HUD scanline band.
void PpuSetWidescreenHudAlwaysVisible(Ppu *ppu, bool enabled);

// Configure the vertical band and native left/right anchor thresholds used by
// the OAM HUD shifter without enabling the BG3 HUD split. Height may cover the
// full 224-line picture. Existing callers of PpuSetWidescreenHudSplit keep the
// coupled behavior until this overrides it.
void PpuSetWsHudOamBand(Ppu *ppu, uint8_t height, uint8_t left_end,
                        uint8_t right_start);

// Shift edge-hugging HUD sprites in OAM slots [0, nslots) outward with the
// live widescreen margins. Presentation-only; 0 disables the anchor.
/* Deterministic widescreen geometry for probes/CI: SNESRECOMP_WS_EXTRA=<px>
 * pins the per-side margin regardless of window size (0 forces 4:3; unset
 * returns -1 = follow the window). Games consult this when computing their
 * widescreen frame width so measured margins never silently depend on
 * window-manager geometry. Clamped to kPpuExtraLeftRight. */
int PpuWsExtraOverride(void);

void PpuSetWsHudOamShift(Ppu *ppu, uint8_t nslots);

// Shift edge-hugging HUD sprites in OAM slots [first_slot, first_slot+nslots)
// outward with the live widescreen margins. When HUD-always-visible is set,
// use the full centering budget so HUDs can occupy room-bound pillarboxes.
// Presentation-only.
void PpuSetWsHudOamShiftRange(Ppu *ppu, uint8_t first_slot, uint8_t nslots);
/* Second anchored slot range (same band/edge thresholds as the first).
 * For sprite HUDs whose elements live outside the game's fixed HUD OAM
 * reserve. nslots 0 disables. Publish every frame like the first range. */
void PpuSetWsHudOamShiftRange2(Ppu *ppu, uint8_t first_slot, uint8_t nslots);

// Publish this frame's OAM left-margin hints (see wsOamLeftHintStrict).
// `hints` is a 128-bit set (16 bytes, bit N of byte N/8 = OAM slot N), or
// NULL to disable strict decode and restore the legacy left-margin behavior.
// Pass a zeroed array for strict mode with no left-margin slots marked.
void PpuWsSetOamLeftHints(Ppu *ppu, const uint8_t *hints);

// Publish this frame's OAM right-margin hints (see wsOamRightHintStrict).
// `hints` is a 128-bit set (16 bytes, bit N of byte N/8 = OAM slot N), or
// NULL to disable strict decode and restore the legacy always-positive band.
// Games that stage OAM CPU-side should call this each NMI, after the staging
// buffer is final and before the frame is presented.
void PpuWsSetOamRightHints(Ppu *ppu, const uint8_t *hints);

// Let BG3 (layer 2) render into the widescreen side margins on scanlines
// >= from_y, instead of being clamped to the authentic 256-wide region. Pass
// the HUD band height so the status bar above it stays clamped (or split) while
// level content on BG3 below it (e.g. SMW water) fills 16:9. from_y 0 = off.
// Like the other widescreen setters, callers re-apply per frame.
void PpuSetWidescreenBg3Widen(Ppu *ppu, uint8_t from_y);

// Restrict side-margin background rendering to the selected BG layer bits.
// The authentic center and OBJ rendering are unaffected. A zero mask restores
// the default layer policy.
void PpuSetWidescreenLayerMask(Ppu *ppu, uint8_t bg_layer_mask);

// Capture one native 256-pixel Mode 2 background layer before it is combined
// with the other layers. This lets a game frontend synthesize presentation-
// only margins without evaluating offset-per-tile data outside the real SNES
// viewport. Pass layer 0 or 1; any other value disables capture.
void PpuSetMode2LayerCapture(Ppu *ppu, int layer);
const uint8_t *PpuGetMode2LayerCapture(const Ppu *ppu);
const uint8_t *PpuGetMode2Bg1Palette(const Ppu *ppu);

// Per-layer widescreen clamp: bit L keeps BG(L+1) in the authentic 256
// columns while other layers extend into the margins. Re-apply per frame.
void PpuSetWidescreenLayerClamp(Ppu *ppu, uint8_t mask);

// Extend selected game-authored PPU windows by the current widescreen margins
// while evaluating the selected layers. Emulated window registers are not
// changed. Re-apply per frame; zero masks disable the policy.
void PpuSetWidescreenWindowExpansion(Ppu *ppu, uint8_t layer_mask,
                                     uint8_t window_mask);

// Fill Mode-1 background margins by reflecting or cyclically repeating the
// authentic rendered scanline. Rendering remains layer-, priority-, window-,
// and color-math-correct. Repeat wins if both bits are set. Re-apply per frame.
void PpuSetWidescreenLayerMirror(Ppu *ppu, uint8_t mask);
void PpuSetWidescreenLayerRepeat(Ppu *ppu, uint8_t mask);

// Apply clamp, cyclic-repeat, or stretch only on scanlines [y0,y1).
// y1<=y0 disables. Repeat/stretch bands apply to Mode-1 4bpp and 2bpp
// background paths.
void PpuSetWidescreenLayerClampBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                    uint8_t y1);
void PpuSetWidescreenLayerRepeatBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                     uint8_t y1);
void PpuSetWidescreenLayerStretchBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                      uint8_t y1);

// On scanlines [y0,y1), anchor [0,left_end) and [right_start,256) of
// BG(layer+1) to the expanded viewport edges while keeping the middle
// centered. Intended for HUDs embedded in a 4bpp background layer.
void PpuSetWidescreenLayerAnchorBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                     uint8_t y1, uint8_t left_end,
                                     uint8_t right_start);
// Configure one of the two independent bands available to split-screen
// layouts. Slot 0 is the same band set by the convenience function above.
void PpuSetWidescreenLayerAnchorBandSlot(
    Ppu *ppu, uint8_t slot, uint8_t layer, uint8_t y0, uint8_t y1,
    uint8_t left_end, uint8_t right_start);

// Skip left_px/right_px offscreen tilemap pixels before sampling the margins
// of BG(layer+1). This hides UI staging columns that hardware never displays.
// Applies to non-mosaic 4bpp/2bpp paths. Re-apply per frame.
void PpuSetWidescreenLayerMarginGap(Ppu *ppu, uint8_t layer, uint8_t left_px,
                                    uint8_t right_px);

// Treat [left_px, 256-right_px) as BG(layer+1)'s authentic visible viewport
// while a widescreen line enhancer is active. Pixels in the native edge
// insets remain transparent so the enhancer or lower layers can replace
// framebuffer padding that was hidden on the original display.
void PpuSetWidescreenLayerViewportInset(Ppu *ppu, uint8_t layer,
                                        uint8_t left_px, uint8_t right_px);

// Reflect BG(layer+1) about the edges of its AUTHORED WORLD rather than about
// the viewport edge, on scanlines [y0,y1).
//
// PpuSetWidescreenLayerMirror/RepeatBand fold the rendered native scanline
// back at screen x=0/255. That is right for a layer whose content ends where
// the original screen ends, and wrong for a bounded arena: mid-scroll the
// margins of such a layer hold genuine authored tilemap art, and folding at
// the viewport edge throws it away.
//
// This policy leaves those columns alone and only intervenes where the
// tilemap runs out of authored content. Per pixel, with `x` the tilemap X
// this line renders at (the line's own hScroll + screen x, in map pixels and
// before the map's own wrap):
//   x <  world_left_px   ->  sample 2*world_left_px  - 1 - x
//   x >= world_right_px  ->  sample 2*world_right_px - 1 - x
//   otherwise            ->  render naturally
// A pixel whose reflection also lands outside [left,right) is left
// transparent, so lower layers and the backdrop still fill it.
//
// The rule is applied uniformly to margin and authentic columns; in practice a
// game clamps the camera so only margins can leave the world. Phase comes from
// the scroll the PPU rendered the line with, never from a WRAM camera mirror
// (WIDESCREEN_PATTERNS P1). Presentation-only: no emulated register is
// touched, the fields live outside every savestate span, and the policy is
// inert while the widescreen margin is 0.
//
// Applies to the Mode-1 policy-dispatched 4bpp/2bpp paths, including their
// big-tile and mosaic variants. Requires kPpuRenderFlags_NewRenderer.
// Re-apply per frame like the other widescreen setters; slot 0 is the band set
// by the convenience function.
void PpuSetWidescreenLayerWorldMirrorBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                          uint8_t y1, uint16_t world_left_px,
                                          uint16_t world_right_px);
void PpuSetWidescreenLayerWorldMirrorBandSlot(
    Ppu *ppu, uint8_t slot, uint8_t layer, uint8_t y0, uint8_t y1,
    uint16_t world_left_px, uint16_t world_right_px);

// ELASTIC ANCHOR BANDS -- anchor a raster status bar's chrome to the widened
// viewport edges and bridge the gap that opens by stretching only the
// material that can survive being stretched.
//
// PpuSetWidescreenLayerAnchorBand already moves a status bar's left and right
// chunks out to the expanded edges. That is only half an answer whenever the
// bar is ONE continuous graphic with no transparent column to hide the seam:
// anchoring then opens an `extra`-px hole on each side of the centre group,
// through which lower layers and the backdrop show. PpuSetWidescreenLayer-
// StretchBand closes such a hole, but it scales the WHOLE line, which
// distorts every glyph on it.
//
// An elastic band splits the difference per column. On scanlines [y0,y1) of
// BG(layer+1), destination column x in [-extraLeft, 256+extraRight) is
// produced from the native 256-px rendered line by an explicit piecewise map:
//   for the segment whose [dstX0,dstX1) contains x, with o = x - dstX0,
//   sw = srcX1 - srcX0 and dw = dstX1 - dstX0:
//       sx = srcX0 + ((2*o + 1) * sw) / (2 * dw)
// i.e. nearest neighbour about each destination pixel's centre, in integer
// arithmetic (no rounding mode, no float, identical on every host). Equal
// source and destination widths make that an exact 1:1 copy, so a RIGID
// segment is byte-exact wherever it is placed -- that is what keeps names,
// digits, labels and markers pixel-perfect while they move outward. A wider
// destination resamples, which is exactly invisible when the source run's
// columns are identical to each other, and which preserves a gauge's fill
// FRACTION when the run is a bar: k filled of n source columns become
// round(k*dw/n) of dw destination columns within a pixel, so full stays full,
// empty stays empty and 37% stays 37%. Centre sampling rather than
// floor(o*sw/dw) is what makes the map symmetric under reflection, so a
// mirror-image pair of gauges stretches to the same length.
//
// Segments must be ascending and non-overlapping in destination space; a band
// that is not is rejected outright rather than half-applied. Destination
// columns no segment covers stay transparent, so a band can also express a
// pure clamp (one segment {0,256,0,256}) for a transitional line.
//
// Implemented at the merge step of the Mode-1 policy dispatchers, so it covers
// the 4bpp, 2bpp, big-tile and mosaic draw paths in one place. Only source
// columns [0,256) are sampled -- the native picture the game authored, never
// the margin columns the widened render happens to reach. Presentation-only:
// no emulated register is touched, the fields live outside every savestate
// span, and the whole policy is inert while the margin is 0. Requires
// kPpuRenderFlags_NewRenderer. Re-apply per frame like the other widescreen
// setters (PpuSetExtraSpace* clears them); slot 0 is the band set by the
// convenience form.
//
// A layer must not carry an elastic band and an anchor band on the same line:
// the anchor band stands down where an elastic band is live, since the
// elastic band's rigid segments already express the anchoring.
void PpuSetWidescreenLayerElasticBand(Ppu *ppu, uint8_t layer, uint8_t y0,
                                      uint8_t y1,
                                      const PpuWsElasticSeg *segs,
                                      uint8_t nseg);
void PpuSetWidescreenLayerElasticBandSlot(Ppu *ppu, uint8_t slot,
                                          uint8_t layer, uint8_t y0,
                                          uint8_t y1,
                                          const PpuWsElasticSeg *segs,
                                          uint8_t nseg);

// Build and install the symmetric five-segment layout a centred status bar
// wants, from the two stretchable source runs alone:
//
//   [0, left_elastic_x0)             rigid, shifted out to the left edge
//   [left_elastic_x0, ..._x1)        elastic, absorbs the left margin
//   [left_elastic_x1, right_..._x0)  rigid, unshifted (holds the centre group)
//   [right_elastic_x0, ..._x1)       elastic, absorbs the right margin
//   [right_elastic_x1, 256)          rigid, shifted out to the right edge
//
// The elastic runs are what a game measures: pick spans whose columns are
// identical to one another (plain chrome) or which are a gauge's interior.
// Empty runs (x1 <= x0 for both sides) install the identity/clamp band.
// Returns false and leaves the slot cleared if the spans are not ordered
// 0 <= lx0 < lx1 <= rx0 < rx1 <= 256. Reads the CURRENT margin
// (extraLeftCur/extraRightCur), so it must be called after PpuSetExtraSpace*.
bool PpuSetWidescreenLayerElasticSplitBandSlot(
    Ppu *ppu, uint8_t slot, uint8_t layer, uint8_t y0, uint8_t y1,
    uint16_t left_elastic_x0, uint16_t left_elastic_x1,
    uint16_t right_elastic_x0, uint16_t right_elastic_x1);

#endif
