"""snesrecomp.recompiler.v2.cfg_loader

Parse a v1-format bank cfg file into a v2 `BankCfg` dataclass that
`emit_bank` can consume.

v2 IGNORES the v1 ABI-fiction directives:
- `sig:` — every v2 function is `void f(CpuState *cpu)`.
- `ret_y` / `carry_ret` — return value is never materialised; flags
  and registers live in the CpuState struct.
- `y_after:` / `x_after:` — call-site index increments are dead with
  the new ABI (caller and callee both see cpu->X / cpu->Y).
- `restores_x:` / DP-aliased struct params (e.g. `CollInfo_*ci`) —
  same, dead.

v2 KEEPS:
- `bank = NN`
- `includes = ...` (used to extend the default emit_bank header).
- `func <name> <hex_pc> [end:<hex_end>] [entry_mx:M,X]` — the entry
  list. `entry_mx` overrides the default reset-state M/X width for
  hand-written entries whose ABI is only valid after caller-side setup.
- `entry_mx_at <hex_pc> <M> <X>` — the same entry-width override, kept
  outside auto-ingested func blocks so those blocks stay regeneratable.
- `end_at <hex_pc> <hex_end>` — override a generated function's
  exclusive end boundary outside auto-ingested func blocks.
- `name <hex_addr> <name>` — friendly-naming for cross-bank labels.
  v2 emits these as `void NAME(CpuState *cpu);` forward declarations
  in funcs.h (Phase 6e/f). For now we just retain them.
- `symbol <hex_addr> <name>` — non-promoting friendly label. Unlike
  `name`, this never creates an emit entry or funcs.h declaration; it
  only names an address if analysis reaches it through real code flow.
- `force_lle <pc24>` — keep an exact architectural function boundary on
  the interpreter tier even when profile promotion or static reachability
  would otherwise materialise it as native code.
- `exclude_range <start> <end>` — data region carved out of decode.
- `data_region <bank> <start> <end>` — same idea, cross-bank.

Public API:
    load_bank_cfg(path: str) -> BankCfg
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import sys

_THIS_DIR = Path(__file__).resolve().parent
_RECOMPILER_DIR = _THIS_DIR.parent
for p in (str(_THIS_DIR), str(_RECOMPILER_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from v2.emit_bank import BankEntry  # noqa: E402


@dataclass
class NameDecl:
    """A `name <addr> <friendly>` line. Cross-bank label / friendly
    name used by funcs.h forward decls; not an entry to emit here."""
    addr_24: int  # bank << 16 | local pc
    name: str


@dataclass
class RamRoutine:
    """A `ram_routine <pc24> <MmXn> <hexbytes>` line: a deterministic
    runtime-generated routine resident in WRAM ($7E/$7F) whose captured bytes
    are literally recompiled (LLE) as an AOT body. The blob is appended to the
    ROM image and reached via a synthetic reloc region so the standard decoder
    path decodes it unchanged; runtime dispatch is guarded by a live byte-match
    (g_ram_routine_guards). Source of truth: tier2_coverage.json ram_routines[]
    (deterministic, terminated entries only)."""
    pc24: int          # absolute 24-bit WRAM entry (bank $7E/$7F)
    entry_m: int       # entry M flag to emit + gate on
    entry_x: int       # entry X flag to emit + gate on
    data: bytes        # captured snapshot (length = routine length)


@dataclass
class BankCfg:
    bank: int
    includes: List[str] = field(default_factory=list)
    entries: List[BankEntry] = field(default_factory=list)
    names: List[NameDecl] = field(default_factory=list)
    symbols: List[NameDecl] = field(default_factory=list)
    # Exact 24-bit function boundaries which must stay interpreter-only.
    # Unlike exclude_range, these are executable ROM routines; they merely
    # rely on behavior (for example return-stack rewriting) that the native
    # callable ABI cannot represent.
    force_lle: set = field(default_factory=set)
    exclude_ranges: List[Tuple[int, int]] = field(default_factory=list)
    authority_insns: dict[int, bytes] = field(default_factory=dict)
    authority_data: List[Tuple[int, int]] = field(default_factory=list)
    data_regions: List[Tuple[int, int, int]] = field(default_factory=list)  # (bank, start, end)
    # exit_mx_at directives: list of (bank, addr16, m, x) — annotates the
    # exit (m, x) state of a function at that PC. Decoder uses this to
    # resume callers after JSR/JSL with the correct (m, x) instead of
    # assuming the callee preserves the caller's state. THIS LIST IS FOR
    # HAND-WRITTEN cfg DIRECTIVES ONLY — the auto-router populates
    # `exit_mx_at_per_variant` (below) which is per-entry-variant and
    # always correct; the 4-tuple broadcast here is preserved for
    # backward compat with hand-written hints that pre-date the
    # per-variant work.
    exit_mx_at: List[Tuple[int, int, int, int]] = field(default_factory=list)
    # Per-entry-variant exit (m, x) tuples populated by the auto-router.
    # Each entry is (bank, addr16, entry_m, entry_x, exit_m, exit_x).
    # Consumed by v2_regen.py's callee_exit_mx builder; per-variant
    # entries OVERRIDE the legacy 4-tuple broadcast for their specific
    # (target, entry_m, entry_x) keys. This is the proper data model
    # for functions whose exit depends on entry — the broadcast 4-tuple
    # is wrong for those (Bug C class, see
    # docs/ABSTRACT_INTERPRETATION_GAPS.md).
    exit_mx_at_per_variant: List[Tuple[int, int, int, int, int, int]] = field(default_factory=list)

    # `exit_mx_set` directives: (bank, addr16, entry_m, entry_x, frozenset of
    # (exit_m, exit_x)). Declares that a callee entered at one variant returns
    # in MORE THAN ONE width depending on the path it takes -- which neither
    # `exit_mx_at` (one width, broadcast to every variant) nor
    # `exit_mx_at_per_variant` (one width per variant) can express.
    #
    # This is not hypothetical. SimCity's 02:8000 is entered only at m0x0 and
    # returns in m0x1 or m1x1: 02:803C is `JMP $824B` into a shared tail that
    # ends at a different RTL from its own. The decoder already models exactly
    # this -- `callee_exit_mx_modes` forks the post-call fall-through into one
    # DecodeKey per proven exit mode and the emitter picks the live one with a
    # runtime width switch -- but until now only the whole-program fixed point
    # could populate it, so a callee the solver could not prove had no way to
    # be told the answer.
    exit_mx_set: List[Tuple[int, int, int, int, frozenset]] = field(default_factory=list)
    # `auto_vectors` directive — when true and this cfg is bank 00,
    # v2_regen reads the SNES interrupt-vector table from the detected
    # LoROM/HiROM internal-header location and auto-seeds
    # `func I_RESET / I_NMI / I_IRQ` entries at the dereferenced PCs.
    # Lets a fresh game project ship a minimal bank00.cfg with just
    # the one directive instead of hand-decoding the vector table.
    auto_vectors: bool = False
    # `tier_down_stubs` directive — when present in ANY cfg, v2_regen emits
    # cross-ROM-bank unresolved-function stubs (unresolved_stubs_v2.c) as
    # interpreter tier-downs (interp_tier_dispatch_bank_miss) that RUN the real
    # ROM bytes, instead of the no-op cpu_trace_unresolved_stub_trap. Game-wide
    # opt-in for the Phase-4 bank-miss tier (docs/MULTI_TIER.md); the
    # --tier-down-stubs CLI flag forces it on regardless. Bring-up aid —
    # shipped titles omit it (default off).
    tier_down_stubs: bool = False
    # `indirect_dispatch` directives — authorise the decoder to recover
    # the static target list of an indirect JMP/JML/JSR. Each entry is
    # a dict with keys:
    #   site_pc16: int       — local 16-bit PC of the dispatch insn
    #   count: int           — N (number of dispatch targets)
    #   idx_reg: 'X' or 'Y'  — which CPU index register selects the case
    #   table_bases: tuple   — table addr(s):
    #       ()           : table base taken from insn.operand (JSR/JMP/JML (abs,X))
    #       (lo,)        : single static table at given addr
    #       (lo, hi)     : two parallel byte-tables forming a 16-bit pointer
    #       (lo, hi, bk) : three parallel byte-tables forming a 24-bit pointer
    #                      (assembled into DP then JML [DP], e.g. Module_MainRouting)
    # Decoder reads ROM via the resolved table layout, registers each
    # entry as a decode successor (for auto-promote / reachability), and
    # stamps `insn.dispatch_entries` so codegen emits a real switch.
    indirect_dispatch: List[dict] = field(default_factory=list)
    # `terminal_jsr <site_pc16>` — the direct JSR at this call site pushes a
    # real return address which the callee consumes as inline-table data, then
    # tail-transfers instead of returning to the byte after JSR.  This is a
    # call-site ABI fact recovered from assembly source, not an inferred
    # no-return heuristic.  The decoder severs lexical fall-through and the
    # emitter hands the caller's outer return context to the callee.
    terminal_jsr: set = field(default_factory=set)
    # `noreturn_jsr <site_pc16>` — the direct JSR enters a path which is
    # source-authoritatively known never to return (for example, an original
    # game bug that transfers into non-code bytes and crashes).  Unlike
    # terminal_jsr, the callee does not consume the call frame as inline data;
    # emission preserves the real frame and hands the exceptional path to LLE.
    noreturn_jsr: set = field(default_factory=set)
    # `hle_spc_upload <pc>` directives — replace the recompiled body of
    # the function starting at <pc> with a single call to the runtime
    # HLE helper RtlUploadSpcImageFromDp. The standard SNES SPC upload
    # protocol is a length/target/data block stream pointed at by a
    # 24-bit ROM pointer in direct page ($DP+0..2). The runtime reads
    # the stream directly into apu->ram and jumps apu->spc->pc to the
    # terminator's target, bypassing the per-byte IPL handshake (which
    # only really works under hardware-realistic SPC pacing and pins
    # the recompiler against the watchdog for many wall seconds).
    # Per-game: declare the SPC upload entry PC here. Works for SMW
    # (HandleSPCUploads_Inner / SPC700UploadLoop at $00:8079) and
    # ALttP (LoadSongBank at $00:8888) — both use the same protocol.
    # Map entry PC to protocol ownership mode. `live` preserves the running
    # driver's AA/BB-ready and CC-terminator handshake; `legacy` retains the
    # direct state replacement required by older per-game declarations.
    hle_spc_upload: dict = field(default_factory=dict)
    # `hle_func <pc16> <c_function_name>` — replace the recompiled body
    # of the function at <pc> with a single forwarding call to the named
    # C function. Used for hand-written HLE bodies that need to run
    # alongside cfg-declared (m,x) variants — the recompiler skips
    # decoding the bytes for these PCs and emits a forwarding stub per
    # requested variant: `RecompReturn NAME_MxXy(CpuState *cpu) {
    #   return <c_function_name>(cpu); }`. The C helper must be
    # provided by the per-game runner (typically in gen_stubs.c).
    # HLE ABI: the helper preserves its entry M/X unless the associated
    # `func ... exit_mx:M,X` boundary explicitly declares another exit.
    # Map: pc16 -> c_function_name. See emit_function.py for stub shape.
    hle_func: dict = field(default_factory=dict)
    # `hle_dispatch <site_pc16> <c_function_name>` — at the named indirect
    # JMP/JML/JSR site, replace the unresolved-dispatch trap with a
    # tail-call to the named C helper. Used when the asm dispatcher at
    # <site_pc16> is replaced by a host-side scheduler / interpreter
    # that decides the next PC itself (e.g. the MMX cooperative-task
    # scheduler's `JMP ($0032,X)` at $00:80E6 — the C-host MmxSchedulerTick
    # selects the task body to run). The site PC matches insn.addr,
    # so the helper fires from every caller-body that inlined the
    # dispatch as part of its decoded CFG. Map: pc16 -> c_function_name.
    hle_dispatch: dict = field(default_factory=dict)
    # `force_variant_at <site_pc24> <m> <x>` — at the named direct
    # JSR/JSL site, bypass the runtime 4-way (m, x) dispatch and emit a
    # hardcoded call to the (m, x) variant of the target. Used for
    # diagnostic VALIDATION of suspected m-flag tracking bugs: if forcing
    # the expected variant at a specific site makes a freeze go away,
    # the runtime cpu->m_flag at that site is wrong and the root cause
    # is upstream. Once the upstream bug is fixed the hint should be
    # REMOVED — this directive is intentionally narrow (one site, one
    # (m, x)) and is NOT a long-term workaround. The 24-bit PC matches
    # the JSR/JSL instruction's own address (the `insn.addr` of the
    # call), NOT the target. Map: site_pc24 -> (m, x).
    force_variant_at: dict = field(default_factory=dict)
    # `ram_routine <pc24> <MmXn> <hexbytes>` directives — see RamRoutine.
    ram_routines: List[RamRoutine] = field(default_factory=list)


# Token regex helpers
_HEX_RE = re.compile(r'^[0-9a-fA-F]+$')


def _parse_hex(token: str) -> int:
    if token.lower().startswith('0x'):
        return int(token, 16)
    return int(token, 16)


def _parse_mx(token: str):
    """Parse an `MmXn` variant token (e.g. 'M1X1') into (m, x). Returns None
    on a malformed token. Case-insensitive."""
    t = token.lower()
    if (len(t) == 4 and t[0] == 'm' and t[2] == 'x'
            and t[1] in '01' and t[3] in '01'):
        return (int(t[1]), int(t[3]))
    return None


def _strip_comment(line: str) -> str:
    """Strip trailing '# ...' comment from a cfg line."""
    idx = line.find('#')
    if idx >= 0:
        line = line[:idx]
    return line.rstrip()


def load_bank_cfg(path: str) -> BankCfg:
    """Parse a v1-format bank cfg file. Returns a BankCfg dataclass.

    Raises ValueError on a malformed `bank =` line. Other unrecognized
    directives are silently ignored (forward-compat with v1 cfgs that
    have v1-only directives the v2 pipeline doesn't need).
    """
    cfg = BankCfg(bank=-1)
    entry_mx_at: dict[int, Tuple[int, int]] = {}
    end_at: dict[int, int] = {}

    with open(path, 'r', encoding='utf-8', errors='replace') as fp:
        for raw in fp:
            line = raw.rstrip('\n')

            # Strip comments + leading whitespace for everything else.
            stripped = _strip_comment(line).strip()
            if not stripped:
                continue

            tokens = stripped.split()
            head = tokens[0]

            # bank = NN
            if head == 'bank' and len(tokens) >= 3 and tokens[1] == '=':
                cfg.bank = _parse_hex(tokens[2])
                continue

            # includes = a.h b.h c.h
            if head == 'includes' and len(tokens) >= 3 and tokens[1] == '=':
                cfg.includes = list(tokens[2:])
                continue

            # comment = ... (v2 ignores)
            if head == 'comment' and '=' in stripped:
                continue

            # auto_vectors — request that v2_regen.py read the SNES
            # interrupt-vector table from the detected cartridge mapping
            # and auto-seed
            # `func I_RESET / I_NMI / I_IRQ` entries. Bank 00 only
            # (vectors live in bank 0); v2_regen warns and skips for
            # other banks.
            if head == 'auto_vectors':
                cfg.auto_vectors = True
                continue

            # tier_down_stubs — opt into the Phase-4 bank-miss interpreter
            # tier (see BankCfg.tier_down_stubs). Game-wide; place once in any
            # bank cfg. The --tier-down-stubs CLI flag forces it on regardless.
            if head == 'tier_down_stubs':
                cfg.tier_down_stubs = True
                continue

            # entry_mx_at <pc16> <m> <x> — override a cfg entry's
            # canonical decode width without modifying auto-ingested
            # `func` lines.
            if head == 'authority_data':
                if len(tokens) != 3:
                    raise ValueError(f"{path}: authority_data needs <start> <end_exclusive>")
                start, end = map(_parse_hex, tokens[1:])
                if not 0 <= start < end <= 0x10000:
                    raise ValueError(f"{path}: invalid authority_data interval")
                cfg.authority_data.append((start, end))
                continue
            if head == 'authority_insn':
                if len(tokens) != 3:
                    raise ValueError(f"{path}: authority_insn needs <pc16> <hexbytes>")
                start = _parse_hex(tokens[1])
                raw = bytes.fromhex(tokens[2])
                if not 0 <= start <= 0xFFFF or not 1 <= len(raw) <= 4 or start + len(raw) > 0x10000:
                    raise ValueError(f"{path}: invalid instruction authority")
                if start in cfg.authority_insns and cfg.authority_insns[start] != raw:
                    raise ValueError(f"{path}: conflicting instruction authority")
                cfg.authority_insns[start] = raw
                continue

            if head == 'entry_mx_at':
                if len(tokens) != 4:
                    raise ValueError(
                        f"{path}: entry_mx_at needs <pc16> <m> <x>, "
                        f"got: {stripped!r}")
                try:
                    pc16 = _parse_hex(tokens[1]) & 0xFFFF
                    m_val = int(tokens[2]) & 1
                    x_val = int(tokens[3]) & 1
                except ValueError as e:
                    raise ValueError(
                        f"{path}: entry_mx_at bad argument in "
                        f"{stripped!r}: {e}")
                entry_mx_at[pc16] = (m_val, x_val)
                continue

            # end_at <pc16> <end> — override a cfg entry's exclusive
            # decode boundary without modifying auto-ingested `func`
            # lines.
            if head == 'end_at':
                if len(tokens) != 3:
                    raise ValueError(
                        f"{path}: end_at needs <pc16> <end>, "
                        f"got: {stripped!r}")
                try:
                    pc16 = _parse_hex(tokens[1]) & 0xFFFF
                    end_val = _parse_hex(tokens[2])
                except ValueError as e:
                    raise ValueError(
                        f"{path}: end_at bad argument in "
                        f"{stripped!r}: {e}")
                end_at[pc16] = end_val
                continue

            # hle_spc_upload <hex_pc> — mark the function at <pc> as
            # the project's SPC upload entry. emit_function replaces
            # its decoded body with a single RtlUploadSpcImageFromDp
            # call; the runtime walks the standard length/target/data
            # block stream pointed to by DP+0..2 and writes directly
            # into apu->ram. See BankCfg.hle_spc_upload comment.
            if head == 'hle_spc_upload':
                if len(tokens) not in (2, 3):
                    raise ValueError(
                        f"{path}: hle_spc_upload needs <pc> and optional "
                        f"legacy|live mode, got: {stripped!r}")
                try:
                    pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: hle_spc_upload bad pc {tokens[1]!r}: {e}")
                mode = tokens[2].lower() if len(tokens) == 3 else 'legacy'
                if mode not in ('legacy', 'live'):
                    raise ValueError(
                        f"{path}: hle_spc_upload bad mode {mode!r}; "
                        "expected legacy or live")
                cfg.hle_spc_upload[pc16] = mode
                continue

            # hle_func <pc16> <c_function_name> — replace the decoded
            # body of the function at <pc> with a forwarding stub:
            #   RecompReturn NAME_MxXy(CpuState *cpu) {
            #     return <c_function_name>(cpu);
            #   }
            # The C helper must be provided externally (typically
            # gen_stubs.c). One stub per (m,x) variant the recompiler
            # discovers as called from elsewhere. See BankCfg.hle_func
            # comment.
            if head == 'hle_func':
                if len(tokens) != 3:
                    raise ValueError(
                        f"{path}: hle_func needs <pc> <c_function_name>, "
                        f"got: {stripped!r}")
                try:
                    pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: hle_func bad pc {tokens[1]!r}: {e}")
                c_name = tokens[2]
                if not c_name.replace('_', '').isalnum() or c_name[0].isdigit():
                    raise ValueError(
                        f"{path}: hle_func c_function_name must be a valid "
                        f"C identifier, got: {c_name!r}")
                cfg.hle_func[pc16] = c_name
                continue

            # force_lle <pc24> — retain this executable function boundary on
            # the interpreter tier. The address is deliberately absolute so
            # a directive can live in a minimal bank00.cfg while naming any
            # ROM bank discovered from a profile manifest.
            if head == 'force_lle':
                if len(tokens) != 2:
                    raise ValueError(
                        f"{path}: force_lle needs <pc24>, got: {stripped!r}")
                try:
                    pc24 = _parse_hex(tokens[1]) & 0xFFFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: force_lle bad pc24 {tokens[1]!r}: {e}")
                if pc24 in cfg.force_lle:
                    raise ValueError(
                        f"{path}: force_lle duplicate boundary ${pc24:06X}")
                cfg.force_lle.add(pc24)
                continue

            # force_variant_at <site_pc24> <m> <x> — pin the variant
            # called at the named direct JSR/JSL site. See BankCfg
            # field doc for use as a diagnostic for suspected m-flag
            # tracking bugs. Format: site_pc24 hex (with or without 0x),
            # m and x each 0 or 1.
            if head == 'force_variant_at':
                if len(tokens) != 4:
                    raise ValueError(
                        f"{path}: force_variant_at needs <site_pc24> <m> <x>, "
                        f"got: {stripped!r}")
                try:
                    site_pc24 = _parse_hex(tokens[1]) & 0xFFFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: force_variant_at bad site_pc24 {tokens[1]!r}: {e}")
                try:
                    m_val = int(tokens[2])
                    x_val = int(tokens[3])
                except ValueError as e:
                    raise ValueError(
                        f"{path}: force_variant_at m and x must be 0 or 1: {e}")
                if m_val not in (0, 1) or x_val not in (0, 1):
                    raise ValueError(
                        f"{path}: force_variant_at m and x must be 0 or 1, "
                        f"got m={m_val} x={x_val}")
                if site_pc24 in cfg.force_variant_at:
                    raise ValueError(
                        f"{path}: force_variant_at duplicate site ${site_pc24:06X}")
                cfg.force_variant_at[site_pc24] = (m_val, x_val)
                continue

            # terminal_jsr <site_pc16> — source-authoritative call-site ABI
            # for inline-return-address dispatch helpers.  The opcode itself
            # is validated by the decoder when this site is reached.
            if head == 'terminal_jsr':
                if len(tokens) != 2:
                    raise ValueError(
                        f"{path}: terminal_jsr needs exactly one <site_pc16>, "
                        f"got: {stripped!r}")
                try:
                    site_pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: terminal_jsr bad site {tokens[1]!r}: {e}")
                if site_pc16 in cfg.terminal_jsr:
                    raise ValueError(
                        f"{path}: terminal_jsr duplicate site ${site_pc16:04X}")
                if site_pc16 in cfg.noreturn_jsr:
                    raise ValueError(
                        f"{path}: JSR site ${site_pc16:04X} cannot be both "
                        "terminal_jsr and noreturn_jsr")
                cfg.terminal_jsr.add(site_pc16)
                continue

            # noreturn_jsr <site_pc16> — source-authoritative no-return call.
            # The decoder validates that the named opcode is a direct JSR.
            if head == 'noreturn_jsr':
                if len(tokens) != 2:
                    raise ValueError(
                        f"{path}: noreturn_jsr needs exactly one <site_pc16>, "
                        f"got: {stripped!r}")
                try:
                    site_pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: noreturn_jsr bad site {tokens[1]!r}: {e}")
                if site_pc16 in cfg.noreturn_jsr:
                    raise ValueError(
                        f"{path}: noreturn_jsr duplicate site ${site_pc16:04X}")
                if site_pc16 in cfg.terminal_jsr:
                    raise ValueError(
                        f"{path}: JSR site ${site_pc16:04X} cannot be both "
                        "terminal_jsr and noreturn_jsr")
                cfg.noreturn_jsr.add(site_pc16)
                continue

            # hle_dispatch <site_pc16> <c_function_name> — replace the
            # unresolved-dispatch trap at the indirect JMP/JML/JSR site
            # at <site_pc16> with a tail-call to the named C helper.
            # The helper decides the next PC (host scheduler / interpreter).
            # See BankCfg.hle_dispatch.
            if head == 'hle_dispatch':
                if len(tokens) != 3:
                    raise ValueError(
                        f"{path}: hle_dispatch needs <site_pc16> <c_function_name>, "
                        f"got: {stripped!r}")
                try:
                    pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: hle_dispatch bad pc {tokens[1]!r}: {e}")
                c_name = tokens[2]
                if not c_name.replace('_', '').isalnum() or c_name[0].isdigit():
                    raise ValueError(
                        f"{path}: hle_dispatch c_function_name must be a valid "
                        f"C identifier, got: {c_name!r}")
                cfg.hle_dispatch[pc16] = c_name
                continue

            # indirect_dispatch <site_pc> <count> idx:<X|Y> [tables:<lo>[,<hi>[,<bank>]]]
            #
            # Authorises the decoder to recover the static target list
            # of an indirect JMP/JML/JSR at the named site. See
            # BankCfg.indirect_dispatch for the field shape + table-base
            # interpretation. Class fix for IndirectGoto / Call indirect
            # SUPPRESSED stubs — see _STUB_MARKERS in tools/v2_regen.py
            # and feedback_no_stubs_ever memory.
            if head == 'indirect_dispatch':
                if len(tokens) < 4:
                    raise ValueError(
                        f"{path}: indirect_dispatch needs at least "
                        f"<site_pc> <count> idx:<reg> — got: {stripped!r}")
                try:
                    site_pc16 = _parse_hex(tokens[1]) & 0xFFFF
                except ValueError as e:
                    raise ValueError(
                        f"{path}: indirect_dispatch bad site_pc {tokens[1]!r}: {e}")
                try:
                    count = int(tokens[2], 0)
                except ValueError as e:
                    raise ValueError(
                        f"{path}: indirect_dispatch bad count {tokens[2]!r}: {e}")
                if count <= 0 or count > 4096:
                    raise ValueError(
                        f"{path}: indirect_dispatch count {count} out of range (1..4096)")
                # Pointer-sourced CALL form (the `PEA <ret>; JMP (ptr)` /
                # `JSR (ptr)` idiom, where `ptr` is a WRAM word holding the
                # current handler address — e.g. SM's cinematic_function).
                # Unlike the register-indexed table form, there is no ROM
                # table to walk: the candidate target set is given explicitly
                # (sourced from the decomp's dispatcher switch). The dispatch
                # is a CALL (the pushed PEA return resumes the next block),
                # not a tail transfer.
                #   indirect_dispatch <site_pc16> <count> ptrcall [return:<pc16>] [frame:<2|3>] targets:<t1,t2,...>
                #
                # Targets may be 16-bit local PCs or full 24-bit SNES
                # pointers. Keep full-width values intact: long pointer
                # dispatches such as SM's HDMA pre-instruction call need
                # to distinguish $88:EBB0 from local $08:EBB0.
                pointer_modes = set(tokens[3:]) & {
                    'ptrcall', 'ptrtail', 'ptrtail_popcall', 'rtsstack'
                }
                if pointer_modes:
                    if len(pointer_modes) != 1:
                        raise ValueError(
                            f"{path}: indirect_dispatch chooses exactly one "
                            f"of ptrcall/ptrtail/ptrtail_popcall/rtsstack: "
                            f"{stripped!r}")
                    pointer_mode = next(iter(pointer_modes))
                    targets: Tuple[int, ...] = ()
                    return_pc: Optional[int] = None
                    frame_size: Optional[int] = None
                    for t in tokens[3:]:
                        if t == pointer_mode:
                            continue
                        if t.startswith('targets:'):
                            raw = t[len('targets:'):].split(',')
                            try:
                                targets = tuple(_parse_hex(b) & 0xFFFFFF for b in raw if b)
                            except ValueError as e:
                                raise ValueError(
                                    f"{path}: indirect_dispatch targets: bad hex {t!r}: {e}")
                        elif t.startswith('return:'):
                            if pointer_mode != 'ptrcall':
                                raise ValueError(
                                    f"{path}: indirect_dispatch return: is only valid with ptrcall")
                            try:
                                return_pc = _parse_hex(t[len('return:'):]) & 0xFFFF
                            except ValueError as e:
                                raise ValueError(
                                    f"{path}: indirect_dispatch return: bad hex {t!r}: {e}")
                        elif t.startswith('frame:'):
                            if pointer_mode != 'ptrcall':
                                raise ValueError(
                                    f"{path}: indirect_dispatch frame: is only valid with ptrcall")
                            try:
                                frame_size = int(t[len('frame:'):], 0)
                            except ValueError as e:
                                raise ValueError(
                                    f"{path}: indirect_dispatch frame: bad size {t!r}: {e}")
                            if frame_size not in (2, 3):
                                raise ValueError(
                                    f"{path}: indirect_dispatch frame: must be 2 or 3")
                        else:
                            raise ValueError(
                                f"{path}: indirect_dispatch {pointer_mode} "
                                f"unknown option {t!r}")
                    if not targets:
                        raise ValueError(
                            f"{path}: indirect_dispatch ptrcall needs targets:<...> — got: {stripped!r}")
                    if len(targets) != count:
                        raise ValueError(
                            f"{path}: indirect_dispatch {pointer_mode} count {count} != "
                            f"{len(targets)} targets")
                    cfg.indirect_dispatch.append({
                        'site_pc16': site_pc16,
                        'count': count,
                        'idx_reg': 'X',          # unused (value-matched), kept for emit path
                        'table_bases': (),
                        'ptr_call': pointer_mode == 'ptrcall',
                        # Optional explicit continuation for wrappers which
                        # construct the PEA return frame away from this site.
                        'return_pc': return_pc,
                        'frame_size': frame_size,
                        'pointer_match': pointer_mode != 'rtsstack',
                        # The dispatcher has already PLA'd the two-byte JSR
                        # frame it entered with and hands control to a state
                        # body which owns the enclosing three-byte JSL return.
                        'popped_call_frame': pointer_mode == 'ptrtail_popcall',
                        'rts_stack': pointer_mode == 'rtsstack',
                        'targets': targets,
                    })
                    continue

                idx_reg: Optional[str] = None
                table_bases: Tuple[int, ...] = ()
                for t in tokens[3:]:
                    if t.startswith('idx:'):
                        v = t[len('idx:'):].upper()
                        if v not in ('X', 'Y'):
                            raise ValueError(
                                f"{path}: indirect_dispatch idx: must be X or Y, got {v!r}")
                        idx_reg = v
                    elif t.startswith('tables:'):
                        raw_bases = t[len('tables:'):].split(',')
                        if len(raw_bases) < 1 or len(raw_bases) > 3:
                            raise ValueError(
                                f"{path}: indirect_dispatch tables: needs 1-3 "
                                f"comma-separated hex addresses, got {t!r}")
                        try:
                            table_bases = tuple(_parse_hex(b) & 0xFFFF for b in raw_bases)
                        except ValueError as e:
                            raise ValueError(
                                f"{path}: indirect_dispatch tables: bad hex {t!r}: {e}")
                    else:
                        raise ValueError(
                            f"{path}: indirect_dispatch unknown option {t!r}")
                if idx_reg is None:
                    raise ValueError(
                        f"{path}: indirect_dispatch needs idx:X or idx:Y — got: {stripped!r}")
                cfg.indirect_dispatch.append({
                    'site_pc16': site_pc16,
                    'count': count,
                    'idx_reg': idx_reg,
                    'table_bases': table_bases,
                })
                continue

            # func <name> <hex_pc> [end:<hex_end>] [entry_mx:M,X] [tail_call:<hex>] [exit_mx:M,X]
            #                      [entry_s_offset:<n>] [sig:...] [...]
            if head == 'func':
                if len(tokens) < 3:
                    continue
                name = tokens[1]
                start = _parse_hex(tokens[2])
                end: Optional[int] = None
                entry_m, entry_x = entry_mx_at.get(start & 0xFFFF, (1, 1))
                tail_call_pc16: Optional[int] = None
                exit_mx: Optional[Tuple[int, int]] = None
                entry_s_offset_val: int = 0
                for t in tokens[3:]:
                    if t.startswith('end:'):
                        try:
                            end = _parse_hex(t[len('end:'):])
                        except ValueError:
                            pass
                    elif t.startswith('tail_call:'):
                        # Local 16-bit PC of a sibling fn whose body
                        # this one falls into. The sibling MUST be
                        # declared as its own `func` entry elsewhere in
                        # this same bank cfg; emit_bank validates that
                        # at resolve time.
                        try:
                            tail_call_pc16 = _parse_hex(t[len('tail_call:'):])
                        except ValueError:
                            pass
                    elif t.startswith('exit_mx:'):
                        # Per-function callee-exit (m, x) annotation.
                        # Format: exit_mx:M,X with M and X each 0 or 1.
                        # When the decoder hits a JSR/JSL whose target's
                        # cfg entry has this directive, it resumes the
                        # caller at the annotated (m, x) instead of
                        # assuming the callee preserves the caller's
                        # state. Required for callees that internally
                        # SEP/REP without restoring (e.g. SMW $00:F465
                        # sets m=1 via SEP #$20 at entry, never resets,
                        # so callers in m=0 must resume at m=1 — without
                        # the annotation, decoder mis-decodes operand
                        # widths and synthesises phantom branch targets
                        # at mid-instruction bytes; root cause of the
                        # RunPlayerBlockCode -1 stack drift / Mario-
                        # dies-on-slope bug, 2026-05-03).
                        try:
                            mx_str = t[len('exit_mx:'):]
                            parts = mx_str.split(',')
                            if len(parts) == 2:
                                exit_mx = (int(parts[0]) & 1,
                                           int(parts[1]) & 1)
                        except (ValueError, IndexError):
                            pass
                    elif t.startswith('entry_mx:'):
                        try:
                            mx_str = t[len('entry_mx:'):]
                            parts = mx_str.split(',')
                            if len(parts) == 2:
                                entry_m = int(parts[0]) & 1
                                entry_x = int(parts[1]) & 1
                        except (ValueError, IndexError):
                            pass
                    elif t.startswith('entry_s_offset:'):
                        try:
                            entry_s_offset_val = int(t[len('entry_s_offset:'):])
                        except ValueError:
                            pass
                if (start & 0xFFFF) in end_at:
                    end = end_at[start & 0xFFFF]
                be = BankEntry(
                    name=name, start=start, end=end,
                    entry_m=entry_m, entry_x=entry_x,
                    tail_call_pc16=tail_call_pc16,
                    entry_s_offset=entry_s_offset_val)
                # Non-default attribute on BankEntry; assign post-init.
                if exit_mx is not None:
                    be.exit_mx = exit_mx
                cfg.entries.append(be)
                continue

            # name <hex_addr> <friendly_name> [sig:...]
            if head == 'name':
                if len(tokens) < 3:
                    continue
                try:
                    addr = _parse_hex(tokens[1])
                except ValueError:
                    continue
                friendly = tokens[2]
                cfg.names.append(NameDecl(addr_24=addr, name=friendly))
                continue

            # symbol <hex_addr> <friendly_name>
            #
            # Non-promoting label overlay. This feeds the name resolver for
            # analysis/emission comments and discovered functions, but unlike
            # `name` it never auto-promotes same-bank labels into cfg.entries.
            if head == 'symbol':
                if len(tokens) < 3:
                    continue
                try:
                    addr = _parse_hex(tokens[1])
                except ValueError:
                    continue
                friendly = tokens[2]
                cfg.symbols.append(NameDecl(addr_24=addr, name=friendly))
                continue

            # exclude_range <start> <end>
            if head == 'exclude_range' and len(tokens) >= 3:
                try:
                    s = _parse_hex(tokens[1])
                    e = _parse_hex(tokens[2])
                except ValueError:
                    continue
                cfg.exclude_ranges.append((s, e))
                continue

            # exit_mx_at <hex_24bit_addr> <m> <x>
            #
            # Stand-alone callee-exit-(m,x) annotation. Records that the
            # function entry at the given 24-bit address returns with
            # the named (m, x). Independent of `func` entries — useful
            # when the function is a callee discovered via auto-promote
            # (e.g. SMW $00:F461 is reached only via JSR from inside
            # other functions; it has no cfg `func` line, so the
            # annotation goes here). Bank is encoded in the high byte
            # of the address; format `<bank><addr16>` as 6 hex digits.
            if head == 'exit_mx_at' and len(tokens) >= 4:
                try:
                    addr_24 = _parse_hex(tokens[1])
                    m_val = int(tokens[2]) & 1
                    x_val = int(tokens[3]) & 1
                except ValueError:
                    continue
                bank_id = (addr_24 >> 16) & 0xFF
                addr16 = addr_24 & 0xFFFF
                cfg.exit_mx_at.append((bank_id, addr16, m_val, x_val))
                continue

            # exit_mx_set <hex_24bit_addr> <entry MmXn> <exit MmXn>[,<exit MmXn>...]
            #
            # Declares a callee's exit widths as a SET, for the entry variant
            # named. Use when a routine returns in more than one width from a
            # single entry variant -- see the field comment above.
            #
            #   exit_mx_set 028000 M0X0 M0X1,M1X1
            if head == 'exit_mx_set' and len(tokens) >= 4:
                try:
                    addr_24 = _parse_hex(tokens[1])
                except ValueError:
                    raise ValueError(
                        f"{path}: exit_mx_set bad address in {stripped!r}")
                entry = _parse_mx(tokens[2])
                if entry is None:
                    raise ValueError(
                        f"{path}: exit_mx_set bad entry variant {tokens[2]!r} "
                        f"(want M0X0..M1X1)")
                # Join the tail before splitting so both `M0X1,M1X1` and
                # `M0X1, M1X1` parse -- the tokenizer splits on whitespace.
                exits = set()
                for part in ''.join(tokens[3:]).split(','):
                    mx = _parse_mx(part.strip())
                    if mx is None:
                        raise ValueError(
                            f"{path}: exit_mx_set bad exit variant {part!r} "
                            f"in {stripped!r} (want M0X0..M1X1)")
                    exits.add(mx)
                if len(exits) < 2:
                    raise ValueError(
                        f"{path}: exit_mx_set needs two or more distinct exit "
                        f"widths in {stripped!r}; use exit_mx_at for a single one")
                cfg.exit_mx_set.append((
                    (addr_24 >> 16) & 0xFF, addr_24 & 0xFFFF,
                    entry[0], entry[1], frozenset(exits)))
                continue

            # data_region <bank> <start> <end>
            if head == 'data_region' and len(tokens) >= 4:
                try:
                    b = _parse_hex(tokens[1])
                    s = _parse_hex(tokens[2])
                    e = _parse_hex(tokens[3])
                except ValueError:
                    continue
                cfg.data_regions.append((b, s, e))
                continue

            # ram_routine <pc24> <MmXn> <hexbytes>
            if head == 'ram_routine':
                if len(tokens) != 4:
                    raise ValueError(
                        f"{path}: ram_routine needs <pc24> <MmXn> <hexbytes>, "
                        f"got: {stripped!r}")
                pc24 = _parse_hex(tokens[1]) & 0xFFFFFF
                mx = _parse_mx(tokens[2])
                if mx is None:
                    raise ValueError(
                        f"{path}: ram_routine bad variant {tokens[2]!r} "
                        f"(want M0X0..M1X1)")
                hexbytes = tokens[3]
                if len(hexbytes) % 2 != 0 or not _HEX_RE.match(hexbytes):
                    raise ValueError(
                        f"{path}: ram_routine bad hexbytes {tokens[2]!r}")
                data = bytes.fromhex(hexbytes)
                if not data:
                    raise ValueError(
                        f"{path}: ram_routine {pc24:06X} has empty byte blob")
                bank = (pc24 >> 16) & 0xFF
                if bank not in (0x7E, 0x7F):
                    raise ValueError(
                        f"{path}: ram_routine {pc24:06X} not in WRAM bank "
                        f"$7E/$7F")
                cfg.ram_routines.append(
                    RamRoutine(pc24=pc24, entry_m=mx[0], entry_x=mx[1],
                               data=data))
                continue

            # Anything else: silently ignore (v1-only directive or
            # forward-compat).

    if cfg.bank < 0:
        raise ValueError(f"{path}: missing 'bank = NN' line")

    for entry in cfg.entries:
        override = entry_mx_at.get(entry.start & 0xFFFF)
        if override is not None:
            entry.entry_m, entry.entry_x = override
        end_override = end_at.get(entry.start & 0xFFFF)
        if end_override is not None:
            entry.end = end_override

    # Auto-promote in-bank `name <addr> <friendly>` declarations to emit
    # entries. v1's recompiler auto-promoted JSL/JSR targets into their
    # own functions; v2 doesn't, so JSR/JSL targets named in cfg but
    # without an explicit `func` entry would otherwise be referenced
    # without a definition. (Cross-bank `name` lines stay declaration-
    # only — their owning bank's cfg is responsible for emitting them.)
    existing_starts = {e.start & 0xFFFF for e in cfg.entries}
    for nd in cfg.names:
        if (nd.addr_24 >> 16) & 0xFF != cfg.bank:
            continue
        local_pc = nd.addr_24 & 0xFFFF
        if local_pc in existing_starts:
            continue
        cfg.entries.append(BankEntry(name=nd.name, start=local_pc))
        existing_starts.add(local_pc)

    return cfg
